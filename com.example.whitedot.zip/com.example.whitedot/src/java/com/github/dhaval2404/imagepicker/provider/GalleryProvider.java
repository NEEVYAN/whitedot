/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.imagepicker.provider;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.github.dhaval2404.imagepicker.ImagePickerActivity;
import com.github.dhaval2404.imagepicker.R;
import com.github.dhaval2404.imagepicker.provider.BaseProvider;
import com.github.dhaval2404.imagepicker.util.IntentUtils;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={1, 0, 3}, d1={"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \u00162\u00020\u0001:\u0001\u0016B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0012\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0002J \u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\b\u0010\u000b\u001a\u0004\u0018\u00010\fJ\b\u0010\u0011\u001a\u00020\nH\u0002J\u0006\u0010\u0012\u001a\u00020\nJ\u0010\u0010\u0013\u001a\u00020\n2\u0006\u0010\u0014\u001a\u00020\u0015H\u0002R\u0016\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\b\u00a8\u0006\u0017"}, d2={"Lcom/github/dhaval2404/imagepicker/provider/GalleryProvider;", "Lcom/github/dhaval2404/imagepicker/provider/BaseProvider;", "activity", "Lcom/github/dhaval2404/imagepicker/ImagePickerActivity;", "(Lcom/github/dhaval2404/imagepicker/ImagePickerActivity;)V", "mimeTypes", "", "", "[Ljava/lang/String;", "handleResult", "", "data", "Landroid/content/Intent;", "onActivityResult", "requestCode", "", "resultCode", "startGalleryIntent", "startIntent", "takePersistableUriPermission", "uri", "Landroid/net/Uri;", "Companion", "imagepicker_release"}, k=1, mv={1, 4, 0})
public final class GalleryProvider
extends BaseProvider {
    public static final Companion Companion = new Companion(null);
    private static final int GALLERY_INTENT_REQ_CODE = 4261;
    private final String[] mimeTypes;

    public GalleryProvider(ImagePickerActivity imagePickerActivity) {
        Intrinsics.checkNotNullParameter((Object)((Object)imagePickerActivity), (String)"activity");
        super(imagePickerActivity);
        Intent intent = imagePickerActivity.getIntent();
        Intrinsics.checkNotNullExpressionValue((Object)intent, (String)"activity.intent");
        Bundle bundle = intent.getExtras();
        if (bundle == null) {
            bundle = new Bundle();
        }
        Intrinsics.checkNotNullExpressionValue((Object)bundle, (String)"activity.intent.extras ?: Bundle()");
        String[] arrstring = bundle.getStringArray("extra.mime_types");
        if (arrstring == null) {
            arrstring = new String[]{};
        }
        this.mimeTypes = arrstring;
    }

    private final void handleResult(Intent intent) {
        Uri uri = intent != null ? intent.getData() : null;
        if (uri != null) {
            this.takePersistableUriPermission(uri);
            this.getActivity().setImage(uri);
            return;
        }
        this.setError(R.string.error_failed_pick_gallery_image);
    }

    private final void startGalleryIntent() {
        Intent intent = IntentUtils.getGalleryIntent((Context)this.getActivity(), this.mimeTypes);
        this.getActivity().startActivityForResult(intent, 4261);
    }

    private final void takePersistableUriPermission(Uri uri) {
        this.getContentResolver().takePersistableUriPermission(uri, 1);
    }

    public final void onActivityResult(int n, int n2, Intent intent) {
        if (n == 4261) {
            if (n2 == -1) {
                this.handleResult(intent);
                return;
            }
            this.setResultCancel();
        }
    }

    public final void startIntent() {
        this.startGalleryIntent();
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"}, d2={"Lcom/github/dhaval2404/imagepicker/provider/GalleryProvider$Companion;", "", "()V", "GALLERY_INTENT_REQ_CODE", "", "imagepicker_release"}, k=1, mv={1, 4, 0})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

}

