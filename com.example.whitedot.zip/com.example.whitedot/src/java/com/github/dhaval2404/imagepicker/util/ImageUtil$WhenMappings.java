/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  java.lang.Object
 *  kotlin.Metadata
 */
package com.github.dhaval2404.imagepicker.util;

import android.graphics.Bitmap;
import kotlin.Metadata;

@Metadata(bv={1, 0, 3}, k=3, mv={1, 4, 0})
public final class ImageUtil$WhenMappings {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

    static /* synthetic */ {
        int[] arrn = new int[Bitmap.Config.values().length];
        $EnumSwitchMapping$0 = arrn;
        arrn[Bitmap.Config.ARGB_8888.ordinal()] = 1;
        arrn[Bitmap.Config.RGB_565.ordinal()] = 2;
        arrn[Bitmap.Config.ARGB_4444.ordinal()] = 3;
        arrn[Bitmap.Config.ALPHA_8.ordinal()] = 4;
    }
}

