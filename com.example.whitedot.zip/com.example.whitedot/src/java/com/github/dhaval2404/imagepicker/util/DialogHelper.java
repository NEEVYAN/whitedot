/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.DialogInterface$OnClickListener
 *  android.content.DialogInterface$OnDismissListener
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  com.github.dhaval2404.imagepicker.util.DialogHelper$showChooseAppDialog
 *  com.github.dhaval2404.imagepicker.util.DialogHelper$showChooseAppDialog$dialog
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.imagepicker.util;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.app.AlertDialog;
import com.github.dhaval2404.imagepicker.R;
import com.github.dhaval2404.imagepicker.constant.ImageProvider;
import com.github.dhaval2404.imagepicker.listener.DismissListener;
import com.github.dhaval2404.imagepicker.listener.ResultListener;
import com.github.dhaval2404.imagepicker.util.DialogHelper;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={1, 0, 3}, d1={"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u00c0\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J&\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b2\b\u0010\n\u001a\u0004\u0018\u00010\u000b\u00a8\u0006\f"}, d2={"Lcom/github/dhaval2404/imagepicker/util/DialogHelper;", "", "()V", "showChooseAppDialog", "", "context", "Landroid/content/Context;", "listener", "Lcom/github/dhaval2404/imagepicker/listener/ResultListener;", "Lcom/github/dhaval2404/imagepicker/constant/ImageProvider;", "dismissListener", "Lcom/github/dhaval2404/imagepicker/listener/DismissListener;", "imagepicker_release"}, k=1, mv={1, 4, 0})
public final class DialogHelper {
    public static final DialogHelper INSTANCE = new DialogHelper();

    private DialogHelper() {
    }

    public final void showChooseAppDialog(Context context, ResultListener<ImageProvider> resultListener, DismissListener dismissListener) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        Intrinsics.checkNotNullParameter(resultListener, (String)"listener");
        View view = LayoutInflater.from((Context)context).inflate(R.layout.dialog_choose_app, null);
        AlertDialog alertDialog = new AlertDialog.Builder(context).setTitle(R.string.title_choose_image_provider).setView(view).setOnCancelListener(new DialogInterface.OnCancelListener(resultListener){
            final /* synthetic */ ResultListener $listener;
            {
                this.$listener = resultListener;
            }

            public final void onCancel(DialogInterface dialogInterface) {
                this.$listener.onResult(null);
            }
        }).setNegativeButton(R.string.action_cancel, new DialogInterface.OnClickListener(resultListener){
            final /* synthetic */ ResultListener $listener;
            {
                this.$listener = resultListener;
            }

            public final void onClick(DialogInterface dialogInterface, int n) {
                this.$listener.onResult(null);
            }
        }).setOnDismissListener(new DialogInterface.OnDismissListener(dismissListener){
            final /* synthetic */ DismissListener $dismissListener;
            {
                this.$dismissListener = dismissListener;
            }

            public final void onDismiss(DialogInterface dialogInterface) {
                DismissListener dismissListener = this.$dismissListener;
                if (dismissListener != null) {
                    dismissListener.onDismiss();
                }
            }
        }).show();
        view.findViewById(R.id.lytCameraPick).setOnClickListener(new View.OnClickListener(resultListener, alertDialog){
            final /* synthetic */ AlertDialog $dialog;
            final /* synthetic */ ResultListener $listener;
            {
                this.$listener = resultListener;
                this.$dialog = alertDialog;
            }

            public final void onClick(View view) {
                this.$listener.onResult(ImageProvider.CAMERA);
                this.$dialog.dismiss();
            }
        });
        view.findViewById(R.id.lytGalleryPick).setOnClickListener(new View.OnClickListener(resultListener, alertDialog){
            final /* synthetic */ AlertDialog $dialog;
            final /* synthetic */ ResultListener $listener;
            {
                this.$listener = resultListener;
                this.$dialog = alertDialog;
            }

            public final void onClick(View view) {
                this.$listener.onResult(ImageProvider.GALLERY);
                this.$dialog.dismiss();
            }
        });
    }
}

