/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.provider.DocumentsContract
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Audio
 *  android.provider.MediaStore$Audio$Media
 *  android.provider.MediaStore$Images
 *  android.provider.MediaStore$Images$Media
 *  android.provider.MediaStore$Video
 *  android.provider.MediaStore$Video$Media
 *  dalvik.annotation.SourceDebugExtension
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.List
 *  java.util.ListIterator
 *  kotlin.Metadata
 *  kotlin.collections.CollectionsKt
 *  kotlin.io.ByteStreamsKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.Regex
 *  kotlin.text.StringsKt
 */
package com.github.dhaval2404.imagepicker.util;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import com.github.dhaval2404.imagepicker.util.FileUtil;
import dalvik.annotation.SourceDebugExtension;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.List;
import java.util.ListIterator;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.io.ByteStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import kotlin.text.StringsKt;

@SourceDebugExtension(value="SMAP\nFileUriUtils.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FileUriUtils.kt\ncom/github/dhaval2404/imagepicker/util/FileUriUtils\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,232:1\n679#2,9:233\n679#2,9:244\n37#3,2:242\n37#3,2:253\n*E\n*S KotlinDebug\n*F\n+ 1 FileUriUtils.kt\ncom/github/dhaval2404/imagepicker/util/FileUriUtils\n*L\n44#1,9:233\n130#1,9:244\n44#1,2:242\n130#1,2:253\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J;\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\b2\b\u0010\t\u001a\u0004\u0018\u00010\u00042\u000e\u0010\n\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u000bH\u0002\u00a2\u0006\u0002\u0010\fJ\u001a\u0010\r\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u001a\u0010\u000e\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u001a\u0010\u000f\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u001a\u0010\u0010\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u001a\u0010\u0011\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u0018\u0010\u0012\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bJ\u0010\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u0010\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u0010\u0010\u0016\u001a\u00020\u00142\u0006\u0010\u0007\u001a\u00020\bH\u0002J\u0010\u0010\u0017\u001a\u00020\u00142\u0006\u0010\u0007\u001a\u00020\bH\u0002\u00a8\u0006\u0018"}, d2={"Lcom/github/dhaval2404/imagepicker/util/FileUriUtils;", "", "()V", "getDataColumn", "", "context", "Landroid/content/Context;", "uri", "Landroid/net/Uri;", "selection", "selectionArgs", "", "(Landroid/content/Context;Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;", "getDownloadDocument", "getFilePath", "getMediaDocument", "getPathFromLocalUri", "getPathFromRemoteUri", "getRealPath", "isDownloadsDocument", "", "isExternalStorageDocument", "isGooglePhotosUri", "isMediaDocument", "imagepicker_release"}, k=1, mv={1, 4, 0})
public final class FileUriUtils {
    public static final FileUriUtils INSTANCE = new FileUriUtils();

    private FileUriUtils() {
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private final String getDataColumn(Context context, Uri uri, String string2, String[] arrstring) {
        Throwable throwable2222;
        Cursor cursor;
        block5 : {
            block6 : {
                block4 : {
                    cursor = null;
                    String[] arrstring2 = new String[]{"_data"};
                    ContentResolver contentResolver = context.getContentResolver();
                    Intrinsics.checkNotNull((Object)uri);
                    cursor = contentResolver.query(uri, arrstring2, string2, arrstring, null);
                    if (cursor == null || !cursor.moveToFirst()) break block4;
                    String string3 = cursor.getString(cursor.getColumnIndexOrThrow("_data"));
                    cursor.close();
                    return string3;
                }
                if (cursor == null) return null;
                break block6;
                {
                    catch (Throwable throwable2222) {
                        break block5;
                    }
                    catch (Exception exception) {}
                    {
                        exception.printStackTrace();
                        if (cursor == null) return null;
                    }
                }
            }
            cursor.close();
            return null;
        }
        if (cursor == null) throw throwable2222;
        cursor.close();
        throw throwable2222;
    }

    private final String getDownloadDocument(Context context, Uri uri) {
        String string2;
        String string3 = this.getFilePath(context, uri);
        if (string3 != null && new File(string2 = Environment.getExternalStorageDirectory().toString() + "/Download/" + string3).exists()) {
            return string2;
        }
        String string4 = DocumentsContract.getDocumentId((Uri)uri);
        Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"id");
        if (StringsKt.contains$default((CharSequence)string4, (CharSequence)":", (boolean)false, (int)2, null)) {
            string4 = (String)StringsKt.split$default((CharSequence)string4, (String[])new String[]{":"}, (boolean)false, (int)0, (int)6, null).get(1);
        }
        Uri uri2 = Uri.parse((String)"content://downloads/public_downloads");
        Long l = Long.valueOf((String)string4);
        Intrinsics.checkNotNullExpressionValue((Object)l, (String)"java.lang.Long.valueOf(id)");
        Uri uri3 = ContentUris.withAppendedId((Uri)uri2, (long)l);
        Intrinsics.checkNotNullExpressionValue((Object)uri3, (String)"ContentUris.withAppended\u2026ong.valueOf(id)\n        )");
        return this.getDataColumn(context, uri3, null, null);
    }

    private final String getFilePath(Context context, Uri uri) {
        Cursor cursor;
        block5 : {
            cursor = null;
            String[] arrstring = new String[]{"_display_name"};
            try {
                cursor = context.getContentResolver().query(uri, arrstring, null, null, null);
                if (cursor == null) break block5;
            }
            catch (Throwable throwable) {
                if (cursor != null) {
                    cursor.close();
                }
                throw throwable;
            }
            if (!cursor.moveToFirst()) break block5;
            String string2 = cursor.getString(cursor.getColumnIndexOrThrow("_display_name"));
            cursor.close();
            return string2;
        }
        if (cursor != null) {
            cursor.close();
        }
        return null;
    }

    private final String getMediaDocument(Context context, Uri uri) {
        List list;
        String string2 = DocumentsContract.getDocumentId((Uri)uri);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"docId");
        CharSequence charSequence = string2;
        List list2 = new Regex(":").split(charSequence, 0);
        if (!list2.isEmpty()) {
            ListIterator listIterator = list2.listIterator(list2.size());
            while (listIterator.hasPrevious()) {
                boolean bl = ((CharSequence)((String)listIterator.previous())).length() == 0;
                if (bl) continue;
                list = CollectionsKt.take((Iterable)((Iterable)list2), (int)(1 + listIterator.nextIndex()));
                break;
            }
        } else {
            list = CollectionsKt.emptyList();
        }
        Object[] arrobject = ((Collection)list).toArray((Object[])new String[0]);
        if (arrobject != null) {
            String[] arrstring = (String[])arrobject;
            String string3 = arrstring[0];
            Uri uri2 = null;
            if (Intrinsics.areEqual((Object)"image", (Object)string3)) {
                uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            } else if (Intrinsics.areEqual((Object)"video", (Object)string3)) {
                uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            } else if (Intrinsics.areEqual((Object)"audio", (Object)string3)) {
                uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            }
            String[] arrstring2 = new String[]{arrstring[1]};
            return this.getDataColumn(context, uri2, "_id=?", arrstring2);
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
    }

    private final String getPathFromLocalUri(Context context, Uri uri) {
        boolean bl = Build.VERSION.SDK_INT >= 19;
        if (bl && DocumentsContract.isDocumentUri((Context)context, (Uri)uri)) {
            if (this.isExternalStorageDocument(uri)) {
                List list;
                String string2 = DocumentsContract.getDocumentId((Uri)uri);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"docId");
                CharSequence charSequence = string2;
                List list2 = new Regex(":").split(charSequence, 0);
                if (!list2.isEmpty()) {
                    ListIterator listIterator = list2.listIterator(list2.size());
                    while (listIterator.hasPrevious()) {
                        boolean bl2 = ((CharSequence)((String)listIterator.previous())).length() == 0;
                        if (bl2) continue;
                        list = CollectionsKt.take((Iterable)((Iterable)list2), (int)(1 + listIterator.nextIndex()));
                        break;
                    }
                } else {
                    list = CollectionsKt.emptyList();
                }
                Object[] arrobject = ((Collection)list).toArray((Object[])new String[0]);
                if (arrobject != null) {
                    String[] arrstring = (String[])arrobject;
                    if (StringsKt.equals((String)"primary", (String)arrstring[0], (boolean)true)) {
                        if (arrstring.length > 1) {
                            return Environment.getExternalStorageDirectory().toString() + "/" + arrstring[1];
                        }
                        return Environment.getExternalStorageDirectory().toString() + "/";
                    }
                    String string3 = "storage/" + StringsKt.replace$default((String)string2, (String)":", (String)"/", (boolean)false, (int)4, null);
                    if (new File(string3).exists()) {
                        return string3;
                    }
                    return "/storage/sdcard/" + arrstring[1];
                }
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
            }
            if (this.isDownloadsDocument(uri)) {
                return this.getDownloadDocument(context, uri);
            }
            if (this.isMediaDocument(uri)) {
                return this.getMediaDocument(context, uri);
            }
            return null;
        }
        String string4 = uri.getScheme();
        Intrinsics.checkNotNull((Object)string4);
        if (StringsKt.equals((String)"content", (String)string4, (boolean)true)) {
            if (this.isGooglePhotosUri(uri)) {
                return uri.getLastPathSegment();
            }
            return this.getDataColumn(context, uri, null, null);
        }
        String string5 = uri.getScheme();
        Intrinsics.checkNotNull((Object)string5);
        if (StringsKt.equals((String)"file", (String)string5, (boolean)true)) {
            return uri.getPath();
        }
        return null;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private final String getPathFromRemoteUri(Context context, Uri uri) {
        boolean bl;
        File file;
        block23 : {
            block24 : {
                InputStream inputStream;
                OutputStream outputStream;
                block22 : {
                    block21 : {
                        File file2;
                        file = null;
                        inputStream = null;
                        outputStream = null;
                        String string2 = FileUtil.INSTANCE.getImageExtension(uri);
                        inputStream = context.getContentResolver().openInputStream(uri);
                        FileUtil fileUtil = FileUtil.INSTANCE;
                        File file3 = context.getCacheDir();
                        Intrinsics.checkNotNullExpressionValue((Object)file3, (String)"context.cacheDir");
                        file = file2 = fileUtil.getImageFile(file3, string2);
                        if (file != null) break block21;
                        if (inputStream == null) return null;
                        try {
                            inputStream.close();
                            return null;
                        }
                        catch (IOException iOException) {
                            // empty catch block
                        }
                        return null;
                    }
                    outputStream = (OutputStream)new FileOutputStream(file);
                    bl = false;
                    if (inputStream != null) {
                        ByteStreamsKt.copyTo((InputStream)inputStream, (OutputStream)outputStream, (int)4096);
                        bl = true;
                    }
                    if (inputStream == null) break block22;
                    try {
                        inputStream.close();
                    }
                    catch (IOException iOException) {
                        // empty catch block
                    }
                }
                try {
                    outputStream.close();
                    break block23;
                }
                catch (IOException iOException) {
                    break block24;
                }
                catch (Throwable throwable) {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        }
                        catch (IOException iOException) {
                            // empty catch block
                        }
                    }
                    if (outputStream == null) throw throwable;
                    try {
                        outputStream.close();
                        throw throwable;
                    }
                    catch (IOException iOException) {
                        // empty catch block
                    }
                    throw throwable;
                }
                catch (IOException iOException) {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        }
                        catch (IOException iOException2) {
                            // empty catch block
                        }
                    }
                    bl = false;
                    if (outputStream == null) break block23;
                    try {
                        outputStream.close();
                        bl = false;
                        break block23;
                    }
                    catch (IOException iOException3) {
                        // empty catch block
                    }
                }
            }
            bl = false;
        }
        String string3 = null;
        if (!bl) return string3;
        Intrinsics.checkNotNull((Object)file);
        return file.getPath();
    }

    private final boolean isDownloadsDocument(Uri uri) {
        return Intrinsics.areEqual((Object)"com.android.providers.downloads.documents", (Object)uri.getAuthority());
    }

    private final boolean isExternalStorageDocument(Uri uri) {
        return Intrinsics.areEqual((Object)"com.android.externalstorage.documents", (Object)uri.getAuthority());
    }

    private final boolean isGooglePhotosUri(Uri uri) {
        return Intrinsics.areEqual((Object)"com.google.android.apps.photos.content", (Object)uri.getAuthority());
    }

    private final boolean isMediaDocument(Uri uri) {
        return Intrinsics.areEqual((Object)"com.android.providers.media.documents", (Object)uri.getAuthority());
    }

    public final String getRealPath(Context context, Uri uri) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        Intrinsics.checkNotNullParameter((Object)uri, (String)"uri");
        String string2 = this.getPathFromLocalUri(context, uri);
        if (string2 == null) {
            string2 = this.getPathFromRemoteUri(context, uri);
        }
        return string2;
    }
}

