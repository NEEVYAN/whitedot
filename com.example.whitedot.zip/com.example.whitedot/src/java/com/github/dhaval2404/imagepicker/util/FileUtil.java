/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.ParcelFileDescriptor
 *  android.os.StatFs
 *  androidx.documentfile.provider.DocumentFile
 *  java.io.File
 *  java.io.FileDescriptor
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.channels.FileChannel
 *  java.nio.channels.ReadableByteChannel
 *  java.text.SimpleDateFormat
 *  java.util.Date
 *  java.util.Locale
 *  kotlin.Metadata
 *  kotlin.Pair
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package com.github.dhaval2404.imagepicker.util;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.StatFs;
import androidx.documentfile.provider.DocumentFile;
import com.github.dhaval2404.imagepicker.util.FileUriUtils;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

@Metadata(bv={1, 0, 3}, d1={"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u0018\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\b\u0010\r\u001a\u00020\u0006H\u0002J\u000e\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011J\u000e\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\fJ\u000e\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u0011J\u001c\u0010\u0014\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0015\u001a\u00020\u00112\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006J\"\u0010\u0016\u001a\u000e\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u00180\u00172\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u001a\u0010\u0016\u001a\u000e\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u00180\u00172\u0006\u0010\u0010\u001a\u00020\u0011J\u0016\u0010\u0019\u001a\u00020\u000f2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u0018\u0010\u001a\u001a\u0004\u0018\u00010\u00112\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\b\u0010\u001b\u001a\u00020\u0006H\u0002J\u0010\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u000b\u001a\u00020\fH\u0002\u00a8\u0006\u001e"}, d2={"Lcom/github/dhaval2404/imagepicker/util/FileUtil;", "", "()V", "getCompressFormat", "Landroid/graphics/Bitmap$CompressFormat;", "extension", "", "getDocumentFile", "Landroidx/documentfile/provider/DocumentFile;", "context", "Landroid/content/Context;", "uri", "Landroid/net/Uri;", "getFileName", "getFreeSpace", "", "file", "Ljava/io/File;", "getImageExtension", "uriImage", "getImageFile", "fileDir", "getImageResolution", "Lkotlin/Pair;", "", "getImageSize", "getTempFile", "getTimestamp", "isFileUri", "", "imagepicker_release"}, k=1, mv={1, 4, 0})
public final class FileUtil {
    public static final FileUtil INSTANCE = new FileUtil();

    private FileUtil() {
    }

    private final String getFileName() {
        return "IMG_" + this.getTimestamp();
    }

    public static /* synthetic */ File getImageFile$default(FileUtil fileUtil, File file, String string2, int n, Object object) {
        if ((n & 2) != 0) {
            string2 = null;
            (String)null;
        }
        return fileUtil.getImageFile(file, string2);
    }

    private final String getTimestamp() {
        String string2 = new SimpleDateFormat("yyyyMMdd_HHmmssSSS", Locale.getDefault()).format(new Date());
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"SimpleDateFormat(timeFor\u2026Default()).format(Date())");
        return string2;
    }

    private final boolean isFileUri(Uri uri) {
        return StringsKt.equals((String)"file", (String)uri.getScheme(), (boolean)true);
    }

    public final Bitmap.CompressFormat getCompressFormat(String string2) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"extension");
        if (StringsKt.contains((CharSequence)string2, (CharSequence)"png", (boolean)true)) {
            return Bitmap.CompressFormat.PNG;
        }
        if (StringsKt.contains((CharSequence)string2, (CharSequence)"webp", (boolean)true)) {
            if (Build.VERSION.SDK_INT >= 30) {
                return Bitmap.CompressFormat.WEBP_LOSSLESS;
            }
            return Bitmap.CompressFormat.WEBP;
        }
        return Bitmap.CompressFormat.JPEG;
    }

    public final DocumentFile getDocumentFile(Context context, Uri uri) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        Intrinsics.checkNotNullParameter((Object)uri, (String)"uri");
        DocumentFile documentFile = null;
        if (this.isFileUri(uri)) {
            String string2 = FileUriUtils.INSTANCE.getRealPath(context, uri);
            if (string2 != null) {
                return DocumentFile.fromFile((File)new File(string2));
            }
        } else {
            documentFile = DocumentFile.fromSingleUri((Context)context, (Uri)uri);
        }
        return documentFile;
    }

    public final long getFreeSpace(File file) {
        Intrinsics.checkNotNullParameter((Object)file, (String)"file");
        StatFs statFs = new StatFs(file.getPath());
        return statFs.getAvailableBlocksLong() * statFs.getBlockSizeLong();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final String getImageExtension(Uri uri) {
        String string2;
        block9 : {
            block8 : {
                Intrinsics.checkNotNullParameter((Object)uri, (String)"uriImage");
                string2 = null;
                int n = 1;
                try {
                    String string3 = uri.getPath();
                    if (string3 != null && StringsKt.lastIndexOf$default((CharSequence)string3, (String)".", (int)0, (boolean)false, (int)6, null) != -1) {
                        String string4 = string3.substring(n + StringsKt.lastIndexOf$default((CharSequence)string3, (String)".", (int)0, (boolean)false, (int)6, null));
                        Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"(this as java.lang.String).substring(startIndex)");
                        string2 = string4;
                    }
                }
                catch (Exception exception) {
                    string2 = null;
                }
                if (string2 == null) break block8;
                if (((CharSequence)string2).length() != 0) {
                    n = 0;
                }
                if (n == 0) break block9;
            }
            string2 = "jpg";
        }
        return '.' + string2;
    }

    public final String getImageExtension(File file) {
        Intrinsics.checkNotNullParameter((Object)file, (String)"file");
        Uri uri = Uri.fromFile((File)file);
        Intrinsics.checkNotNullExpressionValue((Object)uri, (String)"Uri.fromFile(file)");
        return this.getImageExtension(uri);
    }

    public final File getImageFile(File file, String string2) {
        Intrinsics.checkNotNullParameter((Object)file, (String)"fileDir");
        String string3 = string2 != null ? string2 : ".jpg";
        try {
            String string4 = this.getFileName();
            String string5 = string4 + string3;
            if (!file.exists()) {
                file.mkdirs();
            }
            File file2 = new File(file, string5);
            file2.createNewFile();
            return file2;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return null;
        }
    }

    public final Pair<Integer, Integer> getImageResolution(Context context, Uri uri) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        Intrinsics.checkNotNullParameter((Object)uri, (String)"uri");
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream((InputStream)context.getContentResolver().openInputStream(uri), null, (BitmapFactory.Options)options);
        return new Pair((Object)options.outWidth, (Object)options.outHeight);
    }

    public final Pair<Integer, Integer> getImageResolution(File file) {
        Intrinsics.checkNotNullParameter((Object)file, (String)"file");
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile((String)file.getAbsolutePath(), (BitmapFactory.Options)options);
        return new Pair((Object)options.outWidth, (Object)options.outHeight);
    }

    public final long getImageSize(Context context, Uri uri) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        Intrinsics.checkNotNullParameter((Object)uri, (String)"uri");
        DocumentFile documentFile = this.getDocumentFile(context, uri);
        if (documentFile != null) {
            return documentFile.length();
        }
        return 0L;
    }

    public final File getTempFile(Context context, Uri uri) {
        block4 : {
            File file;
            ParcelFileDescriptor parcelFileDescriptor;
            Intrinsics.checkNotNullParameter((Object)context, (String)"context");
            Intrinsics.checkNotNullParameter((Object)uri, (String)"uri");
            try {
                file = new File(context.getCacheDir(), "image_picker.png");
                parcelFileDescriptor = context.getContentResolver().openFileDescriptor(uri, "r");
                if (parcelFileDescriptor == null) break block4;
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
                return null;
            }
            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
            if (fileDescriptor == null) break block4;
            FileChannel fileChannel = new FileInputStream(fileDescriptor).getChannel();
            FileChannel fileChannel2 = new FileOutputStream(file).getChannel();
            fileChannel2.transferFrom((ReadableByteChannel)fileChannel, 0L, fileChannel.size());
            fileChannel.close();
            fileChannel2.close();
            return file;
        }
        return null;
    }
}

