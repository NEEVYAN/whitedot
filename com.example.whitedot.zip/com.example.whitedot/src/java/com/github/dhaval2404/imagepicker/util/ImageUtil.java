/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.String
 *  java.lang.Throwable
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.imagepicker.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Build;
import com.github.dhaval2404.imagepicker.util.ImageUtil$WhenMappings;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={1, 0, 3}, d1={"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J \u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u0004H\u0002J\u0018\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u0006H\u0002J.\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\u00112\u0006\u0010\b\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015J\"\u0010\u0016\u001a\u0004\u0018\u00010\f2\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\u00112\u0006\u0010\b\u001a\u00020\u0011H\u0002J\u0010\u0010\u0017\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0019H\u0002\u00a8\u0006\u001a"}, d2={"Lcom/github/dhaval2404/imagepicker/util/ImageUtil;", "", "()V", "calculateInSampleSize", "", "options", "Landroid/graphics/BitmapFactory$Options;", "reqWidth", "reqHeight", "canUseForInBitmap", "", "candidate", "Landroid/graphics/Bitmap;", "targetOptions", "compressImage", "Ljava/io/File;", "imageFile", "", "compressFormat", "Landroid/graphics/Bitmap$CompressFormat;", "destinationPath", "", "decodeSampledBitmapFromFile", "getBytesPerPixel", "config", "Landroid/graphics/Bitmap$Config;", "imagepicker_release"}, k=1, mv={1, 4, 0})
public final class ImageUtil {
    public static final ImageUtil INSTANCE = new ImageUtil();

    private ImageUtil() {
    }

    private final int calculateInSampleSize(BitmapFactory.Options options, int n, int n2) {
        int n3 = options.outHeight;
        int n4 = options.outWidth;
        int n5 = 1;
        if (n3 > n2 || n4 > n) {
            int n6 = n3 / 2;
            int n7 = n4 / 2;
            while (n6 / n5 >= n2 && n7 / n5 >= n) {
                n5 *= 2;
            }
        }
        return n5;
    }

    private final boolean canUseForInBitmap(Bitmap bitmap, BitmapFactory.Options options) {
        if (Build.VERSION.SDK_INT >= 19) {
            int n = options.outWidth / options.inSampleSize * (options.outHeight / options.inSampleSize);
            Bitmap.Config config = bitmap.getConfig();
            Intrinsics.checkNotNullExpressionValue((Object)config, (String)"candidate.config");
            return n * this.getBytesPerPixel(config) <= bitmap.getAllocationByteCount();
        }
        int n = bitmap.getWidth();
        int n2 = options.outWidth;
        boolean bl = false;
        if (n == n2) {
            int n3 = bitmap.getHeight();
            int n4 = options.outHeight;
            bl = false;
            if (n3 == n4) {
                int n5 = options.inSampleSize;
                bl = false;
                if (n5 == 1) {
                    bl = true;
                }
            }
        }
        return bl;
    }

    private final Bitmap decodeSampledBitmapFromFile(File file, float f, float f2) throws IOException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        Bitmap bitmap = BitmapFactory.decodeFile((String)file.getAbsolutePath(), (BitmapFactory.Options)options);
        int n = options.outHeight;
        int n2 = options.outWidth;
        float f3 = (float)n2 / (float)n;
        float f4 = f / f2;
        if ((float)n > f2 || (float)n2 > f) {
            if (f3 < f4) {
                n2 = (int)(f2 / (float)n * (float)n2);
                n = (int)f2;
            } else if (f3 > f4) {
                n = (int)(f / (float)n2 * (float)n);
                n2 = (int)f;
            } else {
                n = (int)f2;
                n2 = (int)f;
            }
        }
        options.inSampleSize = this.calculateInSampleSize(options, n2, n);
        options.inJustDecodeBounds = false;
        if (bitmap != null && this.canUseForInBitmap(bitmap, options)) {
            options.inMutable = true;
            options.inBitmap = bitmap;
        }
        options.inTempStorage = new byte[16384];
        try {
            Bitmap bitmap2;
            bitmap = bitmap2 = BitmapFactory.decodeFile((String)file.getAbsolutePath(), (BitmapFactory.Options)options);
        }
        catch (OutOfMemoryError outOfMemoryError) {
            outOfMemoryError.printStackTrace();
        }
        Bitmap bitmap3 = null;
        try {
            Bitmap bitmap4;
            bitmap3 = bitmap4 = Bitmap.createBitmap((int)n2, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        }
        catch (OutOfMemoryError outOfMemoryError) {
            outOfMemoryError.printStackTrace();
        }
        float f5 = (float)n2 / (float)options.outWidth;
        float f6 = (float)n / (float)options.outHeight;
        float f7 = (float)n2 / 2.0f;
        float f8 = (float)n / 2.0f;
        Matrix matrix = new Matrix();
        matrix.setScale(f5, f6, f7, f8);
        Intrinsics.checkNotNull((Object)bitmap3);
        Canvas canvas = new Canvas(bitmap3);
        canvas.setMatrix(matrix);
        Intrinsics.checkNotNull((Object)bitmap);
        canvas.drawBitmap(bitmap, f7 - (float)(bitmap.getWidth() / 2), f8 - (float)(bitmap.getHeight() / 2), new Paint(2));
        bitmap.recycle();
        Matrix matrix2 = new Matrix();
        int n3 = bitmap3.getWidth();
        int n4 = bitmap3.getHeight();
        return Bitmap.createBitmap((Bitmap)bitmap3, (int)0, (int)0, (int)n3, (int)n4, (Matrix)matrix2, (boolean)true);
    }

    private final int getBytesPerPixel(Bitmap.Config config) {
        switch (ImageUtil$WhenMappings.$EnumSwitchMapping$0[config.ordinal()]) {
            default: {
                return 1;
            }
            case 4: {
                return 1;
            }
            case 2: 
            case 3: {
                return 2;
            }
            case 1: 
        }
        return 4;
    }

    public final File compressImage(File file, float f, float f2, Bitmap.CompressFormat compressFormat, String string2) throws IOException {
        FileOutputStream fileOutputStream;
        block5 : {
            Bitmap bitmap;
            Intrinsics.checkNotNullParameter((Object)file, (String)"imageFile");
            Intrinsics.checkNotNullParameter((Object)compressFormat, (String)"compressFormat");
            Intrinsics.checkNotNullParameter((Object)string2, (String)"destinationPath");
            fileOutputStream = null;
            File file2 = new File(string2).getParentFile();
            if (file2 != null && !file2.exists()) {
                file2.mkdirs();
            }
            try {
                fileOutputStream = new FileOutputStream(string2);
                bitmap = this.decodeSampledBitmapFromFile(file, f, f2);
                if (bitmap == null) break block5;
            }
            catch (Throwable throwable) {
                if (fileOutputStream != null) {
                    fileOutputStream.flush();
                    fileOutputStream.close();
                }
                throw throwable;
            }
            bitmap.compress(compressFormat, 100, (OutputStream)fileOutputStream);
        }
        fileOutputStream.flush();
        fileOutputStream.close();
        return new File(string2);
    }
}

