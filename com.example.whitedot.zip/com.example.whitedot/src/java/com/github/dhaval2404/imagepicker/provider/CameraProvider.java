/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Bundle
 *  androidx.core.app.ActivityCompat
 *  dalvik.annotation.SourceDebugExtension
 *  java.io.File
 *  java.io.Serializable
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.imagepicker.provider;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import com.github.dhaval2404.imagepicker.ImagePickerActivity;
import com.github.dhaval2404.imagepicker.R;
import com.github.dhaval2404.imagepicker.provider.BaseProvider;
import com.github.dhaval2404.imagepicker.util.FileUtil;
import com.github.dhaval2404.imagepicker.util.IntentUtils;
import com.github.dhaval2404.imagepicker.util.PermissionUtil;
import dalvik.annotation.SourceDebugExtension;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@SourceDebugExtension(value="SMAP\nCameraProvider.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CameraProvider.kt\ncom/github/dhaval2404/imagepicker/provider/CameraProvider\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,225:1\n17978#2,2:226\n3665#2:228\n4180#2,2:229\n37#3,2:231\n*E\n*S KotlinDebug\n*F\n+ 1 CameraProvider.kt\ncom/github/dhaval2404/imagepicker/provider/CameraProvider\n*L\n149#1,2:226\n161#1:228\n161#1,2:229\n163#1,2:231\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 $2\u00020\u0001:\u0001$B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\b\u0010\b\u001a\u00020\tH\u0002J\u0006\u0010\n\u001a\u00020\tJ\u001b\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\f2\u0006\u0010\u000e\u001a\u00020\u000fH\u0002\u00a2\u0006\u0002\u0010\u0010J\b\u0010\u0011\u001a\u00020\tH\u0002J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u000e\u001a\u00020\u000fH\u0002J \u0010\u0014\u001a\u00020\t2\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00162\b\u0010\u0018\u001a\u0004\u0018\u00010\u0019J\b\u0010\u001a\u001a\u00020\tH\u0014J\u000e\u0010\u001b\u001a\u00020\t2\u0006\u0010\u0015\u001a\u00020\u0016J\u0012\u0010\u001c\u001a\u00020\t2\b\u0010\u001d\u001a\u0004\u0018\u00010\u001eH\u0016J\u0010\u0010\u001f\u001a\u00020\t2\u0006\u0010 \u001a\u00020\u001eH\u0016J\b\u0010!\u001a\u00020\tH\u0002J\b\u0010\"\u001a\u00020\tH\u0002J\u0006\u0010#\u001a\u00020\tR\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006%"}, d2={"Lcom/github/dhaval2404/imagepicker/provider/CameraProvider;", "Lcom/github/dhaval2404/imagepicker/provider/BaseProvider;", "activity", "Lcom/github/dhaval2404/imagepicker/ImagePickerActivity;", "(Lcom/github/dhaval2404/imagepicker/ImagePickerActivity;)V", "mCameraFile", "Ljava/io/File;", "mFileDir", "checkPermission", "", "delete", "getRequiredPermission", "", "", "context", "Landroid/content/Context;", "(Landroid/content/Context;)[Ljava/lang/String;", "handleResult", "isPermissionGranted", "", "onActivityResult", "requestCode", "", "resultCode", "data", "Landroid/content/Intent;", "onFailure", "onRequestPermissionsResult", "onRestoreInstanceState", "savedInstanceState", "Landroid/os/Bundle;", "onSaveInstanceState", "outState", "requestPermission", "startCameraIntent", "startIntent", "Companion", "imagepicker_release"}, k=1, mv={1, 4, 0})
public final class CameraProvider
extends BaseProvider {
    private static final int CAMERA_INTENT_REQ_CODE = 4281;
    public static final Companion Companion = new Companion(null);
    private static final int PERMISSION_INTENT_REQ_CODE = 4282;
    private static final String[] REQUIRED_PERMISSIONS = new String[]{"android.permission.CAMERA"};
    private static final String STATE_CAMERA_FILE = "state.camera_file";
    private File mCameraFile;
    private final File mFileDir;

    public CameraProvider(ImagePickerActivity imagePickerActivity) {
        Intrinsics.checkNotNullParameter((Object)((Object)imagePickerActivity), (String)"activity");
        super(imagePickerActivity);
        Intent intent = imagePickerActivity.getIntent();
        Intrinsics.checkNotNullExpressionValue((Object)intent, (String)"activity.intent");
        Bundle bundle = intent.getExtras();
        if (bundle == null) {
            bundle = new Bundle();
        }
        Intrinsics.checkNotNullExpressionValue((Object)bundle, (String)"activity.intent.extras ?: Bundle()");
        this.mFileDir = this.getFileDir(bundle.getString("extra.save_directory"));
    }

    private final void checkPermission() {
        if (this.isPermissionGranted((Context)this)) {
            this.startCameraIntent();
            return;
        }
        this.requestPermission();
    }

    private final String[] getRequiredPermission(Context context) {
        String[] arrstring = REQUIRED_PERMISSIONS;
        Collection collection = (Collection)new ArrayList();
        for (String string2 : arrstring) {
            if (!PermissionUtil.INSTANCE.isPermissionInManifest(context, string2)) continue;
            collection.add((Object)string2);
        }
        Object[] arrobject = ((Collection)((List)collection)).toArray((Object[])new String[0]);
        if (arrobject != null) {
            return (String[])arrobject;
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T>");
    }

    private final void handleResult() {
        ImagePickerActivity imagePickerActivity = this.getActivity();
        Uri uri = Uri.fromFile((File)this.mCameraFile);
        Intrinsics.checkNotNullExpressionValue((Object)uri, (String)"Uri.fromFile(mCameraFile)");
        imagePickerActivity.setImage(uri);
    }

    private final boolean isPermissionGranted(Context context) {
        for (String string2 : this.getRequiredPermission(context)) {
            if (!(true ^ PermissionUtil.INSTANCE.isPermissionGranted(context, string2))) continue;
            return false;
        }
        return true;
    }

    private final void requestPermission() {
        ActivityCompat.requestPermissions((Activity)((Activity)this.getActivity()), (String[])this.getRequiredPermission((Context)this.getActivity()), (int)4282);
    }

    private final void startCameraIntent() {
        File file;
        this.mCameraFile = file = FileUtil.getImageFile$default(FileUtil.INSTANCE, this.mFileDir, null, 2, null);
        if (file != null && file.exists()) {
            Intent intent = IntentUtils.getCameraIntent((Context)this, file);
            this.getActivity().startActivityForResult(intent, 4281);
            return;
        }
        this.setError(R.string.error_failed_to_create_camera_image_file);
    }

    public final void delete() {
        File file = this.mCameraFile;
        if (file != null) {
            file.delete();
        }
        (File)null;
        this.mCameraFile = null;
    }

    public final void onActivityResult(int n, int n2, Intent intent) {
        if (n == 4281) {
            if (n2 == -1) {
                this.handleResult();
                return;
            }
            this.setResultCancel();
        }
    }

    @Override
    protected void onFailure() {
        this.delete();
    }

    public final void onRequestPermissionsResult(int n) {
        if (n == 4282) {
            if (this.isPermissionGranted((Context)this)) {
                this.startIntent();
                return;
            }
            String string2 = this.getString(R.string.permission_camera_denied);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"getString(R.string.permission_camera_denied)");
            this.setError(string2);
        }
    }

    @Override
    public void onRestoreInstanceState(Bundle bundle) {
        Serializable serializable = bundle != null ? bundle.getSerializable(STATE_CAMERA_FILE) : null;
        this.mCameraFile = (File)serializable;
    }

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        Intrinsics.checkNotNullParameter((Object)bundle, (String)"outState");
        bundle.putSerializable(STATE_CAMERA_FILE, (Serializable)this.mCameraFile);
    }

    public final void startIntent() {
        if (!IntentUtils.isCameraAppAvailable((Context)this)) {
            this.setError(R.string.error_camera_app_not_found);
            return;
        }
        this.checkPermission();
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\tR\u000e\u0010\n\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000b"}, d2={"Lcom/github/dhaval2404/imagepicker/provider/CameraProvider$Companion;", "", "()V", "CAMERA_INTENT_REQ_CODE", "", "PERMISSION_INTENT_REQ_CODE", "REQUIRED_PERMISSIONS", "", "", "[Ljava/lang/String;", "STATE_CAMERA_FILE", "imagepicker_release"}, k=1, mv={1, 4, 0})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

}

