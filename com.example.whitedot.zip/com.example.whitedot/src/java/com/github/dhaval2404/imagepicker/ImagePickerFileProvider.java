/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.core.content.FileProvider
 *  kotlin.Metadata
 */
package com.github.dhaval2404.imagepicker;

import androidx.core.content.FileProvider;
import kotlin.Metadata;

@Metadata(bv={1, 0, 3}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2={"Lcom/github/dhaval2404/imagepicker/ImagePickerFileProvider;", "Landroidx/core/content/FileProvider;", "()V", "imagepicker_release"}, k=1, mv={1, 4, 0})
public final class ImagePickerFileProvider
extends FileProvider {
}

