/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.os.Bundle
 *  com.github.dhaval2404.imagepicker.provider.CompressionProvider$startCompressionWorker
 *  java.io.File
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.Pair
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package com.github.dhaval2404.imagepicker.provider;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import com.github.dhaval2404.imagepicker.ImagePickerActivity;
import com.github.dhaval2404.imagepicker.provider.BaseProvider;
import com.github.dhaval2404.imagepicker.provider.CompressionProvider;
import com.github.dhaval2404.imagepicker.util.ExifDataCopier;
import com.github.dhaval2404.imagepicker.util.FileUtil;
import com.github.dhaval2404.imagepicker.util.ImageUtil;
import java.io.File;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

@Metadata(bv={1, 0, 3}, d1={"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u0015\n\u0002\b\u0004\u0018\u0000 \u001d2\u00020\u0001:\u0001\u001dB\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u001a\u0010\f\u001a\u0004\u0018\u00010\u00062\u0006\u0010\r\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\nH\u0002J\u000e\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012J\u0010\u0010\u0013\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u0012H\u0002J\u0010\u0010\u0013\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\u0006H\u0002J\u0010\u0010\u0014\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\u0006H\u0002J\b\u0010\u0015\u001a\u00020\u0016H\u0002J\u000e\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0011\u001a\u00020\u0012J\u0010\u0010\u0017\u001a\u00020\u00162\u0006\u0010\r\u001a\u00020\u0006H\u0002J\u000e\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u001a0\u0019H\u0002J\u0012\u0010\u001b\u001a\u0004\u0018\u00010\u00062\u0006\u0010\r\u001a\u00020\u0006H\u0002J\u0010\u0010\u001c\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012H\u0003R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001e"}, d2={"Lcom/github/dhaval2404/imagepicker/provider/CompressionProvider;", "Lcom/github/dhaval2404/imagepicker/provider/BaseProvider;", "activity", "Lcom/github/dhaval2404/imagepicker/ImagePickerActivity;", "(Lcom/github/dhaval2404/imagepicker/ImagePickerActivity;)V", "mFileDir", "Ljava/io/File;", "mMaxFileSize", "", "mMaxHeight", "", "mMaxWidth", "applyCompression", "file", "attempt", "compress", "", "uri", "Landroid/net/Uri;", "getSizeDiff", "handleResult", "isCompressEnabled", "", "isCompressionRequired", "resolutionList", "", "", "startCompression", "startCompressionWorker", "Companion", "imagepicker_release"}, k=1, mv={1, 4, 0})
public final class CompressionProvider
extends BaseProvider {
    public static final Companion Companion = new Companion(null);
    private static final String TAG = CompressionProvider.class.getSimpleName();
    private final File mFileDir;
    private final long mMaxFileSize;
    private final int mMaxHeight;
    private final int mMaxWidth;

    public CompressionProvider(ImagePickerActivity imagePickerActivity) {
        Intrinsics.checkNotNullParameter((Object)((Object)imagePickerActivity), (String)"activity");
        super(imagePickerActivity);
        Intent intent = imagePickerActivity.getIntent();
        Intrinsics.checkNotNullExpressionValue((Object)intent, (String)"activity.intent");
        Bundle bundle = intent.getExtras();
        if (bundle == null) {
            bundle = new Bundle();
        }
        Intrinsics.checkNotNullExpressionValue((Object)bundle, (String)"activity.intent.extras ?: Bundle()");
        this.mMaxWidth = bundle.getInt("extra.max_width", 0);
        this.mMaxHeight = bundle.getInt("extra.max_height", 0);
        this.mMaxFileSize = bundle.getLong("extra.image_max_size", 0L);
        this.mFileDir = this.getFileDir(bundle.getString("extra.save_directory"));
    }

    public static final /* synthetic */ void access$handleResult(CompressionProvider compressionProvider, File file) {
        compressionProvider.handleResult(file);
    }

    public static final /* synthetic */ File access$startCompression(CompressionProvider compressionProvider, File file) {
        return compressionProvider.startCompression(file);
    }

    private final File applyCompression(File file, int n) {
        int n2;
        File file2;
        String string2;
        List<int[]> list = this.resolutionList();
        if (n >= list.size()) {
            return null;
        }
        int[] arrn = (int[])list.get(n);
        int n3 = arrn[0];
        int n4 = arrn[1];
        int n5 = this.mMaxWidth;
        if (n5 > 0 && (n2 = this.mMaxHeight) > 0 && (n3 > n5 || n4 > n2)) {
            n4 = this.mMaxHeight;
            n3 = this.mMaxWidth;
        }
        Bitmap.CompressFormat compressFormat = Bitmap.CompressFormat.JPEG;
        String string3 = file.getAbsolutePath();
        Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"file.absolutePath");
        if (StringsKt.endsWith$default((String)string3, (String)".png", (boolean)false, (int)2, null)) {
            compressFormat = Bitmap.CompressFormat.PNG;
        }
        if ((file2 = FileUtil.INSTANCE.getImageFile(this.mFileDir, string2 = FileUtil.INSTANCE.getImageExtension(file))) != null) {
            ImageUtil imageUtil = ImageUtil.INSTANCE;
            float f = n3;
            float f2 = n4;
            String string4 = file2.getAbsolutePath();
            Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"compressFile.absolutePath");
            return imageUtil.compressImage(file, f, f2, compressFormat, string4);
        }
        return null;
    }

    private final long getSizeDiff(Uri uri) {
        return FileUtil.INSTANCE.getImageSize((Context)this, uri) - this.mMaxFileSize;
    }

    private final long getSizeDiff(File file) {
        return file.length() - this.mMaxFileSize;
    }

    private final void handleResult(File file) {
        ImagePickerActivity imagePickerActivity = this.getActivity();
        Uri uri = Uri.fromFile((File)file);
        Intrinsics.checkNotNullExpressionValue((Object)uri, (String)"Uri.fromFile(file)");
        imagePickerActivity.setCompressedImage(uri);
    }

    private final boolean isCompressEnabled() {
        return this.mMaxFileSize > 0L;
    }

    private final boolean isCompressionRequired(File file) {
        boolean bl = this.isCompressEnabled();
        boolean bl2 = true;
        boolean bl3 = bl && this.getSizeDiff(file) > 0L ? bl2 : false;
        if (!bl3 && this.mMaxWidth > 0 && this.mMaxHeight > 0) {
            Pair<Integer, Integer> pair = FileUtil.INSTANCE.getImageResolution(file);
            if (((Number)pair.getFirst()).intValue() <= this.mMaxWidth) {
                if (((Number)pair.getSecond()).intValue() > this.mMaxHeight) {
                    return bl2;
                }
                bl2 = false;
            }
            return bl2;
        }
        return bl3;
    }

    private final List<int[]> resolutionList() {
        return CollectionsKt.listOf((Object[])new int[][]{{2448, 3264}, {2008, 3032}, {1944, 2580}, {1680, 2240}, {1536, 2048}, {1200, 1600}, {1024, 1392}, {960, 1280}, {768, 1024}, {600, 800}, {480, 640}, {240, 320}, {120, 160}, {60, 80}, {30, 40}});
    }

    private final File startCompression(File file) {
        File file2 = null;
        int n = 0;
        int n2 = 0;
        do {
            if (file2 != null) {
                file2.delete();
            }
            if ((file2 = this.applyCompression(file, n)) == null) {
                if (n > 0) {
                    return this.applyCompression(file, n2);
                }
                return null;
            }
            n2 = n++;
            if (this.mMaxFileSize <= 0L) continue;
            long l = this.getSizeDiff(file2);
            int n3 = l > (long)1048576 ? 3 : (l > (long)512000 ? 2 : 1);
            n += n3;
        } while (this.isCompressionRequired(file2));
        ExifDataCopier.INSTANCE.copyExif(file, file2);
        return file2;
    }

    private final void startCompressionWorker(Uri uri) {
        new AsyncTask<Uri, Void, File>(this){
            final /* synthetic */ CompressionProvider this$0;
            {
                this.this$0 = compressionProvider;
            }

            protected /* varargs */ File doInBackground(Uri ... arruri) {
                Intrinsics.checkNotNullParameter((Object)arruri, (String)"params");
                File file = FileUtil.INSTANCE.getTempFile((Context)this.this$0, arruri[0]);
                if (file != null) {
                    return CompressionProvider.access$startCompression(this.this$0, file);
                }
                return null;
            }

            protected void onPostExecute(File file) {
                super.onPostExecute((Object)file);
                if (file != null) {
                    CompressionProvider.access$handleResult(this.this$0, file);
                    return;
                }
                this.this$0.setError(com.github.dhaval2404.imagepicker.R$string.error_failed_to_compress_image);
            }
        }.execute((Object[])new Uri[]{uri});
    }

    public final void compress(Uri uri) {
        Intrinsics.checkNotNullParameter((Object)uri, (String)"uri");
        this.startCompressionWorker(uri);
    }

    public final boolean isCompressionRequired(Uri uri) {
        Intrinsics.checkNotNullParameter((Object)uri, (String)"uri");
        boolean bl = this.isCompressEnabled();
        boolean bl2 = true;
        boolean bl3 = bl && this.getSizeDiff(uri) > 0L ? bl2 : false;
        if (!bl3 && this.mMaxWidth > 0 && this.mMaxHeight > 0) {
            Pair<Integer, Integer> pair = FileUtil.INSTANCE.getImageResolution((Context)this, uri);
            if (((Number)pair.getFirst()).intValue() <= this.mMaxWidth) {
                if (((Number)pair.getSecond()).intValue() > this.mMaxHeight) {
                    return bl2;
                }
                bl2 = false;
            }
            return bl2;
        }
        return bl3;
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u0016\u0010\u0003\u001a\n \u0005*\u0004\u0018\u00010\u00040\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0006"}, d2={"Lcom/github/dhaval2404/imagepicker/provider/CompressionProvider$Companion;", "", "()V", "TAG", "", "kotlin.jvm.PlatformType", "imagepicker_release"}, k=1, mv={1, 4, 0})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

}

