/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.intuit.ssp;

public final class R {
    private R() {
    }

    public static final class dimen {
        public static final int _100ssp = 2131165185;
        public static final int _10ssp = 2131165196;
        public static final int _11ssp = 2131165208;
        public static final int _12ssp = 2131165220;
        public static final int _13ssp = 2131165232;
        public static final int _14ssp = 2131165244;
        public static final int _15ssp = 2131165256;
        public static final int _16ssp = 2131165268;
        public static final int _17ssp = 2131165280;
        public static final int _18ssp = 2131165292;
        public static final int _19ssp = 2131165304;
        public static final int _1ssp = 2131165306;
        public static final int _20ssp = 2131165318;
        public static final int _21ssp = 2131165330;
        public static final int _22ssp = 2131165342;
        public static final int _23ssp = 2131165354;
        public static final int _24ssp = 2131165366;
        public static final int _25ssp = 2131165378;
        public static final int _26ssp = 2131165390;
        public static final int _27ssp = 2131165402;
        public static final int _28ssp = 2131165414;
        public static final int _29ssp = 2131165426;
        public static final int _2ssp = 2131165428;
        public static final int _30ssp = 2131165440;
        public static final int _31ssp = 2131165452;
        public static final int _32ssp = 2131165464;
        public static final int _33ssp = 2131165476;
        public static final int _34ssp = 2131165488;
        public static final int _35ssp = 2131165500;
        public static final int _36ssp = 2131165512;
        public static final int _37ssp = 2131165524;
        public static final int _38ssp = 2131165536;
        public static final int _39ssp = 2131165548;
        public static final int _3ssp = 2131165550;
        public static final int _40ssp = 2131165562;
        public static final int _41ssp = 2131165574;
        public static final int _42ssp = 2131165586;
        public static final int _43ssp = 2131165598;
        public static final int _44ssp = 2131165610;
        public static final int _45ssp = 2131165622;
        public static final int _46ssp = 2131165634;
        public static final int _47ssp = 2131165646;
        public static final int _48ssp = 2131165658;
        public static final int _49ssp = 2131165670;
        public static final int _4ssp = 2131165672;
        public static final int _50ssp = 2131165684;
        public static final int _51ssp = 2131165696;
        public static final int _52ssp = 2131165708;
        public static final int _53ssp = 2131165720;
        public static final int _54ssp = 2131165732;
        public static final int _55ssp = 2131165744;
        public static final int _56ssp = 2131165756;
        public static final int _57ssp = 2131165768;
        public static final int _58ssp = 2131165780;
        public static final int _59ssp = 2131165792;
        public static final int _5ssp = 2131165794;
        public static final int _60ssp = 2131165797;
        public static final int _61ssp = 2131165799;
        public static final int _62ssp = 2131165801;
        public static final int _63ssp = 2131165803;
        public static final int _64ssp = 2131165805;
        public static final int _65ssp = 2131165807;
        public static final int _66ssp = 2131165809;
        public static final int _67ssp = 2131165811;
        public static final int _68ssp = 2131165813;
        public static final int _69ssp = 2131165815;
        public static final int _6ssp = 2131165817;
        public static final int _70ssp = 2131165819;
        public static final int _71ssp = 2131165821;
        public static final int _72ssp = 2131165823;
        public static final int _73ssp = 2131165825;
        public static final int _74ssp = 2131165827;
        public static final int _75ssp = 2131165829;
        public static final int _76ssp = 2131165831;
        public static final int _77ssp = 2131165833;
        public static final int _78ssp = 2131165835;
        public static final int _79ssp = 2131165837;
        public static final int _7ssp = 2131165839;
        public static final int _80ssp = 2131165841;
        public static final int _81ssp = 2131165843;
        public static final int _82ssp = 2131165845;
        public static final int _83ssp = 2131165847;
        public static final int _84ssp = 2131165849;
        public static final int _85ssp = 2131165851;
        public static final int _86ssp = 2131165853;
        public static final int _87ssp = 2131165855;
        public static final int _88ssp = 2131165857;
        public static final int _89ssp = 2131165859;
        public static final int _8ssp = 2131165861;
        public static final int _90ssp = 2131165863;
        public static final int _91ssp = 2131165865;
        public static final int _92ssp = 2131165867;
        public static final int _93ssp = 2131165869;
        public static final int _94ssp = 2131165871;
        public static final int _95ssp = 2131165873;
        public static final int _96ssp = 2131165875;
        public static final int _97ssp = 2131165877;
        public static final int _98ssp = 2131165879;
        public static final int _99ssp = 2131165881;
        public static final int _9ssp = 2131165883;

        private dimen() {
        }
    }

    public static final class id {
        public static final int give_us_a_review_landmine_button = 2131362051;
        public static final int give_us_a_review_landmine_main_layout = 2131362052;
        public static final int give_us_a_review_landmine_text_1 = 2131362053;
        public static final int give_us_a_review_landmine_text_2 = 2131362054;

        private id() {
        }
    }

    public static final class layout {
        public static final int sp_example = 2131558523;
        public static final int ssp_example = 2131558524;

        private layout() {
        }
    }

}

