/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.example.whitedot;

public final class R {
    private R() {
    }

    public static final class array {
        public static final int com_google_android_gms_fonts_certs = 2130903040;
        public static final int com_google_android_gms_fonts_certs_dev = 2130903041;
        public static final int com_google_android_gms_fonts_certs_prod = 2130903042;
        public static final int preloaded_fonts = 2130903043;
        public static final int themes = 2130903044;

        private array() {
        }
    }

    public static final class color {
        public static final int black = 2131099681;
        public static final int color1 = 2131099699;
        public static final int color3 = 2131099700;
        public static final int color4 = 2131099701;
        public static final int color5 = 2131099702;
        public static final int purple_200 = 2131099860;
        public static final int purple_500 = 2131099861;
        public static final int purple_700 = 2131099862;
        public static final int shimme2r = 2131099869;
        public static final int shimmer = 2131099870;
        public static final int shimmerbackground = 2131099872;
        public static final int teal_200 = 2131099879;
        public static final int teal_700 = 2131099880;
        public static final int white = 2131099910;

        private color() {
        }
    }

    public static final class drawable {
        public static final int add = 2131230806;
        public static final int background_image = 2131230809;
        public static final int baseline_brightness_1_24 = 2131230810;
        public static final int baseline_brush_24 = 2131230811;
        public static final int baseline_calendar_month_24 = 2131230812;
        public static final int baseline_cancel_schedule_send_24 = 2131230813;
        public static final int baseline_celebration_24 = 2131230814;
        public static final int baseline_control_point_24 = 2131230815;
        public static final int baseline_crop_24 = 2131230816;
        public static final int baseline_data_saver_off_24 = 2131230817;
        public static final int baseline_done_24 = 2131230818;
        public static final int baseline_hive_24 = 2131230819;
        public static final int baseline_keyboard_arrow_left_24 = 2131230820;
        public static final int baseline_live_tv_24 = 2131230821;
        public static final int baseline_location_on_24 = 2131230822;
        public static final int baseline_rocket_launch_24 = 2131230823;
        public static final int baseline_school_24 = 2131230824;
        public static final int baseline_send_24 = 2131230825;
        public static final int baseline_sentiment_very_satisfied_24 = 2131230826;
        public static final int baseline_thumb_down_24 = 2131230827;
        public static final int baseline_thumb_up_24 = 2131230828;
        public static final int bottom_bar = 2131230829;
        public static final int bottom_sheet = 2131230830;
        public static final int button_back = 2131230839;
        public static final int button_drawable = 2131230840;
        public static final int clip = 2131230841;
        public static final int dot = 2131230867;
        public static final int file = 2131232251;
        public static final int file2 = 2131232252;
        public static final int google = 2131232253;
        public static final int ic_baseline_call_24 = 2131232258;
        public static final int ic_baseline_chat_bubble_24 = 2131232259;
        public static final int ic_baseline_clear_24 = 2131232260;
        public static final int ic_baseline_color_lens_24 = 2131232261;
        public static final int ic_baseline_email_24 = 2131232262;
        public static final int ic_baseline_forum_24 = 2131232263;
        public static final int ic_baseline_lock_24 = 2131232264;
        public static final int ic_baseline_login_24 = 2131232265;
        public static final int ic_baseline_menu_24 = 2131232266;
        public static final int ic_baseline_person_24 = 2131232267;
        public static final int ic_baseline_person_add_24 = 2131232268;
        public static final int ic_baseline_person_outline_24 = 2131232269;
        public static final int ic_baseline_photo_24 = 2131232270;
        public static final int ic_baseline_power_settings_new_24 = 2131232271;
        public static final int ic_baseline_remove_red_eye_24 = 2131232272;
        public static final int ic_baseline_settings_24 = 2131232273;
        public static final int ic_launcher_background = 2131232280;
        public static final int ic_launcher_foreground = 2131232281;
        public static final int icon = 2131232290;
        public static final int imagebs = 2131232291;
        public static final int input_back = 2131232292;
        public static final int l = 2131232294;
        public static final int linear_back = 2131232295;
        public static final int live = 2131232296;
        public static final int loading = 2131232297;
        public static final int loading_animation = 2131232298;
        public static final int off = 2131232322;
        public static final int person = 2131232353;
        public static final int receiver_message_layout = 2131232354;
        public static final int send_message_input = 2131232363;
        public static final int sender_message_layout = 2131232364;
        public static final int setting_btn2 = 2131232365;
        public static final int settings_btn = 2131232366;
        public static final int wall = 2131232393;
        public static final int white_circle = 2131232394;
        public static final int word = 2131232395;

        private drawable() {
        }
    }

    public static final class font {
        public static final int aref_ruqaa = 2131296256;
        public static final int average = 2131296257;

        private font() {
        }
    }

    public static final class id {
        public static final int Chat = 2131361796;
        public static final int Friends = 2131361799;
        public static final int MessageBox = 2131361801;
        public static final int Options = 2131361803;
        public static final int Profile = 2131361804;
        public static final int ReceiverName = 2131361805;
        public static final int Request = 2131361806;
        public static final int SEND_FILES = 2131361807;
        public static final int SignInBtn = 2131361813;
        public static final int Status = 2131361814;
        public static final int Update_profile = 2131361817;
        public static final int accept_req = 2131361819;
        public static final int addStory = 2131361877;
        public static final int all_friends_rv = 2131361884;
        public static final int all_story_rv = 2131361885;
        public static final int back = 2131361897;
        public static final int bottom_navigation = 2131361906;
        public static final int bottom_sheet = 2131361907;
        public static final int bottom_sheet2 = 2131361908;
        public static final int btnaccept = 2131361919;
        public static final int btndecline = 2131361920;
        public static final int chatActivity = 2131361933;
        public static final int cnf = 2131361948;
        public static final int cnf_sent = 2131361949;
        public static final int createAccount = 2131361962;
        public static final int date_time = 2131361970;
        public static final int decline_req = 2131361973;
        public static final int decline_request = 2131361974;
        public static final int dismiss2 = 2131361992;
        public static final int document = 2131361993;
        public static final int emoji = 2131362008;
        public static final int etConfirmPassword = 2131362025;
        public static final int etEmail = 2131362026;
        public static final int etPassword = 2131362027;
        public static final int etStatus = 2131362028;
        public static final int etUsername = 2131362029;
        public static final int find = 2131362038;
        public static final int fl = 2131362041;
        public static final int fragment_container = 2131362044;
        public static final int frameLayout = 2131362046;
        public static final int greendot = 2131362059;
        public static final int guideline3 = 2131362064;
        public static final int guideline5 = 2131362065;
        public static final int image = 2131362077;
        public static final int imageProfile = 2131362079;
        public static final int imageView2 = 2131362080;
        public static final int imageViewer = 2131362081;
        public static final int images = 2131362087;
        public static final int layout_image = 2131362100;
        public static final int linearLayout = 2131362110;
        public static final int linearLayout2 = 2131362111;
        public static final int logout = 2131362116;
        public static final int logout2 = 2131362117;
        public static final int messageSent = 2131362129;
        public static final int message_rv = 2131362130;
        public static final int messager_profile_img = 2131362131;
        public static final int mydrawer = 2131362163;
        public static final int name = 2131362164;
        public static final int nav_graph = 2131362165;
        public static final int nav_graph2 = 2131362166;
        public static final int profile_image = 2131362200;
        public static final int progress_bar = 2131362201;
        public static final int receiverTime = 2131362208;
        public static final int receiver_image = 2131362209;
        public static final int receiver_messsage = 2131362210;
        public static final int recyclerView_friends = 2131362212;
        public static final int rv_friend_req = 2131362224;
        public static final int rv_friends_list = 2131362225;
        public static final int searchView = 2131362237;
        public static final int send_btn = 2131362250;
        public static final int send_message = 2131362251;
        public static final int senderTime = 2131362252;
        public static final int sender_image = 2131362253;
        public static final int sender_message = 2131362254;
        public static final int sendtoAddFriend = 2131362255;
        public static final int signUpBtn = 2131362262;
        public static final int status = 2131362293;
        public static final int statusCircleCount = 2131362294;
        public static final int status_person = 2131362296;
        public static final int story = 2131362300;
        public static final int storyType = 2131362301;
        public static final int textView = 2131362329;
        public static final int tnc = 2131362348;
        public static final int toast_cancel = 2131362349;
        public static final int toast_image = 2131362350;
        public static final int toast_layout = 2131362351;
        public static final int toast_root = 2131362352;
        public static final int toast_view = 2131362353;
        public static final int tvSignIn = 2131362369;
        public static final int tvUsername = 2131362370;
        public static final int tvstatus = 2131362371;
        public static final int userName = 2131362380;
        public static final int view = 2131362382;
        public static final int wordfile = 2131362395;

        private id() {
        }
    }

    public static final class layout {
        public static final int activity_chat = 2131558428;
        public static final int activity_chat_inner = 2131558429;
        public static final int activity_find_friends = 2131558430;
        public static final int activity_image_view = 2131558431;
        public static final int activity_main = 2131558432;
        public static final int activity_sign_in = 2131558433;
        public static final int activity_sign_up = 2131558434;
        public static final int activity_theme = 2131558435;
        public static final int activity_user_full_details = 2131558436;
        public static final int bottomsheet_dialogue = 2131558437;
        public static final int custom_message_layout = 2131558441;
        public static final int dialogue_box_accept_decline = 2131558459;
        public static final int fragment_bottom_sheet2 = 2131558464;
        public static final int fragment_chat = 2131558465;
        public static final int fragment_friends = 2131558466;
        public static final int fragment_request = 2131558467;
        public static final int fragment_status = 2131558468;
        public static final int receive_message = 2131558515;
        public static final int send_message = 2131558520;
        public static final int shimmer_layout = 2131558521;
        public static final int shimmer_layout_2 = 2131558522;
        public static final int toast_layout_calender = 2131558538;
        public static final int user_list2 = 2131558546;
        public static final int users_list = 2131558547;

        private layout() {
        }
    }

    public static final class menu {
        public static final int bottom_navigation = 2131623936;
        public static final int drawer = 2131623937;

        private menu() {
        }
    }

    public static final class mipmap {
        public static final int ic_launcher = 2131689472;
        public static final int ic_launcher_round = 2131689473;

        private mipmap() {
        }
    }

    public static final class navigation {
        public static final int nav_graph = 2131755008;
        public static final int nav_graph2 = 2131755009;

        private navigation() {
        }
    }

    public static final class string {
        public static final int app_name = 2131951645;
        public static final int close = 2131951653;
        public static final int create_new_account = 2131951673;
        public static final int default_web_client_id = 2131951674;
        public static final int gcm_defaultSenderId = 2131951690;
        public static final int google_api_key = 2131951691;
        public static final int google_app_id = 2131951692;
        public static final int google_crash_reporting_api_key = 2131951693;
        public static final int google_storage_bucket = 2131951694;
        public static final int hello_blank_fragment = 2131951695;
        public static final int open = 2131951742;
        public static final int project_id = 2131951749;

        private string() {
        }
    }

    public static final class style {
        public static final int AppBottomSheetDialogTheme = 2132017160;
        public static final int AppModalStyle = 2132017161;
        public static final int Theme_WhiteDot = 2132017612;
        public static final int green = 2132017839;
        public static final int red = 2132017840;

        private style() {
        }
    }

    public static final class xml {
        public static final int backup_rules = 2132148224;
        public static final int data_extraction_rules = 2132148225;

        private xml() {
        }
    }

}

