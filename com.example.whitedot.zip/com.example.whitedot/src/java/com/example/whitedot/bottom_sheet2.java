/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.net.Uri
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.Toast
 *  androidx.fragment.app.FragmentActivity
 *  com.google.android.gms.tasks.Continuation
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.OnFailureListener
 *  com.google.android.gms.tasks.Task
 *  com.google.android.material.bottomsheet.BottomSheetDialogFragment
 *  com.google.firebase.auth.FirebaseAuth
 *  com.google.firebase.auth.FirebaseUser
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.storage.FirebaseStorage
 *  com.google.firebase.storage.OnProgressListener
 *  com.google.firebase.storage.StorageMetadata
 *  com.google.firebase.storage.StorageReference
 *  com.google.firebase.storage.StorageTask
 *  com.google.firebase.storage.UploadTask
 *  com.google.firebase.storage.UploadTask$TaskSnapshot
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Map
 */
package com.example.whitedot;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class bottom_sheet2
extends BottomSheetDialogFragment {
    public static final String PREFS_NAME = "myPrefsFile";
    private String checker = "";
    private LinearLayout dismiss;
    private ImageView documents;
    private Uri fileUri;
    private String getMessageReceiverName;
    private ImageView images;
    private FirebaseAuth mAuth;
    private String messageReceiverId;
    private String messageSenderId;
    private String myUri = "";
    private DatabaseReference rootRef;
    private String saveDate;
    private String saveTime;
    private StorageTask upload;
    private ImageView words;

    public void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
        if (n == 11 && n2 == -1 && intent != null && intent.getData() != null) {
            this.fileUri = intent.getData();
            if (!this.checker.equals((Object)"image")) {
                StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("Document File");
                final String string2 = "Messages/" + this.messageSenderId + "/" + this.messageReceiverId;
                final String string3 = "Messages/" + this.messageReceiverId + "/" + this.messageSenderId;
                final String string4 = this.rootRef.child("Messages").child(this.messageSenderId).child(this.messageReceiverId).push().getKey();
                storageReference.child(string4 + "." + this.checker).putFile(this.fileUri).addOnCompleteListener((OnCompleteListener)new OnCompleteListener<UploadTask.TaskSnapshot>(){

                    public void onComplete(Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful()) {
                            HashMap hashMap = new HashMap();
                            hashMap.put((Object)"message", (Object)((UploadTask.TaskSnapshot)task.getResult()).getMetadata().getReference().getDownloadUrl().toString());
                            hashMap.put((Object)"name", (Object)bottom_sheet2.this.fileUri.getLastPathSegment());
                            hashMap.put((Object)"type", (Object)bottom_sheet2.this.checker);
                            hashMap.put((Object)"from", (Object)bottom_sheet2.this.messageSenderId);
                            hashMap.put((Object)"to", (Object)bottom_sheet2.this.messageReceiverId);
                            hashMap.put((Object)"messageID", (Object)string4);
                            hashMap.put((Object)"time", (Object)bottom_sheet2.this.saveTime);
                            hashMap.put((Object)"date", (Object)bottom_sheet2.this.saveDate);
                            HashMap hashMap2 = new HashMap();
                            hashMap2.put((Object)(string2 + "/" + string4), (Object)hashMap);
                            hashMap2.put((Object)(string3 + "/" + string4), (Object)hashMap);
                            bottom_sheet2.this.rootRef.updateChildren((Map)hashMap2);
                        }
                    }
                }).addOnFailureListener(new OnFailureListener(){

                    public void onFailure(Exception exception) {
                        Toast.makeText((Context)bottom_sheet2.this.getContext(), (CharSequence)exception.getMessage(), (int)0).show();
                    }
                }).addOnProgressListener((OnProgressListener)new OnProgressListener<UploadTask.TaskSnapshot>(){

                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                    }
                });
                return;
            }
            if (this.checker.equals((Object)"image")) {
                this.dismiss();
                StorageReference storageReference = FirebaseStorage.getInstance().getReference().child("images Sent");
                final String string5 = "Messages/" + this.messageSenderId + "/" + this.messageReceiverId;
                final String string6 = "Messages/" + this.messageReceiverId + "/" + this.messageSenderId;
                final String string7 = this.rootRef.child("Messages").child(this.messageSenderId).child(this.messageReceiverId).push().getKey();
                final StorageReference storageReference2 = storageReference.child(string7 + ".jpg");
                UploadTask uploadTask = storageReference2.putFile(this.fileUri);
                this.upload = uploadTask;
                uploadTask.continueWithTask(new Continuation(){

                    public Object then(Task task) throws Exception {
                        if (task.isSuccessful()) {
                            return storageReference2.getDownloadUrl();
                        }
                        throw task.getException();
                    }
                }).addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Uri>(){

                    public void onComplete(Task<Uri> task) {
                        if (task.isSuccessful()) {
                            Uri uri = (Uri)task.getResult();
                            bottom_sheet2.this.myUri = uri.toString();
                            HashMap hashMap = new HashMap();
                            hashMap.put((Object)"message", (Object)bottom_sheet2.this.myUri);
                            hashMap.put((Object)"name", (Object)bottom_sheet2.this.fileUri.getLastPathSegment());
                            hashMap.put((Object)"type", (Object)bottom_sheet2.this.checker);
                            hashMap.put((Object)"from", (Object)bottom_sheet2.this.messageSenderId);
                            hashMap.put((Object)"to", (Object)bottom_sheet2.this.messageReceiverId);
                            hashMap.put((Object)"messageID", (Object)string7);
                            hashMap.put((Object)"time", (Object)bottom_sheet2.this.saveTime);
                            hashMap.put((Object)"date", (Object)bottom_sheet2.this.saveDate);
                            HashMap hashMap2 = new HashMap();
                            hashMap2.put((Object)(string5 + "/" + string7), (Object)hashMap);
                            hashMap2.put((Object)(string6 + "/" + string7), (Object)hashMap);
                            bottom_sheet2.this.rootRef.updateChildren((Map)hashMap2).addOnCompleteListener(new OnCompleteListener(){

                                public void onComplete(Task task) {
                                    task.isSuccessful();
                                }
                            });
                        }
                    }

                });
                return;
            }
            Toast.makeText((Context)this.getContext(), (CharSequence)"Nothing selected", (int)0).show();
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        FirebaseAuth firebaseAuth;
        View view = layoutInflater.inflate(2131558464, viewGroup, false);
        this.dismiss = (LinearLayout)view.findViewById(2131361992);
        this.images = (ImageView)view.findViewById(2131362087);
        this.documents = (ImageView)view.findViewById(2131361993);
        this.words = (ImageView)view.findViewById(2131362395);
        this.rootRef = FirebaseDatabase.getInstance().getReference();
        this.mAuth = firebaseAuth = FirebaseAuth.getInstance();
        this.messageSenderId = firebaseAuth.getCurrentUser().getUid();
        this.messageReceiverId = this.getActivity().getSharedPreferences(PREFS_NAME, 0).getString("id", "userID");
        Calendar calendar = Calendar.getInstance();
        this.saveDate = new SimpleDateFormat("dd LLL yyyy").format(calendar.getTime());
        this.saveTime = new SimpleDateFormat("HH:mm").format(calendar.getTime());
        this.dismiss.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                bottom_sheet2.this.dismiss();
            }
        });
        this.images.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                bottom_sheet2.this.checker = "image";
                Intent intent = new Intent();
                intent.setAction("android.intent.action.GET_CONTENT");
                intent.setType("image/*");
                bottom_sheet2.this.startActivityForResult(Intent.createChooser((Intent)intent, (CharSequence)"select image"), 11);
            }
        });
        this.documents.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                bottom_sheet2.this.checker = "pdf";
                Intent intent = new Intent();
                intent.setAction("android.intent.action.GET_CONTENT");
                intent.setType("application/pdf");
                bottom_sheet2.this.startActivityForResult(Intent.createChooser((Intent)intent, (CharSequence)"select PDF"), 11);
            }
        });
        this.words.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                bottom_sheet2.this.checker = "docs";
                Intent intent = new Intent();
                intent.setAction("android.intent.action.GET_CONTENT");
                intent.setType("application/msword");
                bottom_sheet2.this.startActivityForResult(Intent.createChooser((Intent)intent, (CharSequence)"select MS word file"), 11);
            }
        });
        return view;
    }

}

