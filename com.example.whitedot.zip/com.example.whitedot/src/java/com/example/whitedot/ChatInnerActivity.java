/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.os.Bundle
 *  android.os.Handler
 *  android.text.Editable
 *  android.text.TextUtils
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.view.animation.Animation
 *  android.view.animation.TranslateAnimation
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.ImageView
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.fragment.app.FragmentManager
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.auth.FirebaseAuth
 *  com.google.firebase.auth.FirebaseUser
 *  com.google.firebase.database.ChildEventListener
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.database.ValueEventListener
 *  com.makeramen.roundedimageview.RoundedImageView
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  hani.momanii.supernova_emoji_library.Actions.EmojIconActions
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package com.example.whitedot;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.whitedot.MessageAdaptor;
import com.example.whitedot.Messages;
import com.example.whitedot.bottom_sheet2;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import hani.momanii.supernova_emoji_library.Actions.EmojIconActions;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatInnerActivity
extends AppCompatActivity {
    public static final String PREFS_NAME = "myPrefsFile";
    private String SenderStatus;
    private ImageView backImg;
    private String currentUID;
    private EmojIconActions emojIconActions;
    private String getMessageReceiverName;
    private String getMessageReceiverProfileImage;
    private LinearLayoutManager linearLayoutManager;
    private FirebaseAuth mAuth;
    private MessageAdaptor messageAdaptor;
    private EditText messageBox;
    private String messageReceiverId;
    private RecyclerView messageRecyclerView;
    private String messageSenderId;
    private final List<Messages> messagesList = new ArrayList();
    private TextView name;
    private RoundedImageView profilepic;
    private DatabaseReference rootRef;
    private View rootView;
    private String saveDate;
    private String saveTime;
    private FrameLayout sendButton;
    private FrameLayout send_files;
    private TextView status;
    private ImageView tv;

    private void lastSeen() {
        this.rootRef.child("Users").child(this.messageReceiverId).addValueEventListener(new ValueEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("userState").hasChild("state")) {
                    String string2 = dataSnapshot.child("userState").child("state").getValue().toString();
                    final String string3 = dataSnapshot.child("userState").child("date").getValue().toString();
                    String string4 = dataSnapshot.child("userState").child("time").getValue().toString();
                    if (string2.equals((Object)"online")) {
                        ChatInnerActivity.this.status.setText((CharSequence)"online");
                    } else if (string2.equals((Object)"offline")) {
                        ChatInnerActivity.this.status.setText((CharSequence)("last seen " + string4));
                        ChatInnerActivity.this.status.setOnLongClickListener(new View.OnLongClickListener(){

                            public boolean onLongClick(View view) {
                                new Toast(ChatInnerActivity.this.getApplicationContext());
                                Toast.makeText((Context)ChatInnerActivity.this, (CharSequence)string3, (int)0).show();
                                return false;
                            }
                        });
                    }
                    return;
                }
                ChatInnerActivity.this.status.setText((CharSequence)"offline");
            }

        });
    }

    private void sendmessage() {
        String string2 = this.messageBox.getText().toString();
        if (TextUtils.isEmpty((CharSequence)string2)) {
            Toast.makeText((Context)this, (CharSequence)"Enter a text", (int)0).show();
            return;
        }
        String string3 = "Messages/" + this.messageSenderId + "/" + this.messageReceiverId;
        String string4 = "Messages/" + this.messageReceiverId + "/" + this.messageSenderId;
        String string5 = this.rootRef.child("Messages").child(this.messageSenderId).child(this.messageReceiverId).push().getKey();
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"message", (Object)string2);
        hashMap.put((Object)"type", (Object)"text");
        hashMap.put((Object)"from", (Object)this.messageSenderId);
        hashMap.put((Object)"to", (Object)this.messageReceiverId);
        hashMap.put((Object)"messageID", (Object)string5);
        hashMap.put((Object)"time", (Object)this.saveTime);
        hashMap.put((Object)"date", (Object)this.saveDate);
        HashMap hashMap2 = new HashMap();
        hashMap2.put((Object)(string3 + "/" + string5), (Object)hashMap);
        hashMap2.put((Object)(string4 + "/" + string5), (Object)hashMap);
        this.rootRef.updateChildren((Map)hashMap2).addOnCompleteListener(new OnCompleteListener(){

            public void onComplete(Task task) {
                if (task.isSuccessful()) {
                    ChatInnerActivity.this.tv.setVisibility(0);
                    new Handler().postDelayed(new Runnable((View)ChatInnerActivity.this.tv){
                        final /* synthetic */ View val$v;
                        {
                            this.val$v = view;
                        }

                        public void run() {
                            TranslateAnimation translateAnimation = new TranslateAnimation(0.0f, 100.0f, 0.0f, -200.0f);
                            translateAnimation.setDuration(500L);
                            translateAnimation.setFillAfter(true);
                            this.val$v.startAnimation((Animation)translateAnimation);
                            this.val$v.setVisibility(8);
                        }
                    }, (long)1000);
                }
                ChatInnerActivity.this.messageBox.setText((CharSequence)"");
            }

        });
    }

    protected void onCreate(Bundle bundle) {
        LinearLayoutManager linearLayoutManager;
        FirebaseAuth firebaseAuth;
        super.onCreate(bundle);
        this.setContentView(2131558429);
        this.name = (TextView)this.findViewById(2131361805);
        this.status = (TextView)this.findViewById(2131362293);
        this.profilepic = (RoundedImageView)this.findViewById(2131362077);
        this.sendButton = (FrameLayout)this.findViewById(2131362250);
        this.messageBox = (EditText)this.findViewById(2131361801);
        this.backImg = (ImageView)this.findViewById(2131361897);
        this.send_files = (FrameLayout)this.findViewById(2131361807);
        Calendar calendar = Calendar.getInstance();
        this.saveDate = new SimpleDateFormat("dd LLL yyyy").format(calendar.getTime());
        this.saveTime = new SimpleDateFormat("HH:mm").format(calendar.getTime());
        this.backImg.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                ChatInnerActivity.this.onBackPressed();
            }
        });
        this.mAuth = firebaseAuth = FirebaseAuth.getInstance();
        this.messageSenderId = firebaseAuth.getCurrentUser().getUid();
        this.messageRecyclerView = (RecyclerView)this.findViewById(2131362130);
        this.messageAdaptor = new MessageAdaptor((Context)this, this.messagesList);
        this.linearLayoutManager = linearLayoutManager = new LinearLayoutManager((Context)this);
        this.messageRecyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.messageRecyclerView.setAdapter((RecyclerView.Adapter)this.messageAdaptor);
        this.rootRef = FirebaseDatabase.getInstance().getReference();
        SharedPreferences sharedPreferences = this.getSharedPreferences(PREFS_NAME, 0);
        this.messageReceiverId = sharedPreferences.getString("id", "userID");
        this.getMessageReceiverProfileImage = sharedPreferences.getString("profileImge", "profileimage");
        this.getMessageReceiverName = sharedPreferences.getString("Username", "username");
        Toast.makeText((Context)this, (CharSequence)this.messageReceiverId, (int)0).show();
        this.name.setText((CharSequence)this.getMessageReceiverName);
        Picasso.get().load(this.getMessageReceiverProfileImage).into((ImageView)this.profilepic);
        this.lastSeen();
        this.tv = (ImageView)this.findViewById(2131362129);
        this.send_files.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                bottom_sheet2 bottom_sheet22 = new bottom_sheet2();
                bottom_sheet22.show(ChatInnerActivity.this.getSupportFragmentManager(), bottom_sheet22.getTag());
            }
        });
        this.sendButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                ChatInnerActivity.this.sendmessage();
            }
        });
        this.rootRef.child("Messages").child(this.messageSenderId).child(this.messageReceiverId).addChildEventListener(new ChildEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            public void onChildAdded(DataSnapshot dataSnapshot, String string2) {
                Messages messages = (Messages)dataSnapshot.getValue(Messages.class);
                ChatInnerActivity.this.messagesList.add((Object)messages);
                ChatInnerActivity.this.messageAdaptor.notifyDataSetChanged();
                int n = -1 + ChatInnerActivity.this.messageAdaptor.getItemCount();
                ChatInnerActivity.this.messageRecyclerView.scrollToPosition(n);
            }

            public void onChildChanged(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildMoved(DataSnapshot dataSnapshot, String string2) {
            }

            public void onChildRemoved(DataSnapshot dataSnapshot) {
            }
        });
    }

}

