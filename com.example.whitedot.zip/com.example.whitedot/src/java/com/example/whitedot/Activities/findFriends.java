/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.firebase.ui.database.FirebaseRecyclerAdapter
 *  com.firebase.ui.database.FirebaseRecyclerOptions
 *  com.firebase.ui.database.FirebaseRecyclerOptions$Builder
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.database.Query
 *  com.makeramen.roundedimageview.RoundedImageView
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.example.whitedot.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.whitedot.Activities.UserFullDetailsActivity;
import com.example.whitedot.ReachModel;
import com.example.whitedot.UsersAdapter;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import java.util.ArrayList;

public class findFriends
extends AppCompatActivity {
    private DatabaseReference UserRef;
    private ImageView backImg;
    ArrayList<ReachModel> reachModelArrayList;
    private RecyclerView recyclerViewFriends;
    UsersAdapter usersAdapter;

    protected void onCreate(Bundle bundle) {
        ImageView imageView;
        RecyclerView recyclerView;
        super.onCreate(bundle);
        this.setContentView(2131558430);
        this.recyclerViewFriends = recyclerView = (RecyclerView)this.findViewById(2131362212);
        recyclerView.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager((Context)this));
        this.UserRef = FirebaseDatabase.getInstance().getReference().child("Users");
        this.backImg = imageView = (ImageView)this.findViewById(2131361897);
        imageView.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                findFriends.this.onBackPressed();
            }
        });
    }

    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<ReachModel, findFriendsViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<ReachModel, findFriendsViewHolder>(new FirebaseRecyclerOptions.Builder().setQuery((Query)this.UserRef, ReachModel.class).build()){

            protected void onBindViewHolder(findFriendsViewHolder findFriendsViewHolder2, final int n, ReachModel reachModel) {
                findFriendsViewHolder2.username.setText((CharSequence)reachModel.getUsername());
                findFriendsViewHolder2.status.setText((CharSequence)reachModel.getStatus());
                Picasso.get().load(reachModel.getImage()).into((ImageView)findFriendsViewHolder2.profileImage);
                findFriendsViewHolder2.itemView.setOnClickListener(new View.OnClickListener(){

                    public void onClick(View view) {
                        String string2 = 2.this.getRef(n).getKey();
                        Intent intent = new Intent(findFriends.this.getApplicationContext(), UserFullDetailsActivity.class);
                        intent.putExtra("user_full_details", string2);
                        findFriends.this.startActivity(intent);
                    }
                });
            }

            public findFriendsViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
                return new findFriendsViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131558547, viewGroup, false));
            }

        };
        this.recyclerViewFriends.setAdapter((RecyclerView.Adapter)firebaseRecyclerAdapter);
        firebaseRecyclerAdapter.startListening();
    }

    public static class findFriendsViewHolder
    extends RecyclerView.ViewHolder {
        RoundedImageView profileImage;
        TextView status;
        TextView username;

        public findFriendsViewHolder(View view) {
            super(view);
            this.username = (TextView)view.findViewById(2131362380);
            this.status = (TextView)view.findViewById(2131362296);
            this.profileImage = (RoundedImageView)view.findViewById(2131361804);
        }
    }

}

