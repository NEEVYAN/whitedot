/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Patterns
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.ProgressBar
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.auth.AuthResult
 *  com.google.firebase.auth.FirebaseAuth
 *  com.google.firebase.auth.FirebaseUser
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.messaging.FirebaseMessaging
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.example.whitedot.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.whitedot.Activities.ChatActivity;
import com.example.whitedot.Activities.SignUpActivity;
import com.example.whitedot.databinding.ActivitySignInBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SignInActivity
extends AppCompatActivity {
    private ActivitySignInBinding binding;
    private FirebaseAuth mAuth;
    private DatabaseReference userRef;

    private void Progressbar(boolean bl) {
        if (bl) {
            this.binding.SignInBtn.setVisibility(4);
            this.binding.progressBar.setVisibility(0);
            return;
        }
        this.binding.SignInBtn.setVisibility(0);
        this.binding.progressBar.setVisibility(4);
    }

    private void SendUserToChatActivity() {
        Intent intent = new Intent(this.getApplicationContext(), ChatActivity.class);
        intent.addFlags(268468224);
        this.startActivity(intent);
    }

    private boolean isCorrectSignInDetails() {
        if (this.binding.etEmail.getText().toString().trim().isEmpty()) {
            this.showToast("Enter Email");
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher((CharSequence)this.binding.etEmail.getText().toString()).matches()) {
            this.showToast("Enter Valid Email");
            return false;
        }
        if (this.binding.etPassword.getText().toString().trim().isEmpty()) {
            this.showToast("Enter Password");
            return false;
        }
        return true;
    }

    private void showToast(String string2) {
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)string2, (int)0).show();
    }

    private void signIn() {
        this.Progressbar(true);
        this.mAuth.signInWithEmailAndPassword(this.binding.etEmail.getText().toString(), this.binding.etPassword.getText().toString()).addOnCompleteListener((OnCompleteListener)new OnCompleteListener<AuthResult>(){

            public void onComplete(Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    String string2 = SignInActivity.this.mAuth.getCurrentUser().getUid();
                    String string3 = FirebaseMessaging.getInstance().getToken().toString();
                    SignInActivity.this.userRef.child(string2).child("device_token").setValue((Object)string3).addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                        public void onComplete(Task<Void> task) {
                            if (task.isSuccessful()) {
                                SignInActivity.this.Progressbar(false);
                                SignInActivity.this.SendUserToChatActivity();
                                SignInActivity.this.showToast("Login Successful");
                            }
                        }
                    });
                    return;
                }
                SignInActivity.this.Progressbar(false);
                SignInActivity.this.showToast("Login Failed");
            }

        });
    }

    protected void onCreate(Bundle bundle) {
        ActivitySignInBinding activitySignInBinding;
        super.onCreate(bundle);
        this.binding = activitySignInBinding = ActivitySignInBinding.inflate(this.getLayoutInflater());
        this.setContentView((View)activitySignInBinding.getRoot());
        this.mAuth = FirebaseAuth.getInstance();
        this.userRef = FirebaseDatabase.getInstance().getReference().child("Users");
        this.binding.createAccount.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                SignInActivity.this.startActivity(new Intent(SignInActivity.this.getApplicationContext(), SignUpActivity.class));
            }
        });
        this.binding.SignInBtn.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (SignInActivity.this.isCorrectSignInDetails()) {
                    SignInActivity.this.signIn();
                }
            }
        });
    }

    protected void onStart() {
        super.onStart();
        if (this.mAuth.getCurrentUser() != null) {
            this.SendUserToChatActivity();
        }
    }

}

