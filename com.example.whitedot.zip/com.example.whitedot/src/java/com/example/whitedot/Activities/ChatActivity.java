/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.MenuItem
 *  android.view.View
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentManager
 *  androidx.fragment.app.FragmentTransaction
 *  com.google.android.gms.tasks.Task
 *  com.google.android.material.bottomnavigation.BottomNavigationView
 *  com.google.android.material.bottomnavigation.BottomNavigationView$OnNavigationItemSelectedListener
 *  com.google.firebase.auth.FirebaseAuth
 *  com.google.firebase.auth.FirebaseUser
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Map
 */
package com.example.whitedot.Activities;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.example.whitedot.Activities.SignInActivity;
import com.example.whitedot.FriendsFragment;
import com.example.whitedot.RequestFragment;
import com.example.whitedot.StatusFragment;
import com.example.whitedot.chatFragment;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class ChatActivity
extends AppCompatActivity {
    private String currentUID;
    private FirebaseAuth mAuth;
    BottomNavigationView navigationView;
    private DatabaseReference rootRef;

    private void SendUserToSignIn() {
        this.startActivity(new Intent(this.getApplicationContext(), SignInActivity.class));
    }

    private void showToast(String string2) {
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)string2, (int)0).show();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131558428);
        this.navigationView = (BottomNavigationView)this.findViewById(2131361906);
        this.mAuth = FirebaseAuth.getInstance();
        this.rootRef = FirebaseDatabase.getInstance().getReference();
        this.getSupportFragmentManager().beginTransaction().replace(2131362044, (Fragment)new chatFragment()).commit();
        this.navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener(){

            public boolean onNavigationItemSelected(MenuItem menuItem) {
                Fragment fragment;
                switch (menuItem.getItemId()) {
                    default: {
                        fragment = null;
                        break;
                    }
                    case 2131361814: {
                        fragment = new StatusFragment();
                        break;
                    }
                    case 2131361806: {
                        fragment = new RequestFragment();
                        break;
                    }
                    case 2131361799: {
                        fragment = new FriendsFragment();
                        break;
                    }
                    case 2131361796: {
                        fragment = new chatFragment();
                    }
                }
                ChatActivity.this.getSupportFragmentManager().beginTransaction().replace(2131362044, fragment).commit();
                return true;
            }
        });
        this.updateStatus("online");
    }

    protected void onDestroy() {
        FirebaseUser firebaseUser = this.mAuth.getCurrentUser();
        super.onDestroy();
        if (firebaseUser != null) {
            this.updateStatus("offline");
        }
    }

    protected void onStop() {
        FirebaseUser firebaseUser = this.mAuth.getCurrentUser();
        super.onStop();
        if (firebaseUser != null) {
            this.updateStatus("offline");
        }
    }

    public void updateStatus(String string2) {
        Calendar calendar = Calendar.getInstance();
        String string3 = new SimpleDateFormat("dd LLL yyyy").format(calendar.getTime());
        String string4 = new SimpleDateFormat("HH:mm").format(calendar.getTime());
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"time", (Object)string4);
        hashMap.put((Object)"date", (Object)string3);
        hashMap.put((Object)"state", (Object)string2);
        this.currentUID = this.mAuth.getCurrentUser().getUid();
        this.rootRef.child("Users").child(this.currentUID).child("userState").updateChildren((Map)hashMap);
    }

}

