/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Patterns
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.ProgressBar
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.AppCompatActivity
 *  com.github.dhaval2404.imagepicker.ImagePicker
 *  com.github.dhaval2404.imagepicker.ImagePicker$Builder
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.OnSuccessListener
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.auth.AuthResult
 *  com.google.firebase.auth.FirebaseAuth
 *  com.google.firebase.auth.FirebaseUser
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.messaging.FirebaseMessaging
 *  com.google.firebase.storage.FirebaseStorage
 *  com.google.firebase.storage.StorageReference
 *  com.google.firebase.storage.StorageTask
 *  com.google.firebase.storage.UploadTask
 *  com.google.firebase.storage.UploadTask$TaskSnapshot
 *  com.makeramen.roundedimageview.RoundedImageView
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.HashMap
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.example.whitedot.Activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.whitedot.Activities.ChatActivity;
import com.example.whitedot.Activities.SignInActivity;
import com.example.whitedot.databinding.ActivitySignUpBinding;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.makeramen.roundedimageview.RoundedImageView;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SignUpActivity
extends AppCompatActivity {
    private static final int GallaryNumber = 1;
    private final String StringImage = "sampleCropImage";
    private ActivitySignUpBinding binding;
    private String currentUserID;
    private DatabaseReference dbref;
    private Uri imageuri;
    private FirebaseAuth mAuth;
    private StorageReference profileImageReference;

    private void Progressbar(boolean bl) {
        if (bl) {
            this.binding.signUpBtn.setVisibility(4);
            this.binding.progressBar.setVisibility(0);
            return;
        }
        this.binding.signUpBtn.setVisibility(0);
        this.binding.progressBar.setVisibility(4);
    }

    private void SignUptoChatActivity() {
        Intent intent = new Intent(this.getApplicationContext(), ChatActivity.class);
        intent.addFlags(268468224);
        this.startActivity(intent);
        this.finish();
    }

    static /* synthetic */ ActivitySignUpBinding access$400(SignUpActivity signUpActivity) {
        return signUpActivity.binding;
    }

    private Boolean isCorrectSignUpDetails() {
        Uri uri = this.imageuri;
        Boolean bl = false;
        if (uri == null) {
            this.showToast("Select Profile Image");
            return bl;
        }
        if (this.binding.etUsername.getText().toString().trim().isEmpty()) {
            this.showToast("Enter Username");
            return bl;
        }
        if (this.binding.etEmail.getText().toString().trim().isEmpty()) {
            this.showToast("Enter Email");
            return bl;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher((CharSequence)this.binding.etEmail.getText().toString()).matches()) {
            this.showToast("Enter Valid Email");
            return bl;
        }
        if (this.binding.etPassword.getText().toString().trim().isEmpty()) {
            this.showToast("Enter Password");
            return bl;
        }
        if (this.binding.etConfirmPassword.getText().toString().trim().isEmpty()) {
            this.showToast("Enter confirm Password");
            return bl;
        }
        if (!this.binding.etConfirmPassword.getText().toString().equals((Object)this.binding.etPassword.getText().toString())) {
            this.showToast("password does not match");
            return bl;
        }
        if (this.binding.etStatus.getText().toString().trim().isEmpty()) {
            this.showToast("Enter Status");
            return bl;
        }
        return true;
    }

    private void showToast(String string2) {
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)string2, (int)0).show();
    }

    private void signup() {
        this.Progressbar(true);
        this.mAuth.createUserWithEmailAndPassword(this.binding.etEmail.getText().toString(), this.binding.etPassword.getText().toString()).addOnCompleteListener((OnCompleteListener)new OnCompleteListener<AuthResult>(){

            public void onComplete(Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    String string2 = FirebaseMessaging.getInstance().getToken().toString();
                    SignUpActivity signUpActivity = SignUpActivity.this;
                    signUpActivity.currentUserID = signUpActivity.mAuth.getCurrentUser().getUid();
                    HashMap hashMap = new HashMap();
                    hashMap.put((Object)"uid", (Object)SignUpActivity.this.currentUserID);
                    hashMap.put((Object)"username", (Object)SignUpActivity.access$400((SignUpActivity)SignUpActivity.this).etUsername.getText().toString());
                    hashMap.put((Object)"status", (Object)SignUpActivity.access$400((SignUpActivity)SignUpActivity.this).etStatus.getText().toString());
                    SignUpActivity.this.dbref.child("Users").child(SignUpActivity.this.currentUserID).setValue((Object)hashMap).addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                        public void onComplete(Task<Void> task) {
                            if (task.isSuccessful()) {
                                SignUpActivity.this.Progressbar(false);
                                SignUpActivity.this.showToast("Account Created");
                                SignUpActivity.this.SignUptoChatActivity();
                            }
                        }
                    });
                    SignUpActivity.this.dbref.child("Users").child(SignUpActivity.this.currentUserID).child("device_token").setValue((Object)string2);
                    final StorageReference storageReference = SignUpActivity.this.profileImageReference.child(SignUpActivity.this.currentUserID + ".jpg");
                    storageReference.putFile(SignUpActivity.this.imageuri).addOnSuccessListener((OnSuccessListener)new OnSuccessListener<UploadTask.TaskSnapshot>(){

                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            storageReference.getDownloadUrl().addOnSuccessListener((OnSuccessListener)new OnSuccessListener<Uri>(){

                                public void onSuccess(Uri uri) {
                                    SignUpActivity.this.dbref.child("Users").child(SignUpActivity.this.currentUserID).child("image").setValue((Object)uri.toString());
                                }
                            });
                        }

                    });
                    return;
                }
                SignUpActivity.this.Progressbar(false);
                SignUpActivity.this.showToast("Account Failed To Create");
            }

        });
    }

    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
        this.imageuri = intent.getData();
        this.binding.imageProfile.setImageURI(this.imageuri);
        this.binding.image.setVisibility(4);
    }

    protected void onCreate(Bundle bundle) {
        ActivitySignUpBinding activitySignUpBinding;
        super.onCreate(bundle);
        this.binding = activitySignUpBinding = ActivitySignUpBinding.inflate(this.getLayoutInflater());
        this.setContentView((View)activitySignUpBinding.getRoot());
        this.mAuth = FirebaseAuth.getInstance();
        this.dbref = FirebaseDatabase.getInstance().getReference();
        this.profileImageReference = FirebaseStorage.getInstance().getReference().child("profileImage");
        this.binding.imageProfile.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                ImagePicker.with((Activity)SignUpActivity.this).crop().compress(1024).maxResultSize(512, 512).start(1);
            }
        });
        this.binding.tvSignIn.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                SignUpActivity.this.startActivity(new Intent(SignUpActivity.this.getApplicationContext(), SignInActivity.class));
            }
        });
        this.binding.signUpBtn.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (SignUpActivity.this.isCorrectSignUpDetails().booleanValue()) {
                    SignUpActivity.this.signup();
                }
            }
        });
    }

}

