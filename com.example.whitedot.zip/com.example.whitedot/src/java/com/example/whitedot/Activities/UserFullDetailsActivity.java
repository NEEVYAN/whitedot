/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.recyclerview.widget.RecyclerView
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.auth.FirebaseAuth
 *  com.google.firebase.auth.FirebaseUser
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.database.ValueEventListener
 *  com.makeramen.roundedimageview.RoundedImageView
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.HashMap
 */
package com.example.whitedot.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import java.util.HashMap;

public class UserFullDetailsActivity
extends AppCompatActivity {
    private DatabaseReference ChatRequestRef;
    private String CurrentState;
    private DatabaseReference FriendsRef;
    private TextView Name;
    private DatabaseReference NotificationRef;
    private RoundedImageView Profileimage;
    private DatabaseReference UserRef;
    private ImageView backImg;
    private TextView bio;
    private Button decline_req;
    private FirebaseAuth mAuth;
    private String receiverUID;
    private RecyclerView recyclerView;
    private String senderUID;
    private Button sendmessage;
    private Button updateprofile;

    private void AcceptRequest() {
        this.FriendsRef.child(this.senderUID).child(this.receiverUID).child("Friends").setValue((Object)"Saved").addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

            public void onComplete(Task<Void> task) {
                if (task.isSuccessful()) {
                    UserFullDetailsActivity.this.FriendsRef.child(UserFullDetailsActivity.this.receiverUID).child(UserFullDetailsActivity.this.senderUID).child("Friends").setValue((Object)"Saved").addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                        public void onComplete(Task<Void> task) {
                            if (task.isSuccessful()) {
                                UserFullDetailsActivity.this.ChatRequestRef.child(UserFullDetailsActivity.this.senderUID).child(UserFullDetailsActivity.this.receiverUID).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                    public void onComplete(Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            UserFullDetailsActivity.this.ChatRequestRef.child(UserFullDetailsActivity.this.receiverUID).child(UserFullDetailsActivity.this.senderUID).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                                public void onComplete(Task<Void> task) {
                                                    UserFullDetailsActivity.this.sendmessage.setEnabled(true);
                                                    UserFullDetailsActivity.this.CurrentState = "friends";
                                                    UserFullDetailsActivity.this.sendmessage.setText((CharSequence)"UNFRIEND");
                                                    UserFullDetailsActivity.this.decline_req.setVisibility(4);
                                                    UserFullDetailsActivity.this.decline_req.setEnabled(false);
                                                }
                                            });
                                        }
                                    }

                                });
                            }
                        }

                    });
                }
            }

        });
    }

    private void CancelRequest() {
        this.ChatRequestRef.child(this.senderUID).child(this.receiverUID).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

            public void onComplete(Task<Void> task) {
                if (task.isSuccessful()) {
                    UserFullDetailsActivity.this.ChatRequestRef.child(UserFullDetailsActivity.this.receiverUID).child(UserFullDetailsActivity.this.senderUID).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                        public void onComplete(Task<Void> task) {
                            if (task.isSuccessful()) {
                                UserFullDetailsActivity.this.sendmessage.setEnabled(true);
                                UserFullDetailsActivity.this.CurrentState = "new";
                                UserFullDetailsActivity.this.sendmessage.setText((CharSequence)"SAY HELLO!");
                                UserFullDetailsActivity.this.decline_req.setVisibility(4);
                                UserFullDetailsActivity.this.decline_req.setEnabled(false);
                            }
                        }
                    });
                }
            }

        });
    }

    private void ChatRequest() {
        this.ChatRequestRef.child(this.senderUID).addValueEventListener(new ValueEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild(UserFullDetailsActivity.this.receiverUID)) {
                    String string2 = dataSnapshot.child(UserFullDetailsActivity.this.receiverUID).child("request_type").getValue().toString();
                    if (string2.equals((Object)"Sent")) {
                        UserFullDetailsActivity.this.CurrentState = "request_sent";
                        UserFullDetailsActivity.this.sendmessage.setText((CharSequence)"CANCEL REQUEST");
                    } else if (string2.equals((Object)"received")) {
                        UserFullDetailsActivity.this.CurrentState = "request_received";
                        UserFullDetailsActivity.this.sendmessage.setText((CharSequence)"Accept Request");
                        UserFullDetailsActivity.this.decline_req.setVisibility(0);
                        UserFullDetailsActivity.this.decline_req.setEnabled(true);
                        UserFullDetailsActivity.this.decline_req.setOnClickListener(new View.OnClickListener(){

                            public void onClick(View view) {
                                UserFullDetailsActivity.this.CancelRequest();
                            }
                        });
                    }
                    return;
                }
                UserFullDetailsActivity.this.FriendsRef.child(UserFullDetailsActivity.this.senderUID).addListenerForSingleValueEvent(new ValueEventListener(){

                    public void onCancelled(DatabaseError databaseError) {
                    }

                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChild(UserFullDetailsActivity.this.receiverUID)) {
                            UserFullDetailsActivity.this.CurrentState = "friends";
                            UserFullDetailsActivity.this.sendmessage.setText((CharSequence)"UNFRIEND");
                        }
                    }
                });
            }

        });
        if (!this.senderUID.equals((Object)this.receiverUID)) {
            this.sendmessage.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    UserFullDetailsActivity.this.sendmessage.setEnabled(false);
                    if (UserFullDetailsActivity.this.CurrentState.equals((Object)"new")) {
                        UserFullDetailsActivity.this.SendChatRequest();
                    }
                    if (UserFullDetailsActivity.this.CurrentState.equals((Object)"request_sent")) {
                        UserFullDetailsActivity.this.CancelRequest();
                    }
                    if (UserFullDetailsActivity.this.CurrentState.equals((Object)"request_received")) {
                        UserFullDetailsActivity.this.AcceptRequest();
                    }
                    if (UserFullDetailsActivity.this.CurrentState.equals((Object)"friends")) {
                        UserFullDetailsActivity.this.RemoveFriend();
                    }
                }
            });
            return;
        }
        this.sendmessage.setVisibility(4);
        this.updateprofile.setVisibility(0);
    }

    private void RemoveFriend() {
        this.FriendsRef.child(this.senderUID).child(this.receiverUID).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

            public void onComplete(Task<Void> task) {
                if (task.isSuccessful()) {
                    UserFullDetailsActivity.this.FriendsRef.child(UserFullDetailsActivity.this.receiverUID).child(UserFullDetailsActivity.this.senderUID).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                        public void onComplete(Task<Void> task) {
                            if (task.isSuccessful()) {
                                UserFullDetailsActivity.this.sendmessage.setEnabled(true);
                                UserFullDetailsActivity.this.CurrentState = "new";
                                UserFullDetailsActivity.this.sendmessage.setText((CharSequence)"SAY HELLO!");
                                UserFullDetailsActivity.this.decline_req.setVisibility(4);
                                UserFullDetailsActivity.this.decline_req.setEnabled(false);
                            }
                        }
                    });
                }
            }

        });
    }

    private void SendChatRequest() {
        this.ChatRequestRef.child(this.senderUID).child(this.receiverUID).child("request_type").setValue((Object)"Sent").addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

            public void onComplete(Task<Void> task) {
                UserFullDetailsActivity.this.ChatRequestRef.child(UserFullDetailsActivity.this.receiverUID).child(UserFullDetailsActivity.this.senderUID).child("request_type").setValue((Object)"received").addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                    public void onComplete(Task<Void> task) {
                        if (task.isSuccessful()) {
                            HashMap hashMap = new HashMap();
                            hashMap.put((Object)"from", (Object)UserFullDetailsActivity.this.senderUID);
                            hashMap.put((Object)"type", (Object)"req");
                            UserFullDetailsActivity.this.NotificationRef.child(UserFullDetailsActivity.this.receiverUID).push().setValue((Object)hashMap).addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                public void onComplete(Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        UserFullDetailsActivity.this.sendmessage.setEnabled(true);
                                        UserFullDetailsActivity.this.CurrentState = "request_sent";
                                        UserFullDetailsActivity.this.sendmessage.setText((CharSequence)"CANCEL REQUEST");
                                    }
                                }
                            });
                        }
                    }

                });
            }

        });
    }

    protected void onCreate(Bundle bundle) {
        FirebaseAuth firebaseAuth;
        ImageView imageView;
        super.onCreate(bundle);
        this.setContentView(2131558436);
        this.UserRef = FirebaseDatabase.getInstance().getReference().child("Users");
        this.ChatRequestRef = FirebaseDatabase.getInstance().getReference().child("ChatRequest");
        this.FriendsRef = FirebaseDatabase.getInstance().getReference().child("Friends");
        this.NotificationRef = FirebaseDatabase.getInstance().getReference().child("Notification");
        this.backImg = imageView = (ImageView)this.findViewById(2131361897);
        imageView.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                UserFullDetailsActivity.this.onBackPressed();
            }
        });
        this.mAuth = firebaseAuth = FirebaseAuth.getInstance();
        this.senderUID = firebaseAuth.getCurrentUser().getUid();
        this.receiverUID = this.getIntent().getExtras().get("user_full_details").toString();
        this.Profileimage = (RoundedImageView)this.findViewById(2131362200);
        this.Name = (TextView)this.findViewById(2131362370);
        this.bio = (TextView)this.findViewById(2131362371);
        this.sendmessage = (Button)this.findViewById(2131362251);
        this.decline_req = (Button)this.findViewById(2131361974);
        this.updateprofile = (Button)this.findViewById(2131361817);
        this.recyclerView = (RecyclerView)this.findViewById(2131362130);
        this.CurrentState = "new";
        this.UserRef.child(this.receiverUID).addValueEventListener(new ValueEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists() && dataSnapshot.hasChild("image")) {
                    String string2 = dataSnapshot.child("image").getValue().toString();
                    String string3 = dataSnapshot.child("username").getValue().toString();
                    String string4 = dataSnapshot.child("status").getValue().toString();
                    Picasso.get().load(string2).into((ImageView)UserFullDetailsActivity.this.Profileimage);
                    UserFullDetailsActivity.this.Name.setText((CharSequence)string3);
                    UserFullDetailsActivity.this.bio.setText((CharSequence)string4);
                    UserFullDetailsActivity.this.ChatRequest();
                }
            }
        });
    }

}

