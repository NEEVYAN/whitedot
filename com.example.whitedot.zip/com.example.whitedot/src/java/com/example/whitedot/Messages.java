/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot;

public class Messages {
    private String date;
    private String from;
    private String message;
    private String messageID;
    private String name;
    private String time;
    private String to;
    private String type;

    public Messages() {
    }

    public Messages(String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9) {
        this.from = string2;
        this.message = string3;
        this.type = string4;
        this.to = string5;
        this.messageID = string6;
        this.time = string7;
        this.date = string8;
        this.name = string9;
    }

    public String getDate() {
        return this.date;
    }

    public String getFrom() {
        return this.from;
    }

    public String getMessage() {
        return this.message;
    }

    public String getMessageID() {
        return this.messageID;
    }

    public String getName() {
        return this.name;
    }

    public String getTime() {
        return this.time;
    }

    public String getTo() {
        return this.to;
    }

    public String getType() {
        return this.type;
    }

    public void setDate(String string2) {
        this.date = string2;
    }

    public void setFrom(String string2) {
        this.from = string2;
    }

    public void setMessage(String string2) {
        this.message = string2;
    }

    public void setMessageID(String string2) {
        this.messageID = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setTime(String string2) {
        this.time = string2;
    }

    public void setTo(String string2) {
        this.to = string2;
    }

    public void setType(String string2) {
        this.type = string2;
    }
}

