/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  androidx.activity.result.ActivityResultCallback
 *  androidx.activity.result.ActivityResultLauncher
 *  androidx.activity.result.contract.ActivityResultContract
 *  androidx.activity.result.contract.ActivityResultContracts
 *  androidx.activity.result.contract.ActivityResultContracts$GetContent
 *  androidx.fragment.app.Fragment
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.cooltechworks.views.shimmer.ShimmerRecyclerView
 *  com.google.android.gms.tasks.OnSuccessListener
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.auth.FirebaseAuth
 *  com.google.firebase.auth.FirebaseUser
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.database.ValueEventListener
 *  com.google.firebase.storage.FirebaseStorage
 *  com.google.firebase.storage.StorageReference
 *  com.google.firebase.storage.StorageTask
 *  com.google.firebase.storage.UploadTask
 *  com.google.firebase.storage.UploadTask$TaskSnapshot
 *  com.makeramen.roundedimageview.RoundedImageView
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.ArrayList
 *  java.util.Date
 *  java.util.Iterator
 */
package com.example.whitedot;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.example.whitedot.Story;
import com.example.whitedot.StoryAdapter;
import com.example.whitedot.UserStories;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

public class StatusFragment
extends Fragment {
    FirebaseAuth auth;
    RoundedImageView createStoryImage;
    private String currentUID;
    FirebaseDatabase database;
    ProgressDialog dialog;
    ActivityResultLauncher<String> gallaryLauncher;
    FirebaseStorage storage;
    ArrayList<Story> storyList;
    ShimmerRecyclerView storyRv;
    private DatabaseReference usersRef;

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        ShimmerRecyclerView shimmerRecyclerView;
        ProgressDialog progressDialog;
        DatabaseReference databaseReference;
        FirebaseAuth firebaseAuth;
        View view = layoutInflater.inflate(2131558468, viewGroup, false);
        this.storyRv = shimmerRecyclerView = (ShimmerRecyclerView)view.findViewById(2131361885);
        shimmerRecyclerView.showShimmerAdapter();
        this.storyList = new ArrayList();
        this.createStoryImage = (RoundedImageView)view.findViewById(2131361877);
        this.storage = FirebaseStorage.getInstance();
        this.database = FirebaseDatabase.getInstance();
        this.auth = firebaseAuth = FirebaseAuth.getInstance();
        this.currentUID = firebaseAuth.getCurrentUser().getUid();
        this.dialog = progressDialog = new ProgressDialog(this.getContext());
        progressDialog.setProgressStyle(0);
        this.dialog.setTitle((CharSequence)"Story Uplaoding");
        this.dialog.setMessage((CharSequence)"please wait......");
        this.dialog.setCancelable(false);
        this.createStoryImage.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                StatusFragment.this.gallaryLauncher.launch((Object)"image/*");
            }
        });
        this.usersRef = databaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(this.currentUID);
        databaseReference.addValueEventListener(new ValueEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild("image")) {
                    String string2 = dataSnapshot.child("image").getValue().toString();
                    Picasso.get().load(string2).fit().into((ImageView)StatusFragment.this.createStoryImage);
                }
            }
        });
        final StoryAdapter storyAdapter = new StoryAdapter(this.storyList, this.getContext());
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getContext(), 1, false);
        this.storyRv.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.storyRv.setNestedScrollingEnabled(false);
        this.database.getReference().child("stories").addValueEventListener(new ValueEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    StatusFragment.this.storyList.clear();
                    for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
                        Story story = new Story();
                        story.setStoryBy(dataSnapshot2.getKey());
                        story.setStoryAt((Long)dataSnapshot2.child("postedBy").getValue(Long.class));
                        ArrayList arrayList = new ArrayList();
                        Iterator iterator = dataSnapshot2.child("userStories").getChildren().iterator();
                        while (iterator.hasNext()) {
                            arrayList.add((Object)((UserStories)((DataSnapshot)iterator.next()).getValue(UserStories.class)));
                        }
                        story.setStories((ArrayList<UserStories>)arrayList);
                        StatusFragment.this.storyList.add((Object)story);
                    }
                    StatusFragment.this.storyRv.setAdapter((RecyclerView.Adapter)storyAdapter);
                    StatusFragment.this.storyRv.hideShimmerAdapter();
                    storyAdapter.notifyDataSetChanged();
                }
            }
        });
        this.gallaryLauncher = this.registerForActivityResult((ActivityResultContract)new ActivityResultContracts.GetContent(), (ActivityResultCallback)new ActivityResultCallback<Uri>(){

            public void onActivityResult(Uri uri) {
                StatusFragment.this.createStoryImage.setImageURI(uri);
                StatusFragment.this.dialog.show();
                final StorageReference storageReference = StatusFragment.this.storage.getReference().child("stories").child(FirebaseAuth.getInstance().getUid()).child(new Date().getTime() + "");
                storageReference.putFile(uri).addOnSuccessListener((OnSuccessListener)new OnSuccessListener<UploadTask.TaskSnapshot>(){

                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        storageReference.getDownloadUrl().addOnSuccessListener((OnSuccessListener)new OnSuccessListener<Uri>(){

                            public void onSuccess(final Uri uri) {
                                final Story story = new Story();
                                story.setStoryAt(new Date().getTime());
                                StatusFragment.this.database.getReference().child("stories").child(FirebaseAuth.getInstance().getUid()).child("postedBy").setValue((Object)story.getStoryAt()).addOnSuccessListener((OnSuccessListener)new OnSuccessListener<Void>(){

                                    public void onSuccess(Void void_) {
                                        UserStories userStories = new UserStories(uri.toString(), story.getStoryAt());
                                        StatusFragment.this.database.getReference().child("stories").child(FirebaseAuth.getInstance().getUid()).child("userStories").push().setValue((Object)userStories).addOnSuccessListener((OnSuccessListener)new OnSuccessListener<Void>(){

                                            public void onSuccess(Void void_) {
                                                StatusFragment.this.dialog.dismiss();
                                            }
                                        });
                                    }

                                });
                            }

                        });
                    }

                });
            }

        });
        return view;
    }

}

