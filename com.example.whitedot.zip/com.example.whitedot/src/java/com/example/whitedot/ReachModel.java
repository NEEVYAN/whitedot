/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot;

public class ReachModel {
    private String image;
    private String status;
    private String username;

    public ReachModel() {
    }

    public ReachModel(String string2, String string3, String string4) {
        this.username = string2;
        this.status = string3;
        this.image = string4;
    }

    public String getImage() {
        return this.image;
    }

    public String getStatus() {
        return this.status;
    }

    public String getUsername() {
        return this.username;
    }

    public void setImage(String string2) {
        this.image = string2;
    }

    public void setStatus(String string2) {
        this.status = string2;
    }

    public void setUsername(String string2) {
        this.username = string2;
    }
}

