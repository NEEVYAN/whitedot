/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.Window
 *  android.view.WindowInsets
 *  android.view.WindowInsets$Type
 *  android.view.WindowInsetsController
 *  android.widget.ImageView
 *  androidx.appcompat.app.AppCompatActivity
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.String
 */
package com.example.whitedot;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;

public class ImageViewActivity
extends AppCompatActivity {
    private String imageUrl;
    private ImageView imageViewer;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131558431);
        this.imageViewer = (ImageView)this.findViewById(2131362081);
        this.imageUrl = this.getIntent().getStringExtra("url");
        Picasso.get().load(this.imageUrl).fit().into(this.imageViewer);
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController windowInsetsController = this.getWindow().getInsetsController();
            if (windowInsetsController != null) {
                windowInsetsController.hide(WindowInsets.Type.statusBars());
                return;
            }
            this.getWindow().setFlags(1024, 1024);
        }
    }
}

