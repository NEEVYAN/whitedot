/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.DownloadManager
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.net.Uri
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.auth.FirebaseAuth
 *  com.google.firebase.auth.FirebaseUser
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.database.ValueEventListener
 *  com.makeramen.roundedimageview.RoundedImageView
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.util.List
 */
package com.example.whitedot;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.example.whitedot.ChatInnerActivity;
import com.example.whitedot.ImageViewActivity;
import com.example.whitedot.Messages;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import java.util.List;

public class MessageAdaptor
extends RecyclerView.Adapter<MessageViewHolder> {
    private Context context;
    private LayoutInflater inflater;
    private FirebaseAuth mAuth;
    private List<String> mPdfUrls;
    private DownloadManager manager;
    private List<Messages> userMessageList;
    private DatabaseReference usersRef;

    public MessageAdaptor(Context context, List<Messages> list) {
        this.context = context;
        this.inflater = LayoutInflater.from((Context)context);
        this.userMessageList = list;
    }

    private void deleteMessageForEveryone(final int n, final MessageViewHolder messageViewHolder) {
        final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.child("Messages").child(((Messages)this.userMessageList.get(n)).getTo()).child(((Messages)this.userMessageList.get(n)).getFrom()).child(((Messages)this.userMessageList.get(n)).getMessageID()).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

            public void onComplete(Task<Void> task) {
                if (task.isSuccessful()) {
                    databaseReference.child("Messages").child(((Messages)MessageAdaptor.this.userMessageList.get(n)).getFrom()).child(((Messages)MessageAdaptor.this.userMessageList.get(n)).getTo()).child(((Messages)MessageAdaptor.this.userMessageList.get(n)).getMessageID()).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                        public void onComplete(Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText((Context)messageViewHolder.itemView.getContext(), (CharSequence)"message deleted", (int)0).show();
                                return;
                            }
                            Toast.makeText((Context)MessageAdaptor.this.context, (CharSequence)"message failed to delete", (int)0).show();
                        }
                    });
                }
            }

        });
    }

    private void deleteReceivedMessage(int n, MessageViewHolder messageViewHolder) {
        FirebaseDatabase.getInstance().getReference().child("Messages").child(((Messages)this.userMessageList.get(n)).getTo()).child(((Messages)this.userMessageList.get(n)).getFrom()).child(((Messages)this.userMessageList.get(n)).getMessageID()).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

            public void onComplete(Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText((Context)MessageAdaptor.this.context, (CharSequence)"message deleted", (int)0).show();
                    return;
                }
                Toast.makeText((Context)MessageAdaptor.this.context, (CharSequence)"message failed to delete", (int)0).show();
            }
        });
    }

    private void deleteSentMessage(int n, MessageViewHolder messageViewHolder) {
        FirebaseDatabase.getInstance().getReference().child("Messages").child(((Messages)this.userMessageList.get(n)).getFrom()).child(((Messages)this.userMessageList.get(n)).getTo()).child(((Messages)this.userMessageList.get(n)).getMessageID()).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

            public void onComplete(Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText((Context)MessageAdaptor.this.context, (CharSequence)"message deleted", (int)0).show();
                    return;
                }
                Toast.makeText((Context)MessageAdaptor.this.context, (CharSequence)"message failed to delete", (int)0).show();
            }
        });
    }

    public int getItemCount() {
        return this.userMessageList.size();
    }

    public void onBindViewHolder(final MessageViewHolder messageViewHolder, final int n) {
        DatabaseReference databaseReference;
        String string2 = this.mAuth.getCurrentUser().getUid();
        final Messages messages = (Messages)this.userMessageList.get(n);
        String string3 = messages.getFrom();
        String string4 = messages.getType();
        this.usersRef = databaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(string3);
        databaseReference.addValueEventListener(new ValueEventListener(){

            public void onCancelled(DatabaseError databaseError) {
            }

            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChild("image")) {
                    String string2 = dataSnapshot.child("image").getValue().toString();
                    Picasso.get().load(string2).fit().into((ImageView)messageViewHolder.receiverProfileImage);
                }
            }
        });
        messageViewHolder.receiverTextView.setVisibility(8);
        messageViewHolder.senderMessageText.setVisibility(8);
        messageViewHolder.messageSenderImage.setVisibility(8);
        messageViewHolder.messageReceiverImage.setVisibility(8);
        messageViewHolder.senderTime.setVisibility(8);
        messageViewHolder.receiverTime.setVisibility(8);
        if (string4.equals((Object)"text")) {
            if (string3.equals((Object)string2)) {
                messageViewHolder.senderMessageText.setVisibility(0);
                messageViewHolder.senderMessageText.setText((CharSequence)messages.getMessage());
                messageViewHolder.senderMessageText.setOnLongClickListener(new View.OnLongClickListener(){

                    public boolean onLongClick(View view) {
                        if (messageViewHolder.senderTime.getVisibility() == 0) {
                            messageViewHolder.senderTime.setVisibility(8);
                            return false;
                        }
                        messageViewHolder.senderTime.setVisibility(0);
                        messageViewHolder.senderTime.setText((CharSequence)messages.getTime());
                        messageViewHolder.senderTime.setOnClickListener(new View.OnClickListener(){

                            public void onClick(View view) {
                                View view2 = MessageAdaptor.this.inflater.inflate(2131558538, null);
                                ((TextView)view2.findViewById(2131361970)).setText((CharSequence)messages.getDate());
                                Toast toast = new Toast(MessageAdaptor.this.context);
                                toast.setDuration(0);
                                toast.setView(view2);
                                toast.show();
                            }
                        });
                        return false;
                    }

                });
            } else {
                messageViewHolder.receiverTextView.setVisibility(0);
                messageViewHolder.receiverTextView.setText((CharSequence)messages.getMessage());
                messageViewHolder.receiverTextView.setOnLongClickListener(new View.OnLongClickListener(){

                    public boolean onLongClick(View view) {
                        if (messageViewHolder.receiverTime.getVisibility() == 0) {
                            messageViewHolder.receiverTime.setVisibility(8);
                            return false;
                        }
                        messageViewHolder.receiverTime.setVisibility(0);
                        messageViewHolder.receiverTime.setText((CharSequence)messages.getTime());
                        messageViewHolder.receiverTime.setOnClickListener(new View.OnClickListener(){

                            public void onClick(View view) {
                                View view2 = MessageAdaptor.this.inflater.inflate(2131558538, null);
                                ((TextView)view2.findViewById(2131361970)).setText((CharSequence)messages.getDate());
                                Toast toast = new Toast(MessageAdaptor.this.context);
                                toast.setDuration(0);
                                toast.setView(view2);
                                toast.show();
                            }
                        });
                        return false;
                    }

                });
            }
        } else if (string4.equals((Object)"image")) {
            if (string3.equals((Object)string2)) {
                messageViewHolder.messageSenderImage.setVisibility(0);
                Picasso.get().load(messages.getMessage()).placeholder(2131232292).fit().into(messageViewHolder.messageSenderImage);
            } else {
                messageViewHolder.messageReceiverImage.setVisibility(0);
                Picasso.get().load(messages.getMessage()).placeholder(2131232292).fit().into(messageViewHolder.messageReceiverImage);
            }
        } else if (string4.equals((Object)"pdf") || string4.equals((Object)"docs")) {
            if (string3.equals((Object)string2)) {
                messageViewHolder.messageSenderImage.setVisibility(0);
                Picasso.get().load("https://firebasestorage.googleapis.com/v0/b/whitedot-68104.appspot.com/o/images%20Sent%2Ffile2.png?alt=media&token=c8e2f8f1-fb53-48cc-9ba0-0f0d54a9ccc9").fit().into(messageViewHolder.messageSenderImage);
            } else {
                messageViewHolder.messageReceiverImage.setVisibility(0);
                Picasso.get().load("https://firebasestorage.googleapis.com/v0/b/whitedot-68104.appspot.com/o/images%20Sent%2Ffile2.png?alt=media&token=c8e2f8f1-fb53-48cc-9ba0-0f0d54a9ccc9").fit().into(messageViewHolder.messageReceiverImage);
                messageViewHolder.itemView.setOnClickListener(new View.OnClickListener(){

                    public void onClick(View view) {
                    }
                });
            }
        }
        if (string3.equals((Object)string2)) {
            messageViewHolder.itemView.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    if (!((Messages)MessageAdaptor.this.userMessageList.get(n)).getType().equals((Object)"pdf") && !((Messages)MessageAdaptor.this.userMessageList.get(n)).getType().equals((Object)"docs")) {
                        if (((Messages)MessageAdaptor.this.userMessageList.get(n)).getType().equals((Object)"text")) {
                            CharSequence[] arrcharSequence = new CharSequence[]{"Delete for me", "Cancel", "Delete for Everyone"};
                            AlertDialog.Builder builder = new AlertDialog.Builder(messageViewHolder.itemView.getContext());
                            builder.setTitle((CharSequence)"Delete Message");
                            builder.setItems(arrcharSequence, new DialogInterface.OnClickListener(){

                                public void onClick(DialogInterface dialogInterface, int n) {
                                    if (n == 0) {
                                        MessageAdaptor.this.deleteSentMessage(n, messageViewHolder);
                                        Intent intent = new Intent(messageViewHolder.itemView.getContext(), ChatInnerActivity.class);
                                        messageViewHolder.itemView.getContext().startActivity(intent);
                                        return;
                                    }
                                    if (n == 2) {
                                        MessageAdaptor.this.deleteMessageForEveryone(n, messageViewHolder);
                                        Intent intent = new Intent(messageViewHolder.itemView.getContext(), ChatInnerActivity.class);
                                        messageViewHolder.itemView.getContext().startActivity(intent);
                                    }
                                }
                            });
                            builder.show();
                        }
                    } else {
                        CharSequence[] arrcharSequence = new CharSequence[]{"Delete for me", "Downlaod and View", "Cancel", "Delete for Everyone"};
                        AlertDialog.Builder builder = new AlertDialog.Builder(messageViewHolder.itemView.getContext());
                        builder.setTitle((CharSequence)"Delete Message");
                        builder.setItems(arrcharSequence, new DialogInterface.OnClickListener(){

                            public void onClick(DialogInterface dialogInterface, int n) {
                                if (n == 0) {
                                    MessageAdaptor.this.deleteSentMessage(n, messageViewHolder);
                                    return;
                                }
                                if (n == 1) {
                                    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse((String)((Messages)MessageAdaptor.this.userMessageList.get(n)).getMessage()));
                                    messageViewHolder.itemView.getContext().startActivity(intent);
                                    return;
                                }
                                if (n == 3) {
                                    MessageAdaptor.this.deleteMessageForEveryone(n, messageViewHolder);
                                }
                            }
                        });
                        builder.show();
                    }
                    if (((Messages)MessageAdaptor.this.userMessageList.get(n)).getType().equals((Object)"image")) {
                        CharSequence[] arrcharSequence = new CharSequence[]{"Delete for me", "View this image", "Cancel", "Delete for Everyone"};
                        AlertDialog.Builder builder = new AlertDialog.Builder(messageViewHolder.itemView.getContext());
                        builder.setTitle((CharSequence)"Delete Message");
                        builder.setItems(arrcharSequence, new DialogInterface.OnClickListener(){

                            public void onClick(DialogInterface dialogInterface, int n) {
                                if (n == 0) {
                                    MessageAdaptor.this.deleteSentMessage(n, messageViewHolder);
                                    return;
                                }
                                if (n == 1) {
                                    Intent intent = new Intent(messageViewHolder.itemView.getContext(), ImageViewActivity.class);
                                    intent.putExtra("url", ((Messages)MessageAdaptor.this.userMessageList.get(n)).getMessage());
                                    messageViewHolder.itemView.getContext().startActivity(intent);
                                    return;
                                }
                                if (n == 3) {
                                    MessageAdaptor.this.deleteMessageForEveryone(n, messageViewHolder);
                                }
                            }
                        });
                        builder.show();
                    }
                }

            });
            return;
        }
        messageViewHolder.itemView.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (!((Messages)MessageAdaptor.this.userMessageList.get(n)).getType().equals((Object)"pdf") && !((Messages)MessageAdaptor.this.userMessageList.get(n)).getType().equals((Object)"docs")) {
                    if (((Messages)MessageAdaptor.this.userMessageList.get(n)).getType().equals((Object)"text")) {
                        CharSequence[] arrcharSequence = new CharSequence[]{"Delete for me", "Cancel"};
                        AlertDialog.Builder builder = new AlertDialog.Builder(messageViewHolder.itemView.getContext());
                        builder.setTitle((CharSequence)"Delete Message");
                        builder.setItems(arrcharSequence, new DialogInterface.OnClickListener(){

                            public void onClick(DialogInterface dialogInterface, int n) {
                                if (n == 0) {
                                    MessageAdaptor.this.deleteReceivedMessage(n, messageViewHolder);
                                }
                            }
                        });
                        builder.show();
                    }
                } else {
                    CharSequence[] arrcharSequence = new CharSequence[]{"Delete for me", "Downlaod and View", "Cancel"};
                    AlertDialog.Builder builder = new AlertDialog.Builder(messageViewHolder.itemView.getContext());
                    builder.setTitle((CharSequence)"Delete Message");
                    builder.setItems(arrcharSequence, new DialogInterface.OnClickListener(){

                        public void onClick(DialogInterface dialogInterface, int n) {
                            if (n == 0) {
                                MessageAdaptor.this.deleteReceivedMessage(n, messageViewHolder);
                                return;
                            }
                            if (n == 1) {
                                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse((String)((Messages)MessageAdaptor.this.userMessageList.get(n)).getMessage()));
                                messageViewHolder.itemView.getContext().startActivity(intent);
                            }
                        }
                    });
                    builder.show();
                }
                if (((Messages)MessageAdaptor.this.userMessageList.get(n)).getType().equals((Object)"image")) {
                    CharSequence[] arrcharSequence = new CharSequence[]{"Delete for me", "View this image", "Cancel"};
                    AlertDialog.Builder builder = new AlertDialog.Builder(messageViewHolder.itemView.getContext());
                    builder.setTitle((CharSequence)"Delete Message");
                    builder.setItems(arrcharSequence, new DialogInterface.OnClickListener(){

                        public void onClick(DialogInterface dialogInterface, int n) {
                            if (n == 0) {
                                MessageAdaptor.this.deleteReceivedMessage(n, messageViewHolder);
                                return;
                            }
                            if (n == 1) {
                                Intent intent = new Intent(messageViewHolder.itemView.getContext(), ImageViewActivity.class);
                                intent.putExtra("url", ((Messages)MessageAdaptor.this.userMessageList.get(n)).getMessage());
                                messageViewHolder.itemView.getContext().startActivity(intent);
                            }
                        }
                    });
                    builder.show();
                }
            }

        });
    }

    public MessageViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        View view = LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131558441, viewGroup, false);
        this.mAuth = FirebaseAuth.getInstance();
        return new MessageViewHolder(view);
    }

    public class MessageViewHolder
    extends RecyclerView.ViewHolder {
        public TextView date_time;
        public ImageView messageReceiverImage;
        public ImageView messageSenderImage;
        public RoundedImageView receiverProfileImage;
        public TextView receiverTextView;
        public TextView receiverTime;
        public TextView senderMessageText;
        public TextView senderTime;

        public MessageViewHolder(View view) {
            super(view);
            this.senderMessageText = (TextView)view.findViewById(2131362254);
            this.receiverTextView = (TextView)view.findViewById(2131362210);
            this.receiverProfileImage = (RoundedImageView)view.findViewById(2131362131);
            this.messageSenderImage = (ImageView)view.findViewById(2131362253);
            this.messageReceiverImage = (ImageView)view.findViewById(2131362209);
            this.senderTime = (TextView)view.findViewById(2131362252);
            this.receiverTime = (TextView)view.findViewById(2131362208);
            this.date_time = (TextView)view.findViewById(2131361970);
        }
    }

}

