/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.fragment.app.Fragment
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.firebase.ui.database.FirebaseRecyclerAdapter
 *  com.firebase.ui.database.FirebaseRecyclerOptions
 *  com.firebase.ui.database.FirebaseRecyclerOptions$Builder
 *  com.google.firebase.auth.FirebaseAuth
 *  com.google.firebase.auth.FirebaseUser
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.database.Query
 *  com.google.firebase.database.ValueEventListener
 *  com.makeramen.roundedimageview.RoundedImageView
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.whitedot.ReachModel;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;

public class FriendsFragment
extends Fragment {
    private DatabaseReference FriendsRef;
    private DatabaseReference UserRef;
    private String currentUID;
    private FirebaseAuth mAuth;
    private RecyclerView myfriends;

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        RecyclerView recyclerView;
        FirebaseAuth firebaseAuth;
        View view = layoutInflater.inflate(2131558466, viewGroup, false);
        this.myfriends = recyclerView = (RecyclerView)view.findViewById(2131362225);
        recyclerView.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager(this.getContext()));
        this.mAuth = firebaseAuth = FirebaseAuth.getInstance();
        this.currentUID = firebaseAuth.getCurrentUser().getUid();
        this.FriendsRef = FirebaseDatabase.getInstance().getReference().child("Friends").child(this.currentUID);
        this.UserRef = FirebaseDatabase.getInstance().getReference().child("Users");
        return view;
    }

    public void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<ReachModel, FriendsViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<ReachModel, FriendsViewHolder>(new FirebaseRecyclerOptions.Builder().setQuery((Query)this.FriendsRef, ReachModel.class).build()){

            protected void onBindViewHolder(final FriendsViewHolder friendsViewHolder, int n, ReachModel reachModel) {
                String string2 = this.getRef(n).getKey();
                FriendsFragment.this.UserRef.child(string2).addValueEventListener(new ValueEventListener(){

                    public void onCancelled(DatabaseError databaseError) {
                    }

                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            if (dataSnapshot.child("userState").hasChild("state")) {
                                String string2 = dataSnapshot.child("userState").child("state").getValue().toString();
                                dataSnapshot.child("userState").child("date").getValue().toString();
                                dataSnapshot.child("userState").child("time").getValue().toString();
                                if (string2.equals((Object)"online")) {
                                    friendsViewHolder.green.setVisibility(0);
                                } else if (string2.equals((Object)"offline")) {
                                    friendsViewHolder.green.setVisibility(4);
                                }
                            } else {
                                friendsViewHolder.green.setVisibility(4);
                            }
                            String string3 = dataSnapshot.child("image").getValue().toString();
                            String string4 = dataSnapshot.child("username").getValue().toString();
                            String string5 = dataSnapshot.child("status").getValue().toString();
                            friendsViewHolder.username.setText((CharSequence)string4);
                            friendsViewHolder.status.setText((CharSequence)string5);
                            Picasso.get().load(string3).into((ImageView)friendsViewHolder.profileImage);
                        }
                    }
                });
            }

            public FriendsViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
                return new FriendsViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131558547, viewGroup, false));
            }

        };
        this.myfriends.setAdapter((RecyclerView.Adapter)firebaseRecyclerAdapter);
        firebaseRecyclerAdapter.startListening();
    }

    public static class FriendsViewHolder
    extends RecyclerView.ViewHolder {
        ImageView green;
        RoundedImageView profileImage;
        TextView status;
        TextView username;

        public FriendsViewHolder(View view) {
            super(view);
            this.username = (TextView)view.findViewById(2131362380);
            this.status = (TextView)view.findViewById(2131362296);
            this.profileImage = (RoundedImageView)view.findViewById(2131361804);
            this.green = (ImageView)view.findViewById(2131362059);
        }
    }

}

