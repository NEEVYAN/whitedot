/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.content.Context
 *  android.graphics.Color
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.ImageView
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.fragment.app.Fragment
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.firebase.ui.database.FirebaseRecyclerAdapter
 *  com.firebase.ui.database.FirebaseRecyclerOptions
 *  com.firebase.ui.database.FirebaseRecyclerOptions$Builder
 *  com.google.android.gms.tasks.OnCompleteListener
 *  com.google.android.gms.tasks.Task
 *  com.google.firebase.auth.FirebaseAuth
 *  com.google.firebase.auth.FirebaseUser
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.database.Query
 *  com.google.firebase.database.ValueEventListener
 *  com.makeramen.roundedimageview.RoundedImageView
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 */
package com.example.whitedot;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.whitedot.ReachModel;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;

public class RequestFragment
extends Fragment {
    private DatabaseReference ContactRef;
    private DatabaseReference UserRef;
    private ImageView backImg;
    private DatabaseReference chatRef;
    private String currentUID;
    private FirebaseAuth mAuth;
    private RecyclerView myRequestList;

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        RecyclerView recyclerView;
        FirebaseAuth firebaseAuth;
        View view = layoutInflater.inflate(2131558467, viewGroup, false);
        this.myRequestList = recyclerView = (RecyclerView)view.findViewById(2131362224);
        recyclerView.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager(this.getContext()));
        this.chatRef = FirebaseDatabase.getInstance().getReference().child("ChatRequest");
        this.UserRef = FirebaseDatabase.getInstance().getReference().child("Users");
        this.ContactRef = FirebaseDatabase.getInstance().getReference().child("Friends");
        this.backImg = (ImageView)view.findViewById(2131361897);
        this.mAuth = firebaseAuth = FirebaseAuth.getInstance();
        this.currentUID = firebaseAuth.getCurrentUser().getUid();
        return view;
    }

    public void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<ReachModel, RequestViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<ReachModel, RequestViewHolder>(new FirebaseRecyclerOptions.Builder().setQuery((Query)this.chatRef.child(this.currentUID), ReachModel.class).build()){

            protected void onBindViewHolder(final RequestViewHolder requestViewHolder, int n, ReachModel reachModel) {
                requestViewHolder.itemView.findViewById(2131361919).setVisibility(0);
                requestViewHolder.itemView.findViewById(2131361920).setVisibility(0);
                final String string2 = this.getRef(n).getKey();
                this.getRef(n).child("request_type").getRef().addValueEventListener(new ValueEventListener(){

                    public void onCancelled(DatabaseError databaseError) {
                    }

                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            String string22 = dataSnapshot.getValue().toString();
                            if (string22.equals((Object)"received")) {
                                RequestFragment.this.UserRef.child(string2).addValueEventListener(new ValueEventListener(){

                                    public void onCancelled(DatabaseError databaseError) {
                                    }

                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        if (dataSnapshot.hasChild("status")) {
                                            dataSnapshot.child("status").getValue().toString();
                                            String string2 = dataSnapshot.child("image").getValue().toString();
                                            requestViewHolder.status.setText((CharSequence)"want to be friends");
                                            Picasso.get().load(string2).into((ImageView)requestViewHolder.profileImage);
                                        }
                                        final String string3 = dataSnapshot.child("username").getValue().toString();
                                        requestViewHolder.username.setText((CharSequence)string3);
                                        requestViewHolder.itemView.setOnClickListener(new View.OnClickListener(){

                                            public void onClick(View view) {
                                                final Dialog dialog = new Dialog(RequestFragment.this.getContext());
                                                dialog.setContentView(2131558459);
                                                Button button = (Button)dialog.findViewById(2131361819);
                                                Button button2 = (Button)dialog.findViewById(2131361973);
                                                ((TextView)dialog.findViewById(2131361948)).setText((CharSequence)string3);
                                                button.setOnClickListener(new View.OnClickListener(){

                                                    public void onClick(View view) {
                                                        RequestFragment.this.ContactRef.child(RequestFragment.this.currentUID).child(string2).child("Friends").setValue((Object)"Saved").addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                                            public void onComplete(Task<Void> task) {
                                                                if (task.isSuccessful()) {
                                                                    RequestFragment.this.ContactRef.child(string2).child(RequestFragment.this.currentUID).child("Friends").setValue((Object)"Saved").addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                                                        public void onComplete(Task<Void> task) {
                                                                            if (task.isSuccessful()) {
                                                                                RequestFragment.this.chatRef.child(RequestFragment.this.currentUID).child(string2).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                                                                    public void onComplete(Task<Void> task) {
                                                                                        if (task.isSuccessful()) {
                                                                                            RequestFragment.this.chatRef.child(string2).child(RequestFragment.this.currentUID).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                                                                                public void onComplete(Task<Void> task) {
                                                                                                    if (task.isSuccessful()) {
                                                                                                        Toast.makeText((Context)RequestFragment.this.getContext(), (CharSequence)"Friends added", (int)0).show();
                                                                                                        dialog.dismiss();
                                                                                                    }
                                                                                                }
                                                                                            });
                                                                                        }
                                                                                    }

                                                                                });
                                                                            }
                                                                        }

                                                                    });
                                                                }
                                                            }

                                                        });
                                                    }

                                                });
                                                button2.setOnClickListener(new View.OnClickListener(){

                                                    public void onClick(View view) {
                                                        RequestFragment.this.chatRef.child(RequestFragment.this.currentUID).child(string2).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                                            public void onComplete(Task<Void> task) {
                                                                if (task.isSuccessful()) {
                                                                    RequestFragment.this.chatRef.child(string2).child(RequestFragment.this.currentUID).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                                                        public void onComplete(Task<Void> task) {
                                                                            if (task.isSuccessful()) {
                                                                                Toast.makeText((Context)RequestFragment.this.getContext(), (CharSequence)"Contact removed", (int)0).show();
                                                                                dialog.dismiss();
                                                                            }
                                                                        }
                                                                    });
                                                                }
                                                            }

                                                        });
                                                    }

                                                });
                                                dialog.show();
                                            }

                                        });
                                    }

                                });
                                return;
                            }
                            if (string22.equals((Object)"Sent")) {
                                TextView textView = (TextView)requestViewHolder.itemView.findViewById(2131361919);
                                textView.setText((CharSequence)"Request Sent");
                                textView.setTextColor(Color.parseColor((String)"#000000"));
                                requestViewHolder.itemView.findViewById(2131361920).setVisibility(4);
                                RequestFragment.this.UserRef.child(string2).addValueEventListener(new ValueEventListener(){

                                    public void onCancelled(DatabaseError databaseError) {
                                    }

                                    public void onDataChange(DataSnapshot dataSnapshot) {
                                        final String string2 = dataSnapshot.child("username").getValue().toString();
                                        requestViewHolder.username.setText((CharSequence)string2);
                                        dataSnapshot.child("status").getValue().toString();
                                        String string3 = dataSnapshot.child("image").getValue().toString();
                                        requestViewHolder.status.setText((CharSequence)("You sent a request to " + string2));
                                        Picasso.get().load(string3).into((ImageView)requestViewHolder.profileImage);
                                        requestViewHolder.itemView.setOnClickListener(new View.OnClickListener(){

                                            public void onClick(View view) {
                                                final Dialog dialog = new Dialog(RequestFragment.this.getContext());
                                                dialog.setContentView(2131558459);
                                                ((Button)dialog.findViewById(2131361819)).setVisibility(8);
                                                Button button = (Button)dialog.findViewById(2131361973);
                                                button.setText((CharSequence)"Cancel");
                                                TextView textView = (TextView)dialog.findViewById(2131361948);
                                                ((TextView)dialog.findViewById(2131361949)).setText((CharSequence)"Request sent");
                                                textView.setText((CharSequence)string2);
                                                button.setOnClickListener(new View.OnClickListener(){

                                                    public void onClick(View view) {
                                                        RequestFragment.this.chatRef.child(RequestFragment.this.currentUID).child(string2).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                                            public void onComplete(Task<Void> task) {
                                                                if (task.isSuccessful()) {
                                                                    RequestFragment.this.chatRef.child(string2).child(RequestFragment.this.currentUID).removeValue().addOnCompleteListener((OnCompleteListener)new OnCompleteListener<Void>(){

                                                                        public void onComplete(Task<Void> task) {
                                                                            if (task.isSuccessful()) {
                                                                                Toast.makeText((Context)RequestFragment.this.getContext(), (CharSequence)"Request Cancelled", (int)0).show();
                                                                                dialog.dismiss();
                                                                            }
                                                                        }
                                                                    });
                                                                }
                                                            }

                                                        });
                                                    }

                                                });
                                                dialog.show();
                                            }

                                        });
                                    }

                                });
                            }
                        }
                    }

                });
            }

            public RequestViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
                return new RequestViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131558547, viewGroup, false));
            }

        };
        this.myRequestList.setAdapter((RecyclerView.Adapter)firebaseRecyclerAdapter);
        firebaseRecyclerAdapter.startListening();
    }

    public static class RequestViewHolder
    extends RecyclerView.ViewHolder {
        TextView accept;
        TextView decline;
        RoundedImageView profileImage;
        TextView status;
        TextView username;

        public RequestViewHolder(View view) {
            super(view);
            this.username = (TextView)view.findViewById(2131362380);
            this.profileImage = (RoundedImageView)view.findViewById(2131361804);
            this.status = (TextView)view.findViewById(2131362296);
            this.accept = (TextView)view.findViewById(2131361919);
            this.decline = (TextView)view.findViewById(2131361920);
        }
    }

}

