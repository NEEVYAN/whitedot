/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.fragment.app.FragmentManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.devlomi.circularstatusview.CircularStatusView
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.FirebaseDatabase
 *  com.google.firebase.database.ValueEventListener
 *  com.makeramen.roundedimageview.RoundedImageView
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.RequestCreator
 *  de.hdodenhof.circleimageview.CircleImageView
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  omari.hamza.storyview.StoryView
 *  omari.hamza.storyview.StoryView$Builder
 *  omari.hamza.storyview.callback.StoryClickListeners
 *  omari.hamza.storyview.model.MyStory
 */
package com.example.whitedot;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import com.devlomi.circularstatusview.CircularStatusView;
import com.example.whitedot.ReachModel;
import com.example.whitedot.Story;
import com.example.whitedot.UserStories;
import com.example.whitedot.databinding.UserList2Binding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import de.hdodenhof.circleimageview.CircleImageView;
import java.util.ArrayList;
import java.util.Iterator;
import omari.hamza.storyview.StoryView;
import omari.hamza.storyview.callback.StoryClickListeners;
import omari.hamza.storyview.model.MyStory;

public class StoryAdapter
extends RecyclerView.Adapter<viewHolder> {
    Context context;
    ArrayList<Story> list;

    public StoryAdapter(ArrayList<Story> arrayList, Context context) {
        this.list = arrayList;
        this.context = context;
    }

    public int getItemCount() {
        return this.list.size();
    }

    public void onBindViewHolder(final viewHolder viewHolder2, int n) {
        final Story story = (Story)this.list.get(n);
        if (story.getStories().size() > 0) {
            UserStories userStories = (UserStories)story.getStories().get(-1 + story.getStories().size());
            Picasso.get().load(userStories.getImage()).fit().into((ImageView)viewHolder2.binding.story);
            viewHolder2.binding.statusCircleCount.setPortionsCount(story.getStories().size());
            FirebaseDatabase.getInstance().getReference().child("Users").child(story.getStoryBy()).addValueEventListener(new ValueEventListener(){

                public void onCancelled(DatabaseError databaseError) {
                }

                public void onDataChange(DataSnapshot dataSnapshot) {
                    final ReachModel reachModel = (ReachModel)dataSnapshot.getValue(ReachModel.class);
                    Picasso.get().load(reachModel.getImage()).fit().into((ImageView)viewHolder2.binding.profileImage);
                    viewHolder2.binding.name.setText((CharSequence)reachModel.getUsername());
                    viewHolder2.binding.story.setOnClickListener(new View.OnClickListener(){

                        public void onClick(View view) {
                            ArrayList arrayList = new ArrayList();
                            Iterator iterator = story.getStories().iterator();
                            while (iterator.hasNext()) {
                                arrayList.add((Object)new MyStory(((UserStories)iterator.next()).getImage()));
                            }
                            new StoryView.Builder(((AppCompatActivity)StoryAdapter.this.context).getSupportFragmentManager()).setStoriesList(arrayList).setStoryDuration(5000L).setTitleText(reachModel.getUsername()).setSubtitleText("").setTitleLogoUrl(reachModel.getImage()).setStoryClickListeners(new StoryClickListeners(){

                                public void onDescriptionClickListener(int n) {
                                }

                                public void onTitleIconClickListener(int n) {
                                }
                            }).build().show();
                        }

                    });
                }

            });
        }
    }

    public viewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new viewHolder(LayoutInflater.from((Context)this.context).inflate(2131558546, viewGroup, false));
    }

    public class viewHolder
    extends RecyclerView.ViewHolder {
        UserList2Binding binding;

        public viewHolder(View view) {
            super(view);
            this.binding = UserList2Binding.bind(view);
        }
    }

}

