/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.fragment.app.FragmentActivity
 *  com.google.android.material.bottomsheet.BottomSheetDialogFragment
 *  com.google.firebase.auth.FirebaseAuth
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 */
package com.example.whitedot;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.FragmentActivity;
import com.example.whitedot.Activities.SignInActivity;
import com.example.whitedot.Activities.findFriends;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.auth.FirebaseAuth;

public class BottomFragment
extends BottomSheetDialogFragment {
    LinearLayout cancelBtn;
    TextView findFriends;
    TextView logout;

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = layoutInflater.inflate(2131558437, viewGroup, false);
        this.findFriends = (TextView)view.findViewById(2131362038);
        this.cancelBtn = (LinearLayout)view.findViewById(2131361992);
        this.logout = (TextView)view.findViewById(2131362117);
        this.findFriends.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Intent intent = new Intent((Context)BottomFragment.this.getActivity(), findFriends.class);
                BottomFragment.this.startActivity(intent);
            }
        });
        this.cancelBtn.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                BottomFragment.this.dismiss();
            }
        });
        this.logout.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Toast.makeText((Context)BottomFragment.this.getContext(), (CharSequence)"Logged Out", (int)0).show();
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent((Context)BottomFragment.this.getActivity(), SignInActivity.class);
                intent.setFlags(268468224);
                BottomFragment.this.startActivity(intent);
            }
        });
        return view;
    }

}

