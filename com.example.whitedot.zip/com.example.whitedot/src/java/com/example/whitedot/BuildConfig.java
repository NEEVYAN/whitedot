/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.example.whitedot";
    public static final String BUILD_TYPE = "debug";
    public static final boolean DEBUG = false;
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";

    static {
        DEBUG = Boolean.parseBoolean((String)"true");
    }
}

