/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.Iitems;

public class constant {
    public static final String KEY_EMAIL = "email";
    public static final String KEY_IMAGE = "image";
    public static final String KEY_NAME = "name";
    public static final String KEY_NAME_USED = "chatName";
    public static final String KEY_ONLINE = "isOnline";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_USERS = "users";
    public static final String KEY_USER_ID = "userId";
}

