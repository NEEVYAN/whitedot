/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.example.whitedot;

import com.example.whitedot.UserStories;
import java.util.ArrayList;

public class Story {
    ArrayList<UserStories> stories;
    private long storyAt;
    private String storyBy;

    public ArrayList<UserStories> getStories() {
        return this.stories;
    }

    public long getStoryAt() {
        return this.storyAt;
    }

    public String getStoryBy() {
        return this.storyBy;
    }

    public void setStories(ArrayList<UserStories> arrayList) {
        this.stories = arrayList;
    }

    public void setStoryAt(long l) {
        this.storyAt = l;
    }

    public void setStoryBy(String string2) {
        this.storyBy = string2;
    }
}

