/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  androidx.appcompat.app.AppCompatActivity
 */
package com.example.whitedot;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ThemeActivity
extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131558435);
    }
}

