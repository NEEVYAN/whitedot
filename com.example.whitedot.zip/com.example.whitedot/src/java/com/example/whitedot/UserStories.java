/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot;

public class UserStories {
    private String image;
    private long storyAt;

    public UserStories() {
    }

    public UserStories(String string2, long l) {
        this.image = string2;
        this.storyAt = l;
    }

    public String getImage() {
        return this.image;
    }

    public long getStoryAt() {
        return this.storyAt;
    }

    public void setImage(String string2) {
        this.image = string2;
    }

    public void setStoryAt(long l) {
        this.storyAt = l;
    }
}

