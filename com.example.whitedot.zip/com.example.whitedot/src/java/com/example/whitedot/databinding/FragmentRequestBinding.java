/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class FragmentRequestBinding
implements ViewBinding {
    public final ImageView back;
    private final RelativeLayout rootView;
    public final RecyclerView rvFriendReq;

    private FragmentRequestBinding(RelativeLayout relativeLayout, ImageView imageView, RecyclerView recyclerView) {
        this.rootView = relativeLayout;
        this.back = imageView;
        this.rvFriendReq = recyclerView;
    }

    public static FragmentRequestBinding bind(View view) {
        RecyclerView recyclerView;
        int n = 2131361897;
        ImageView imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)n);
        if (imageView != null && (recyclerView = (RecyclerView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362224))) != null) {
            return new FragmentRequestBinding((RelativeLayout)view, imageView, recyclerView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static FragmentRequestBinding inflate(LayoutInflater layoutInflater) {
        return FragmentRequestBinding.inflate(layoutInflater, null, false);
    }

    public static FragmentRequestBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558467, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return FragmentRequestBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

