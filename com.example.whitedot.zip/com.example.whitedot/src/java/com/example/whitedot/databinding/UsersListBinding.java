/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  com.makeramen.roundedimageview.RoundedImageView
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.makeramen.roundedimageview.RoundedImageView;

public final class UsersListBinding
implements ViewBinding {
    public final RoundedImageView Profile;
    public final TextView btnaccept;
    public final TextView btndecline;
    public final ImageView greendot;
    private final RelativeLayout rootView;
    public final TextView statusPerson;
    public final TextView userName;

    private UsersListBinding(RelativeLayout relativeLayout, RoundedImageView roundedImageView, TextView textView, TextView textView2, ImageView imageView, TextView textView3, TextView textView4) {
        this.rootView = relativeLayout;
        this.Profile = roundedImageView;
        this.btnaccept = textView;
        this.btndecline = textView2;
        this.greendot = imageView;
        this.statusPerson = textView3;
        this.userName = textView4;
    }

    public static UsersListBinding bind(View view) {
        TextView textView;
        TextView textView2;
        TextView textView3;
        TextView textView4;
        ImageView imageView;
        int n = 2131361804;
        RoundedImageView roundedImageView = (RoundedImageView)ViewBindings.findChildViewById((View)view, (int)n);
        if (roundedImageView != null && (textView4 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361919))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361920))) != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362059))) != null && (textView3 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362296))) != null && (textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362380))) != null) {
            UsersListBinding usersListBinding = new UsersListBinding((RelativeLayout)view, roundedImageView, textView4, textView, imageView, textView3, textView2);
            return usersListBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static UsersListBinding inflate(LayoutInflater layoutInflater) {
        return UsersListBinding.inflate(layoutInflater, null, false);
    }

    public static UsersListBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558547, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return UsersListBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

