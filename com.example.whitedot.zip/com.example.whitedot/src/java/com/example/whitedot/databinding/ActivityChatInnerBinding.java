/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  com.makeramen.roundedimageview.RoundedImageView
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.makeramen.roundedimageview.RoundedImageView;

public final class ActivityChatInnerBinding
implements ViewBinding {
    public final EditText MessageBox;
    public final TextView ReceiverName;
    public final FrameLayout SENDFILES;
    public final ImageView back;
    public final ConstraintLayout chatActivity;
    public final FrameLayout emoji;
    public final FrameLayout fl;
    public final FrameLayout frameLayout;
    public final RoundedImageView image;
    public final RecyclerView messageRv;
    public final ImageView messageSent;
    private final ConstraintLayout rootView;
    public final FrameLayout sendBtn;
    public final TextView status;

    private ActivityChatInnerBinding(ConstraintLayout constraintLayout, EditText editText, TextView textView, FrameLayout frameLayout, ImageView imageView, ConstraintLayout constraintLayout2, FrameLayout frameLayout2, FrameLayout frameLayout3, FrameLayout frameLayout4, RoundedImageView roundedImageView, RecyclerView recyclerView, ImageView imageView2, FrameLayout frameLayout5, TextView textView2) {
        this.rootView = constraintLayout;
        this.MessageBox = editText;
        this.ReceiverName = textView;
        this.SENDFILES = frameLayout;
        this.back = imageView;
        this.chatActivity = constraintLayout2;
        this.emoji = frameLayout2;
        this.fl = frameLayout3;
        this.frameLayout = frameLayout4;
        this.image = roundedImageView;
        this.messageRv = recyclerView;
        this.messageSent = imageView2;
        this.sendBtn = frameLayout5;
        this.status = textView2;
    }

    public static ActivityChatInnerBinding bind(View view) {
        FrameLayout frameLayout;
        TextView textView;
        ImageView imageView;
        int n = 2131361801;
        EditText editText = (EditText)ViewBindings.findChildViewById((View)view, (int)n);
        if (editText != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361805))) != null && (frameLayout = (FrameLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131361807))) != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361897))) != null) {
            RoundedImageView roundedImageView;
            FrameLayout frameLayout2;
            TextView textView2;
            FrameLayout frameLayout3;
            ImageView imageView2;
            FrameLayout frameLayout4;
            RecyclerView recyclerView;
            ConstraintLayout constraintLayout = (ConstraintLayout)view;
            n = 2131362008;
            FrameLayout frameLayout5 = (FrameLayout)ViewBindings.findChildViewById((View)view, (int)n);
            if (frameLayout5 != null && (frameLayout4 = (FrameLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362041))) != null && (frameLayout3 = (FrameLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362046))) != null && (roundedImageView = (RoundedImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362077))) != null && (recyclerView = (RecyclerView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362130))) != null && (imageView2 = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362129))) != null && (frameLayout2 = (FrameLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362250))) != null && (textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362293))) != null) {
                ActivityChatInnerBinding activityChatInnerBinding = new ActivityChatInnerBinding((ConstraintLayout)view, editText, textView, frameLayout, imageView, constraintLayout, frameLayout5, frameLayout4, frameLayout3, roundedImageView, recyclerView, imageView2, frameLayout2, textView2);
                return activityChatInnerBinding;
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivityChatInnerBinding inflate(LayoutInflater layoutInflater) {
        return ActivityChatInnerBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityChatInnerBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558429, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityChatInnerBinding.bind(view);
    }

    public ConstraintLayout getRoot() {
        return this.rootView;
    }
}

