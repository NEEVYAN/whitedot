/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class DialogueBoxAcceptDeclineBinding
implements ViewBinding {
    public final Button acceptReq;
    public final TextView cnf;
    public final TextView cnfSent;
    public final Button declineReq;
    private final LinearLayout rootView;

    private DialogueBoxAcceptDeclineBinding(LinearLayout linearLayout, Button button, TextView textView, TextView textView2, Button button2) {
        this.rootView = linearLayout;
        this.acceptReq = button;
        this.cnf = textView;
        this.cnfSent = textView2;
        this.declineReq = button2;
    }

    public static DialogueBoxAcceptDeclineBinding bind(View view) {
        TextView textView;
        Button button;
        TextView textView2;
        int n = 2131361819;
        Button button2 = (Button)ViewBindings.findChildViewById((View)view, (int)n);
        if (button2 != null && (textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361948))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361949))) != null && (button = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361973))) != null) {
            DialogueBoxAcceptDeclineBinding dialogueBoxAcceptDeclineBinding = new DialogueBoxAcceptDeclineBinding((LinearLayout)view, button2, textView2, textView, button);
            return dialogueBoxAcceptDeclineBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static DialogueBoxAcceptDeclineBinding inflate(LayoutInflater layoutInflater) {
        return DialogueBoxAcceptDeclineBinding.inflate(layoutInflater, null, false);
    }

    public static DialogueBoxAcceptDeclineBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558459, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return DialogueBoxAcceptDeclineBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

