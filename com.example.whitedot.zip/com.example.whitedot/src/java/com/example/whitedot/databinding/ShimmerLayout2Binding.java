/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  com.devlomi.circularstatusview.CircularStatusView
 *  com.makeramen.roundedimageview.RoundedImageView
 *  de.hdodenhof.circleimageview.CircleImageView
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.devlomi.circularstatusview.CircularStatusView;
import com.makeramen.roundedimageview.RoundedImageView;
import de.hdodenhof.circleimageview.CircleImageView;

public final class ShimmerLayout2Binding
implements ViewBinding {
    public final TextView name;
    public final CircleImageView profileImage;
    private final ConstraintLayout rootView;
    public final CircularStatusView statusCircleCount;
    public final RoundedImageView story;
    public final ImageView storyType;

    private ShimmerLayout2Binding(ConstraintLayout constraintLayout, TextView textView, CircleImageView circleImageView, CircularStatusView circularStatusView, RoundedImageView roundedImageView, ImageView imageView) {
        this.rootView = constraintLayout;
        this.name = textView;
        this.profileImage = circleImageView;
        this.statusCircleCount = circularStatusView;
        this.story = roundedImageView;
        this.storyType = imageView;
    }

    public static ShimmerLayout2Binding bind(View view) {
        CircularStatusView circularStatusView;
        ImageView imageView;
        CircleImageView circleImageView;
        RoundedImageView roundedImageView;
        int n = 2131362164;
        TextView textView = (TextView)ViewBindings.findChildViewById((View)view, (int)n);
        if (textView != null && (circleImageView = (CircleImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362200))) != null && (circularStatusView = (CircularStatusView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362294))) != null && (roundedImageView = (RoundedImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362300))) != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362301))) != null) {
            ShimmerLayout2Binding shimmerLayout2Binding = new ShimmerLayout2Binding((ConstraintLayout)view, textView, circleImageView, circularStatusView, roundedImageView, imageView);
            return shimmerLayout2Binding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ShimmerLayout2Binding inflate(LayoutInflater layoutInflater) {
        return ShimmerLayout2Binding.inflate(layoutInflater, null, false);
    }

    public static ShimmerLayout2Binding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558522, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ShimmerLayout2Binding.bind(view);
    }

    public ConstraintLayout getRoot() {
        return this.rootView;
    }
}

