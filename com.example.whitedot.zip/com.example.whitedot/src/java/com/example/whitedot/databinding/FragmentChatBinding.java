/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  androidx.appcompat.widget.SearchView
 *  androidx.drawerlayout.widget.DrawerLayout
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  com.cooltechworks.views.shimmer.ShimmerRecyclerView
 *  com.google.android.material.floatingactionbutton.FloatingActionButton
 *  com.makeramen.roundedimageview.RoundedImageView
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.appcompat.widget.SearchView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.makeramen.roundedimageview.RoundedImageView;

public final class FragmentChatBinding
implements ViewBinding {
    public final RoundedImageView Options;
    public final ShimmerRecyclerView allFriendsRv;
    public final ImageView logout;
    public final DrawerLayout mydrawer;
    private final DrawerLayout rootView;
    public final SearchView searchView;
    public final FloatingActionButton sendtoAddFriend;
    public final View view;

    private FragmentChatBinding(DrawerLayout drawerLayout, RoundedImageView roundedImageView, ShimmerRecyclerView shimmerRecyclerView, ImageView imageView, DrawerLayout drawerLayout2, SearchView searchView, FloatingActionButton floatingActionButton, View view) {
        this.rootView = drawerLayout;
        this.Options = roundedImageView;
        this.allFriendsRv = shimmerRecyclerView;
        this.logout = imageView;
        this.mydrawer = drawerLayout2;
        this.searchView = searchView;
        this.sendtoAddFriend = floatingActionButton;
        this.view = view;
    }

    public static FragmentChatBinding bind(View view) {
        ImageView imageView;
        ShimmerRecyclerView shimmerRecyclerView;
        int n = 2131361803;
        RoundedImageView roundedImageView = (RoundedImageView)ViewBindings.findChildViewById((View)view, (int)n);
        if (roundedImageView != null && (shimmerRecyclerView = (ShimmerRecyclerView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361884))) != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362116))) != null) {
            FloatingActionButton floatingActionButton;
            View view2;
            DrawerLayout drawerLayout = (DrawerLayout)view;
            n = 2131362237;
            SearchView searchView = (SearchView)ViewBindings.findChildViewById((View)view, (int)n);
            if (searchView != null && (floatingActionButton = (FloatingActionButton)ViewBindings.findChildViewById((View)view, (int)(n = 2131362255))) != null && (view2 = ViewBindings.findChildViewById((View)view, (int)(n = 2131362382))) != null) {
                FragmentChatBinding fragmentChatBinding = new FragmentChatBinding((DrawerLayout)view, roundedImageView, shimmerRecyclerView, imageView, drawerLayout, searchView, floatingActionButton, view2);
                return fragmentChatBinding;
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static FragmentChatBinding inflate(LayoutInflater layoutInflater) {
        return FragmentChatBinding.inflate(layoutInflater, null, false);
    }

    public static FragmentChatBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558465, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return FragmentChatBinding.bind(view);
    }

    public DrawerLayout getRoot() {
        return this.rootView;
    }
}

