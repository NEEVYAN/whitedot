/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ActivityImageViewBinding
implements ViewBinding {
    public final ImageView imageViewer;
    private final RelativeLayout rootView;

    private ActivityImageViewBinding(RelativeLayout relativeLayout, ImageView imageView) {
        this.rootView = relativeLayout;
        this.imageViewer = imageView;
    }

    public static ActivityImageViewBinding bind(View view) {
        ImageView imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)2131362081);
        if (imageView != null) {
            return new ActivityImageViewBinding((RelativeLayout)view, imageView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(2131362081)));
    }

    public static ActivityImageViewBinding inflate(LayoutInflater layoutInflater) {
        return ActivityImageViewBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityImageViewBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558431, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityImageViewBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

