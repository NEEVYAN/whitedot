/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  androidx.viewbinding.ViewBinding
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewbinding.ViewBinding;

public final class ActivityMainBinding
implements ViewBinding {
    private final ConstraintLayout rootView;

    private ActivityMainBinding(ConstraintLayout constraintLayout) {
        this.rootView = constraintLayout;
    }

    public static ActivityMainBinding bind(View view) {
        if (view != null) {
            return new ActivityMainBinding((ConstraintLayout)view);
        }
        throw new NullPointerException("rootView");
    }

    public static ActivityMainBinding inflate(LayoutInflater layoutInflater) {
        return ActivityMainBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityMainBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558432, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityMainBinding.bind(view);
    }

    public ConstraintLayout getRoot() {
        return this.rootView;
    }
}

