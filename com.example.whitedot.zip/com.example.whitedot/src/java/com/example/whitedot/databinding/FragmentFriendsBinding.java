/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.RelativeLayout
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class FragmentFriendsBinding
implements ViewBinding {
    private final RelativeLayout rootView;
    public final RecyclerView rvFriendsList;

    private FragmentFriendsBinding(RelativeLayout relativeLayout, RecyclerView recyclerView) {
        this.rootView = relativeLayout;
        this.rvFriendsList = recyclerView;
    }

    public static FragmentFriendsBinding bind(View view) {
        RecyclerView recyclerView = (RecyclerView)ViewBindings.findChildViewById((View)view, (int)2131362225);
        if (recyclerView != null) {
            return new FragmentFriendsBinding((RelativeLayout)view, recyclerView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(2131362225)));
    }

    public static FragmentFriendsBinding inflate(LayoutInflater layoutInflater) {
        return FragmentFriendsBinding.inflate(layoutInflater, null, false);
    }

    public static FragmentFriendsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558466, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return FragmentFriendsBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

