/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  com.makeramen.roundedimageview.RoundedImageView
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.makeramen.roundedimageview.RoundedImageView;

public final class ReceiveMessageBinding
implements ViewBinding {
    public final RoundedImageView messagerProfileImg;
    public final TextView receiverMesssage;
    private final RelativeLayout rootView;

    private ReceiveMessageBinding(RelativeLayout relativeLayout, RoundedImageView roundedImageView, TextView textView) {
        this.rootView = relativeLayout;
        this.messagerProfileImg = roundedImageView;
        this.receiverMesssage = textView;
    }

    public static ReceiveMessageBinding bind(View view) {
        TextView textView;
        int n = 2131362131;
        RoundedImageView roundedImageView = (RoundedImageView)ViewBindings.findChildViewById((View)view, (int)n);
        if (roundedImageView != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362210))) != null) {
            return new ReceiveMessageBinding((RelativeLayout)view, roundedImageView, textView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ReceiveMessageBinding inflate(LayoutInflater layoutInflater) {
        return ReceiveMessageBinding.inflate(layoutInflater, null, false);
    }

    public static ReceiveMessageBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558515, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ReceiveMessageBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

