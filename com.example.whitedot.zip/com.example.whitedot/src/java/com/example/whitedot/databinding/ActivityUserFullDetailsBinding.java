/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  com.makeramen.roundedimageview.RoundedImageView
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.makeramen.roundedimageview.RoundedImageView;

public final class ActivityUserFullDetailsBinding
implements ViewBinding {
    public final Button UpdateProfile;
    public final ImageView back;
    public final Button declineRequest;
    public final LinearLayout linearLayout;
    public final RoundedImageView profileImage;
    private final RelativeLayout rootView;
    public final Button sendMessage;
    public final TextView tvUsername;
    public final TextView tvstatus;

    private ActivityUserFullDetailsBinding(RelativeLayout relativeLayout, Button button, ImageView imageView, Button button2, LinearLayout linearLayout, RoundedImageView roundedImageView, Button button3, TextView textView, TextView textView2) {
        this.rootView = relativeLayout;
        this.UpdateProfile = button;
        this.back = imageView;
        this.declineRequest = button2;
        this.linearLayout = linearLayout;
        this.profileImage = roundedImageView;
        this.sendMessage = button3;
        this.tvUsername = textView;
        this.tvstatus = textView2;
    }

    public static ActivityUserFullDetailsBinding bind(View view) {
        TextView textView;
        Button button;
        ImageView imageView;
        LinearLayout linearLayout;
        Button button2;
        RoundedImageView roundedImageView;
        TextView textView2;
        int n = 2131361817;
        Button button3 = (Button)ViewBindings.findChildViewById((View)view, (int)n);
        if (button3 != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361897))) != null && (button2 = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131361974))) != null && (linearLayout = (LinearLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362110))) != null && (roundedImageView = (RoundedImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362200))) != null && (button = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131362251))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362370))) != null && (textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362371))) != null) {
            ActivityUserFullDetailsBinding activityUserFullDetailsBinding = new ActivityUserFullDetailsBinding((RelativeLayout)view, button3, imageView, button2, linearLayout, roundedImageView, button, textView, textView2);
            return activityUserFullDetailsBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivityUserFullDetailsBinding inflate(LayoutInflater layoutInflater) {
        return ActivityUserFullDetailsBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityUserFullDetailsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558436, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityUserFullDetailsBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

