/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.FrameLayout
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  com.cooltechworks.views.shimmer.ShimmerRecyclerView
 *  com.google.android.material.floatingactionbutton.FloatingActionButton
 *  com.makeramen.roundedimageview.RoundedImageView
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.makeramen.roundedimageview.RoundedImageView;

public final class FragmentStatusBinding
implements ViewBinding {
    public final ImageView Options;
    public final RoundedImageView addStory;
    public final ShimmerRecyclerView allStoryRv;
    public final TextView btnaccept;
    public final TextView btndecline;
    public final ImageView greendot;
    public final FrameLayout linearLayout2;
    public final ImageView logout;
    private final FrameLayout rootView;
    public final FloatingActionButton sendtoAddFriend;
    public final TextView statusPerson;
    public final TextView userName;
    public final View view;

    private FragmentStatusBinding(FrameLayout frameLayout, ImageView imageView, RoundedImageView roundedImageView, ShimmerRecyclerView shimmerRecyclerView, TextView textView, TextView textView2, ImageView imageView2, FrameLayout frameLayout2, ImageView imageView3, FloatingActionButton floatingActionButton, TextView textView3, TextView textView4, View view) {
        this.rootView = frameLayout;
        this.Options = imageView;
        this.addStory = roundedImageView;
        this.allStoryRv = shimmerRecyclerView;
        this.btnaccept = textView;
        this.btndecline = textView2;
        this.greendot = imageView2;
        this.linearLayout2 = frameLayout2;
        this.logout = imageView3;
        this.sendtoAddFriend = floatingActionButton;
        this.statusPerson = textView3;
        this.userName = textView4;
        this.view = view;
    }

    public static FragmentStatusBinding bind(View view) {
        ImageView imageView;
        TextView textView;
        TextView textView2;
        ShimmerRecyclerView shimmerRecyclerView;
        RoundedImageView roundedImageView;
        TextView textView3;
        ImageView imageView2;
        View view2;
        TextView textView4;
        FloatingActionButton floatingActionButton;
        FrameLayout frameLayout;
        int n = 2131361803;
        ImageView imageView3 = (ImageView)ViewBindings.findChildViewById((View)view, (int)n);
        if (imageView3 != null && (roundedImageView = (RoundedImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361877))) != null && (shimmerRecyclerView = (ShimmerRecyclerView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361885))) != null && (textView4 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361919))) != null && (textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361920))) != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362059))) != null && (frameLayout = (FrameLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362111))) != null && (imageView2 = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362116))) != null && (floatingActionButton = (FloatingActionButton)ViewBindings.findChildViewById((View)view, (int)(n = 2131362255))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362296))) != null && (textView3 = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362380))) != null && (view2 = ViewBindings.findChildViewById((View)view, (int)(n = 2131362382))) != null) {
            FragmentStatusBinding fragmentStatusBinding = new FragmentStatusBinding((FrameLayout)view, imageView3, roundedImageView, shimmerRecyclerView, textView4, textView2, imageView, frameLayout, imageView2, floatingActionButton, textView, textView3, view2);
            return fragmentStatusBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static FragmentStatusBinding inflate(LayoutInflater layoutInflater) {
        return FragmentStatusBinding.inflate(layoutInflater, null, false);
    }

    public static FragmentStatusBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558468, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return FragmentStatusBinding.bind(view);
    }

    public FrameLayout getRoot() {
        return this.rootView;
    }
}

