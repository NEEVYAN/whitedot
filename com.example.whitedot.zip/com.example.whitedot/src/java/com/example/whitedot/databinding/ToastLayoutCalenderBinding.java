/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ToastLayoutCalenderBinding
implements ViewBinding {
    public final TextView dateTime;
    private final LinearLayout rootView;
    public final ImageView toastCancel;
    public final ImageView toastImage;
    public final LinearLayout toastLayout;
    public final LinearLayout toastRoot;
    public final View toastView;

    private ToastLayoutCalenderBinding(LinearLayout linearLayout, TextView textView, ImageView imageView, ImageView imageView2, LinearLayout linearLayout2, LinearLayout linearLayout3, View view) {
        this.rootView = linearLayout;
        this.dateTime = textView;
        this.toastCancel = imageView;
        this.toastImage = imageView2;
        this.toastLayout = linearLayout2;
        this.toastRoot = linearLayout3;
        this.toastView = view;
    }

    public static ToastLayoutCalenderBinding bind(View view) {
        ImageView imageView;
        LinearLayout linearLayout;
        ImageView imageView2;
        int n = 2131361970;
        TextView textView = (TextView)ViewBindings.findChildViewById((View)view, (int)n);
        if (textView != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362349))) != null && (imageView2 = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362350))) != null && (linearLayout = (LinearLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362351))) != null) {
            LinearLayout linearLayout2 = (LinearLayout)view;
            n = 2131362353;
            View view2 = ViewBindings.findChildViewById((View)view, (int)n);
            if (view2 != null) {
                ToastLayoutCalenderBinding toastLayoutCalenderBinding = new ToastLayoutCalenderBinding((LinearLayout)view, textView, imageView, imageView2, linearLayout, linearLayout2, view2);
                return toastLayoutCalenderBinding;
            }
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ToastLayoutCalenderBinding inflate(LayoutInflater layoutInflater) {
        return ToastLayoutCalenderBinding.inflate(layoutInflater, null, false);
    }

    public static ToastLayoutCalenderBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558538, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ToastLayoutCalenderBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

