/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class SendMessageBinding
implements ViewBinding {
    private final RelativeLayout rootView;
    public final TextView senderMessage;

    private SendMessageBinding(RelativeLayout relativeLayout, TextView textView) {
        this.rootView = relativeLayout;
        this.senderMessage = textView;
    }

    public static SendMessageBinding bind(View view) {
        TextView textView = (TextView)ViewBindings.findChildViewById((View)view, (int)2131362254);
        if (textView != null) {
            return new SendMessageBinding((RelativeLayout)view, textView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(2131362254)));
    }

    public static SendMessageBinding inflate(LayoutInflater layoutInflater) {
        return SendMessageBinding.inflate(layoutInflater, null, false);
    }

    public static SendMessageBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558520, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return SendMessageBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

