/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class FragmentBottomSheet2Binding
implements ViewBinding {
    public final LinearLayout bottomSheet2;
    public final LinearLayout dismiss2;
    public final ImageView document;
    public final ImageView images;
    private final LinearLayout rootView;
    public final ImageView wordfile;

    private FragmentBottomSheet2Binding(LinearLayout linearLayout, LinearLayout linearLayout2, LinearLayout linearLayout3, ImageView imageView, ImageView imageView2, ImageView imageView3) {
        this.rootView = linearLayout;
        this.bottomSheet2 = linearLayout2;
        this.dismiss2 = linearLayout3;
        this.document = imageView;
        this.images = imageView2;
        this.wordfile = imageView3;
    }

    public static FragmentBottomSheet2Binding bind(View view) {
        ImageView imageView;
        ImageView imageView2;
        LinearLayout linearLayout = (LinearLayout)view;
        int n = 2131361992;
        LinearLayout linearLayout2 = (LinearLayout)ViewBindings.findChildViewById((View)view, (int)n);
        if (linearLayout2 != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361993))) != null && (imageView2 = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362087))) != null) {
            ImageView imageView3 = (ImageView)ViewBindings.findChildViewById((View)view, (int)2131362395);
            if (imageView3 != null) {
                FragmentBottomSheet2Binding fragmentBottomSheet2Binding = new FragmentBottomSheet2Binding((LinearLayout)view, linearLayout, linearLayout2, imageView, imageView2, imageView3);
                return fragmentBottomSheet2Binding;
            }
            n = 2131362395;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static FragmentBottomSheet2Binding inflate(LayoutInflater layoutInflater) {
        return FragmentBottomSheet2Binding.inflate(layoutInflater, null, false);
    }

    public static FragmentBottomSheet2Binding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558464, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return FragmentBottomSheet2Binding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

