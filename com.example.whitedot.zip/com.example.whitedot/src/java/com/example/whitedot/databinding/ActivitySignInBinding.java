/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.ProgressBar
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ActivitySignInBinding
implements ViewBinding {
    public final Button SignInBtn;
    public final TextView createAccount;
    public final EditText etEmail;
    public final EditText etPassword;
    public final ProgressBar progressBar;
    private final ScrollView rootView;
    public final Button tnc;

    private ActivitySignInBinding(ScrollView scrollView, Button button, TextView textView, EditText editText, EditText editText2, ProgressBar progressBar, Button button2) {
        this.rootView = scrollView;
        this.SignInBtn = button;
        this.createAccount = textView;
        this.etEmail = editText;
        this.etPassword = editText2;
        this.progressBar = progressBar;
        this.tnc = button2;
    }

    public static ActivitySignInBinding bind(View view) {
        Button button;
        EditText editText;
        EditText editText2;
        TextView textView;
        ProgressBar progressBar;
        int n = 2131361813;
        Button button2 = (Button)ViewBindings.findChildViewById((View)view, (int)n);
        if (button2 != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131361962))) != null && (editText = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362026))) != null && (editText2 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362027))) != null && (progressBar = (ProgressBar)ViewBindings.findChildViewById((View)view, (int)(n = 2131362201))) != null && (button = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131362348))) != null) {
            ActivitySignInBinding activitySignInBinding = new ActivitySignInBinding((ScrollView)view, button2, textView, editText, editText2, progressBar, button);
            return activitySignInBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivitySignInBinding inflate(LayoutInflater layoutInflater) {
        return ActivitySignInBinding.inflate(layoutInflater, null, false);
    }

    public static ActivitySignInBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558433, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivitySignInBinding.bind(view);
    }

    public ScrollView getRoot() {
        return this.rootView;
    }
}

