/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.FrameLayout
 *  android.widget.RelativeLayout
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  com.google.android.material.bottomnavigation.BottomNavigationView
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public final class ActivityChatBinding
implements ViewBinding {
    public final BottomNavigationView bottomNavigation;
    public final FrameLayout fragmentContainer;
    private final RelativeLayout rootView;

    private ActivityChatBinding(RelativeLayout relativeLayout, BottomNavigationView bottomNavigationView, FrameLayout frameLayout) {
        this.rootView = relativeLayout;
        this.bottomNavigation = bottomNavigationView;
        this.fragmentContainer = frameLayout;
    }

    public static ActivityChatBinding bind(View view) {
        FrameLayout frameLayout;
        int n = 2131361906;
        BottomNavigationView bottomNavigationView = (BottomNavigationView)ViewBindings.findChildViewById((View)view, (int)n);
        if (bottomNavigationView != null && (frameLayout = (FrameLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362044))) != null) {
            return new ActivityChatBinding((RelativeLayout)view, bottomNavigationView, frameLayout);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivityChatBinding inflate(LayoutInflater layoutInflater) {
        return ActivityChatBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityChatBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558428, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityChatBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

