/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class BottomsheetDialogueBinding
implements ViewBinding {
    public final LinearLayout bottomSheet;
    public final LinearLayout dismiss2;
    public final TextView find;
    public final TextView logout2;
    private final LinearLayout rootView;

    private BottomsheetDialogueBinding(LinearLayout linearLayout, LinearLayout linearLayout2, LinearLayout linearLayout3, TextView textView, TextView textView2) {
        this.rootView = linearLayout;
        this.bottomSheet = linearLayout2;
        this.dismiss2 = linearLayout3;
        this.find = textView;
        this.logout2 = textView2;
    }

    public static BottomsheetDialogueBinding bind(View view) {
        TextView textView;
        LinearLayout linearLayout = (LinearLayout)view;
        int n = 2131361992;
        LinearLayout linearLayout2 = (LinearLayout)ViewBindings.findChildViewById((View)view, (int)n);
        if (linearLayout2 != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362038))) != null) {
            TextView textView2 = (TextView)ViewBindings.findChildViewById((View)view, (int)2131362117);
            if (textView2 != null) {
                BottomsheetDialogueBinding bottomsheetDialogueBinding = new BottomsheetDialogueBinding((LinearLayout)view, linearLayout, linearLayout2, textView, textView2);
                return bottomsheetDialogueBinding;
            }
            n = 2131362117;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static BottomsheetDialogueBinding inflate(LayoutInflater layoutInflater) {
        return BottomsheetDialogueBinding.inflate(layoutInflater, null, false);
    }

    public static BottomsheetDialogueBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558437, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return BottomsheetDialogueBinding.bind(view);
    }

    public LinearLayout getRoot() {
        return this.rootView;
    }
}

