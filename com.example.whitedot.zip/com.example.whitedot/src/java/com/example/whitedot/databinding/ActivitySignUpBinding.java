/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.FrameLayout
 *  android.widget.ImageView
 *  android.widget.ProgressBar
 *  android.widget.ScrollView
 *  android.widget.TextView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  com.makeramen.roundedimageview.RoundedImageView
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;
import com.makeramen.roundedimageview.RoundedImageView;

public final class ActivitySignUpBinding
implements ViewBinding {
    public final EditText etConfirmPassword;
    public final EditText etEmail;
    public final EditText etPassword;
    public final EditText etStatus;
    public final EditText etUsername;
    public final ImageView image;
    public final RoundedImageView imageProfile;
    public final FrameLayout layoutImage;
    public final ProgressBar progressBar;
    private final ScrollView rootView;
    public final Button signUpBtn;
    public final TextView tvSignIn;

    private ActivitySignUpBinding(ScrollView scrollView, EditText editText, EditText editText2, EditText editText3, EditText editText4, EditText editText5, ImageView imageView, RoundedImageView roundedImageView, FrameLayout frameLayout, ProgressBar progressBar, Button button, TextView textView) {
        this.rootView = scrollView;
        this.etConfirmPassword = editText;
        this.etEmail = editText2;
        this.etPassword = editText3;
        this.etStatus = editText4;
        this.etUsername = editText5;
        this.image = imageView;
        this.imageProfile = roundedImageView;
        this.layoutImage = frameLayout;
        this.progressBar = progressBar;
        this.signUpBtn = button;
        this.tvSignIn = textView;
    }

    public static ActivitySignUpBinding bind(View view) {
        EditText editText;
        ImageView imageView;
        EditText editText2;
        ProgressBar progressBar;
        RoundedImageView roundedImageView;
        TextView textView;
        EditText editText3;
        FrameLayout frameLayout;
        EditText editText4;
        Button button;
        int n = 2131362025;
        EditText editText5 = (EditText)ViewBindings.findChildViewById((View)view, (int)n);
        if (editText5 != null && (editText = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362026))) != null && (editText3 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362027))) != null && (editText4 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362028))) != null && (editText2 = (EditText)ViewBindings.findChildViewById((View)view, (int)(n = 2131362029))) != null && (imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362077))) != null && (roundedImageView = (RoundedImageView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362079))) != null && (frameLayout = (FrameLayout)ViewBindings.findChildViewById((View)view, (int)(n = 2131362100))) != null && (progressBar = (ProgressBar)ViewBindings.findChildViewById((View)view, (int)(n = 2131362201))) != null && (button = (Button)ViewBindings.findChildViewById((View)view, (int)(n = 2131362262))) != null && (textView = (TextView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362369))) != null) {
            ActivitySignUpBinding activitySignUpBinding = new ActivitySignUpBinding((ScrollView)view, editText5, editText, editText3, editText4, editText2, imageView, roundedImageView, frameLayout, progressBar, button, textView);
            return activitySignUpBinding;
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivitySignUpBinding inflate(LayoutInflater layoutInflater) {
        return ActivitySignUpBinding.inflate(layoutInflater, null, false);
    }

    public static ActivitySignUpBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558434, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivitySignUpBinding.bind(view);
    }

    public ScrollView getRoot() {
        return this.rootView;
    }
}

