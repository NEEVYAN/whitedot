/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.viewbinding.ViewBinding
 *  androidx.viewbinding.ViewBindings
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package com.example.whitedot.databinding;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewbinding.ViewBinding;
import androidx.viewbinding.ViewBindings;

public final class ActivityFindFriendsBinding
implements ViewBinding {
    public final ImageView back;
    public final RecyclerView recyclerViewFriends;
    private final RelativeLayout rootView;

    private ActivityFindFriendsBinding(RelativeLayout relativeLayout, ImageView imageView, RecyclerView recyclerView) {
        this.rootView = relativeLayout;
        this.back = imageView;
        this.recyclerViewFriends = recyclerView;
    }

    public static ActivityFindFriendsBinding bind(View view) {
        RecyclerView recyclerView;
        int n = 2131361897;
        ImageView imageView = (ImageView)ViewBindings.findChildViewById((View)view, (int)n);
        if (imageView != null && (recyclerView = (RecyclerView)ViewBindings.findChildViewById((View)view, (int)(n = 2131362212))) != null) {
            return new ActivityFindFriendsBinding((RelativeLayout)view, imageView, recyclerView);
        }
        throw new NullPointerException("Missing required view with ID: ".concat(view.getResources().getResourceName(n)));
    }

    public static ActivityFindFriendsBinding inflate(LayoutInflater layoutInflater) {
        return ActivityFindFriendsBinding.inflate(layoutInflater, null, false);
    }

    public static ActivityFindFriendsBinding inflate(LayoutInflater layoutInflater, ViewGroup viewGroup, boolean bl) {
        View view = layoutInflater.inflate(2131558430, viewGroup, false);
        if (bl) {
            viewGroup.addView(view);
        }
        return ActivityFindFriendsBinding.bind(view);
    }

    public RelativeLayout getRoot() {
        return this.rootView;
    }
}

