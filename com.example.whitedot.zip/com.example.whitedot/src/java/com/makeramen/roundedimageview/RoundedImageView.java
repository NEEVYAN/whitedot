/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.graphics.ColorFilter
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.LayerDrawable
 *  android.net.Uri
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  java.lang.AssertionError
 *  java.lang.Deprecated
 *  java.lang.Exception
 *  java.lang.Math
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.makeramen.roundedimageview;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ImageView;
import com.makeramen.roundedimageview.R;
import com.makeramen.roundedimageview.RoundedDrawable;

public class RoundedImageView
extends ImageView {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    public static final float DEFAULT_BORDER_WIDTH = 0.0f;
    public static final float DEFAULT_RADIUS = 0.0f;
    public static final Shader.TileMode DEFAULT_TILE_MODE = Shader.TileMode.CLAMP;
    private static final ImageView.ScaleType[] SCALE_TYPES;
    public static final String TAG = "RoundedImageView";
    private static final int TILE_MODE_CLAMP = 0;
    private static final int TILE_MODE_MIRROR = 2;
    private static final int TILE_MODE_REPEAT = 1;
    private static final int TILE_MODE_UNDEFINED = -2;
    private Drawable mBackgroundDrawable;
    private int mBackgroundResource;
    private ColorStateList mBorderColor;
    private float mBorderWidth;
    private ColorFilter mColorFilter;
    private boolean mColorMod;
    private final float[] mCornerRadii;
    private Drawable mDrawable;
    private boolean mHasColorFilter;
    private boolean mIsOval;
    private boolean mMutateBackground;
    private int mResource;
    private ImageView.ScaleType mScaleType;
    private Shader.TileMode mTileModeX;
    private Shader.TileMode mTileModeY;

    static {
        ImageView.ScaleType[] arrscaleType = new ImageView.ScaleType[]{ImageView.ScaleType.MATRIX, ImageView.ScaleType.FIT_XY, ImageView.ScaleType.FIT_START, ImageView.ScaleType.FIT_CENTER, ImageView.ScaleType.FIT_END, ImageView.ScaleType.CENTER, ImageView.ScaleType.CENTER_CROP, ImageView.ScaleType.CENTER_INSIDE};
        SCALE_TYPES = arrscaleType;
    }

    public RoundedImageView(Context context) {
        Shader.TileMode tileMode;
        super(context);
        this.mCornerRadii = new float[]{0.0f, 0.0f, 0.0f, 0.0f};
        this.mBorderColor = ColorStateList.valueOf((int)-16777216);
        this.mBorderWidth = 0.0f;
        this.mColorFilter = null;
        this.mColorMod = false;
        this.mHasColorFilter = false;
        this.mIsOval = false;
        this.mMutateBackground = false;
        this.mTileModeX = tileMode = DEFAULT_TILE_MODE;
        this.mTileModeY = tileMode;
    }

    public RoundedImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public RoundedImageView(Context context, AttributeSet attributeSet, int n) {
        Shader.TileMode tileMode;
        float f;
        int n2;
        ColorStateList colorStateList;
        int n3;
        super(context, attributeSet, n);
        float[] arrf = new float[]{0.0f, 0.0f, 0.0f, 0.0f};
        this.mCornerRadii = arrf;
        this.mBorderColor = ColorStateList.valueOf((int)-16777216);
        this.mBorderWidth = 0.0f;
        this.mColorFilter = null;
        this.mColorMod = false;
        this.mHasColorFilter = false;
        this.mIsOval = false;
        this.mMutateBackground = false;
        this.mTileModeX = tileMode = DEFAULT_TILE_MODE;
        this.mTileModeY = tileMode;
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, R.styleable.RoundedImageView, n, 0);
        int n4 = typedArray.getInt(R.styleable.RoundedImageView_android_scaleType, -1);
        if (n4 >= 0) {
            this.setScaleType(SCALE_TYPES[n4]);
        } else {
            this.setScaleType(ImageView.ScaleType.FIT_CENTER);
        }
        float f2 = typedArray.getDimensionPixelSize(R.styleable.RoundedImageView_riv_corner_radius, -1);
        arrf[0] = typedArray.getDimensionPixelSize(R.styleable.RoundedImageView_riv_corner_radius_top_left, -1);
        arrf[1] = typedArray.getDimensionPixelSize(R.styleable.RoundedImageView_riv_corner_radius_top_right, -1);
        arrf[2] = typedArray.getDimensionPixelSize(R.styleable.RoundedImageView_riv_corner_radius_bottom_right, -1);
        arrf[3] = typedArray.getDimensionPixelSize(R.styleable.RoundedImageView_riv_corner_radius_bottom_left, -1);
        boolean bl = false;
        int n5 = arrf.length;
        for (int i = 0; i < n5; ++i) {
            float[] arrf2 = this.mCornerRadii;
            if (arrf2[i] < 0.0f) {
                arrf2[i] = 0.0f;
                continue;
            }
            bl = true;
        }
        if (!bl) {
            if (f2 < 0.0f) {
                f2 = 0.0f;
            }
            int n6 = this.mCornerRadii.length;
            for (int i = 0; i < n6; ++i) {
                this.mCornerRadii[i] = f2;
            }
        }
        this.mBorderWidth = f = (float)typedArray.getDimensionPixelSize(R.styleable.RoundedImageView_riv_border_width, -1);
        if (f < 0.0f) {
            this.mBorderWidth = 0.0f;
        }
        this.mBorderColor = colorStateList = typedArray.getColorStateList(R.styleable.RoundedImageView_riv_border_color);
        if (colorStateList == null) {
            this.mBorderColor = ColorStateList.valueOf((int)-16777216);
        }
        this.mMutateBackground = typedArray.getBoolean(R.styleable.RoundedImageView_riv_mutate_background, false);
        this.mIsOval = typedArray.getBoolean(R.styleable.RoundedImageView_riv_oval, false);
        int n7 = typedArray.getInt(R.styleable.RoundedImageView_riv_tile_mode, -2);
        if (n7 != -2) {
            this.setTileModeX(RoundedImageView.parseTileMode(n7));
            this.setTileModeY(RoundedImageView.parseTileMode(n7));
        }
        if ((n3 = typedArray.getInt(R.styleable.RoundedImageView_riv_tile_mode_x, -2)) != -2) {
            this.setTileModeX(RoundedImageView.parseTileMode(n3));
        }
        if ((n2 = typedArray.getInt(R.styleable.RoundedImageView_riv_tile_mode_y, -2)) != -2) {
            this.setTileModeY(RoundedImageView.parseTileMode(n2));
        }
        this.updateDrawableAttrs();
        this.updateBackgroundDrawableAttrs(true);
        if (this.mMutateBackground) {
            super.setBackgroundDrawable(this.mBackgroundDrawable);
        }
        typedArray.recycle();
    }

    private void applyColorMod() {
        Drawable drawable = this.mDrawable;
        if (drawable != null && this.mColorMod) {
            Drawable drawable2;
            this.mDrawable = drawable2 = drawable.mutate();
            if (this.mHasColorFilter) {
                drawable2.setColorFilter(this.mColorFilter);
            }
        }
    }

    private static Shader.TileMode parseTileMode(int n) {
        switch (n) {
            default: {
                return null;
            }
            case 2: {
                return Shader.TileMode.MIRROR;
            }
            case 1: {
                return Shader.TileMode.REPEAT;
            }
            case 0: 
        }
        return Shader.TileMode.CLAMP;
    }

    private Drawable resolveBackgroundResource() {
        Resources resources = this.getResources();
        if (resources == null) {
            return null;
        }
        int n = this.mBackgroundResource;
        Drawable drawable = null;
        if (n != 0) {
            try {
                Drawable drawable2;
                drawable = drawable2 = resources.getDrawable(n);
            }
            catch (Exception exception) {
                Log.w((String)TAG, (String)("Unable to find resource: " + this.mBackgroundResource), (Throwable)exception);
                this.mBackgroundResource = 0;
            }
        }
        return RoundedDrawable.fromDrawable(drawable);
    }

    private Drawable resolveResource() {
        Resources resources = this.getResources();
        if (resources == null) {
            return null;
        }
        int n = this.mResource;
        Drawable drawable = null;
        if (n != 0) {
            try {
                Drawable drawable2;
                drawable = drawable2 = resources.getDrawable(n);
            }
            catch (Exception exception) {
                Log.w((String)TAG, (String)("Unable to find resource: " + this.mResource), (Throwable)exception);
                this.mResource = 0;
            }
        }
        return RoundedDrawable.fromDrawable(drawable);
    }

    private void updateAttrs(Drawable drawable, ImageView.ScaleType scaleType) {
        if (drawable == null) {
            return;
        }
        if (drawable instanceof RoundedDrawable) {
            ((RoundedDrawable)drawable).setScaleType(scaleType).setBorderWidth(this.mBorderWidth).setBorderColor(this.mBorderColor).setOval(this.mIsOval).setTileModeX(this.mTileModeX).setTileModeY(this.mTileModeY);
            float[] arrf = this.mCornerRadii;
            if (arrf != null) {
                ((RoundedDrawable)drawable).setCornerRadius(arrf[0], arrf[1], arrf[2], arrf[3]);
            }
            this.applyColorMod();
            return;
        }
        if (drawable instanceof LayerDrawable) {
            LayerDrawable layerDrawable = (LayerDrawable)drawable;
            int n = layerDrawable.getNumberOfLayers();
            for (int i = 0; i < n; ++i) {
                this.updateAttrs(layerDrawable.getDrawable(i), scaleType);
            }
        }
    }

    private void updateBackgroundDrawableAttrs(boolean bl) {
        if (this.mMutateBackground) {
            if (bl) {
                this.mBackgroundDrawable = RoundedDrawable.fromDrawable(this.mBackgroundDrawable);
            }
            this.updateAttrs(this.mBackgroundDrawable, ImageView.ScaleType.FIT_XY);
        }
    }

    private void updateDrawableAttrs() {
        this.updateAttrs(this.mDrawable, this.mScaleType);
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        this.invalidate();
    }

    public int getBorderColor() {
        return this.mBorderColor.getDefaultColor();
    }

    public ColorStateList getBorderColors() {
        return this.mBorderColor;
    }

    public float getBorderWidth() {
        return this.mBorderWidth;
    }

    public float getCornerRadius() {
        return this.getMaxCornerRadius();
    }

    public float getCornerRadius(int n) {
        return this.mCornerRadii[n];
    }

    public float getMaxCornerRadius() {
        float f = 0.0f;
        float[] arrf = this.mCornerRadii;
        int n = arrf.length;
        for (int i = 0; i < n; ++i) {
            f = Math.max((float)arrf[i], (float)f);
        }
        return f;
    }

    public ImageView.ScaleType getScaleType() {
        return this.mScaleType;
    }

    public Shader.TileMode getTileModeX() {
        return this.mTileModeX;
    }

    public Shader.TileMode getTileModeY() {
        return this.mTileModeY;
    }

    public boolean isOval() {
        return this.mIsOval;
    }

    public void mutateBackground(boolean bl) {
        if (this.mMutateBackground == bl) {
            return;
        }
        this.mMutateBackground = bl;
        this.updateBackgroundDrawableAttrs(true);
        this.invalidate();
    }

    public boolean mutatesBackground() {
        return this.mMutateBackground;
    }

    public void setBackground(Drawable drawable) {
        this.setBackgroundDrawable(drawable);
    }

    public void setBackgroundColor(int n) {
        ColorDrawable colorDrawable = new ColorDrawable(n);
        this.mBackgroundDrawable = colorDrawable;
        this.setBackgroundDrawable((Drawable)colorDrawable);
    }

    @Deprecated
    public void setBackgroundDrawable(Drawable drawable) {
        this.mBackgroundDrawable = drawable;
        this.updateBackgroundDrawableAttrs(true);
        super.setBackgroundDrawable(this.mBackgroundDrawable);
    }

    public void setBackgroundResource(int n) {
        if (this.mBackgroundResource != n) {
            Drawable drawable;
            this.mBackgroundResource = n;
            this.mBackgroundDrawable = drawable = this.resolveBackgroundResource();
            this.setBackgroundDrawable(drawable);
        }
    }

    public void setBorderColor(int n) {
        this.setBorderColor(ColorStateList.valueOf((int)n));
    }

    public void setBorderColor(ColorStateList colorStateList) {
        if (this.mBorderColor.equals((Object)colorStateList)) {
            return;
        }
        ColorStateList colorStateList2 = colorStateList != null ? colorStateList : ColorStateList.valueOf((int)-16777216);
        this.mBorderColor = colorStateList2;
        this.updateDrawableAttrs();
        this.updateBackgroundDrawableAttrs(false);
        if (this.mBorderWidth > 0.0f) {
            this.invalidate();
        }
    }

    public void setBorderWidth(float f) {
        if (this.mBorderWidth == f) {
            return;
        }
        this.mBorderWidth = f;
        this.updateDrawableAttrs();
        this.updateBackgroundDrawableAttrs(false);
        this.invalidate();
    }

    public void setBorderWidth(int n) {
        this.setBorderWidth(this.getResources().getDimension(n));
    }

    public void setColorFilter(ColorFilter colorFilter) {
        if (this.mColorFilter != colorFilter) {
            this.mColorFilter = colorFilter;
            this.mHasColorFilter = true;
            this.mColorMod = true;
            this.applyColorMod();
            this.invalidate();
        }
    }

    public void setCornerRadius(float f) {
        this.setCornerRadius(f, f, f, f);
    }

    public void setCornerRadius(float f, float f2, float f3, float f4) {
        float[] arrf = this.mCornerRadii;
        if (arrf[0] == f && arrf[1] == f2 && arrf[2] == f4 && arrf[3] == f3) {
            return;
        }
        arrf[0] = f;
        arrf[1] = f2;
        arrf[3] = f3;
        arrf[2] = f4;
        this.updateDrawableAttrs();
        this.updateBackgroundDrawableAttrs(false);
        this.invalidate();
    }

    public void setCornerRadius(int n, float f) {
        float[] arrf = this.mCornerRadii;
        if (arrf[n] == f) {
            return;
        }
        arrf[n] = f;
        this.updateDrawableAttrs();
        this.updateBackgroundDrawableAttrs(false);
        this.invalidate();
    }

    public void setCornerRadiusDimen(int n) {
        float f = this.getResources().getDimension(n);
        this.setCornerRadius(f, f, f, f);
    }

    public void setCornerRadiusDimen(int n, int n2) {
        this.setCornerRadius(n, this.getResources().getDimensionPixelSize(n2));
    }

    public void setImageBitmap(Bitmap bitmap) {
        this.mResource = 0;
        this.mDrawable = RoundedDrawable.fromBitmap(bitmap);
        this.updateDrawableAttrs();
        super.setImageDrawable(this.mDrawable);
    }

    public void setImageDrawable(Drawable drawable) {
        this.mResource = 0;
        this.mDrawable = RoundedDrawable.fromDrawable(drawable);
        this.updateDrawableAttrs();
        super.setImageDrawable(this.mDrawable);
    }

    public void setImageResource(int n) {
        if (this.mResource != n) {
            this.mResource = n;
            this.mDrawable = this.resolveResource();
            this.updateDrawableAttrs();
            super.setImageDrawable(this.mDrawable);
        }
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        this.setImageDrawable(this.getDrawable());
    }

    public void setOval(boolean bl) {
        this.mIsOval = bl;
        this.updateDrawableAttrs();
        this.updateBackgroundDrawableAttrs(false);
        this.invalidate();
    }

    public void setScaleType(ImageView.ScaleType scaleType) {
        if (scaleType != null) {
            if (this.mScaleType != scaleType) {
                this.mScaleType = scaleType;
                switch (1.$SwitchMap$android$widget$ImageView$ScaleType[scaleType.ordinal()]) {
                    default: {
                        super.setScaleType(scaleType);
                        break;
                    }
                    case 1: 
                    case 2: 
                    case 3: 
                    case 4: 
                    case 5: 
                    case 6: 
                    case 7: {
                        super.setScaleType(ImageView.ScaleType.FIT_XY);
                    }
                }
                this.updateDrawableAttrs();
                this.updateBackgroundDrawableAttrs(false);
                this.invalidate();
            }
            return;
        }
        throw new AssertionError();
    }

    public void setTileModeX(Shader.TileMode tileMode) {
        if (this.mTileModeX == tileMode) {
            return;
        }
        this.mTileModeX = tileMode;
        this.updateDrawableAttrs();
        this.updateBackgroundDrawableAttrs(false);
        this.invalidate();
    }

    public void setTileModeY(Shader.TileMode tileMode) {
        if (this.mTileModeY == tileMode) {
            return;
        }
        this.mTileModeY = tileMode;
        this.updateDrawableAttrs();
        this.updateBackgroundDrawableAttrs(false);
        this.invalidate();
    }

}

