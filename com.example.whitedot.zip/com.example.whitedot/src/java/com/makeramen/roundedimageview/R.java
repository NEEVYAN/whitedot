/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.makeramen.roundedimageview;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int riv_border_color = 2130969287;
        public static final int riv_border_width = 2130969288;
        public static final int riv_corner_radius = 2130969289;
        public static final int riv_corner_radius_bottom_left = 2130969290;
        public static final int riv_corner_radius_bottom_right = 2130969291;
        public static final int riv_corner_radius_top_left = 2130969292;
        public static final int riv_corner_radius_top_right = 2130969293;
        public static final int riv_mutate_background = 2130969294;
        public static final int riv_oval = 2130969295;
        public static final int riv_tile_mode = 2130969296;
        public static final int riv_tile_mode_x = 2130969297;
        public static final int riv_tile_mode_y = 2130969298;

        private attr() {
        }
    }

    public static final class id {
        public static final int clamp = 2131361942;
        public static final int mirror = 2131362134;
        public static final int repeat = 2131362214;

        private id() {
        }
    }

    public static final class string {
        public static final int define_roundedimageview = 2131951675;
        public static final int library_roundedimageview_author = 2131951699;
        public static final int library_roundedimageview_authorWebsite = 2131951700;
        public static final int library_roundedimageview_isOpenSource = 2131951701;
        public static final int library_roundedimageview_libraryDescription = 2131951702;
        public static final int library_roundedimageview_libraryName = 2131951703;
        public static final int library_roundedimageview_libraryVersion = 2131951704;
        public static final int library_roundedimageview_libraryWebsite = 2131951705;
        public static final int library_roundedimageview_licenseId = 2131951706;
        public static final int library_roundedimageview_repositoryLink = 2131951707;

        private string() {
        }
    }

    public static final class styleable {
        public static final int[] RoundedImageView = new int[]{16843037, 2130969287, 2130969288, 2130969289, 2130969290, 2130969291, 2130969292, 2130969293, 2130969294, 2130969295, 2130969296, 2130969297, 2130969298};
        public static final int RoundedImageView_android_scaleType = 0;
        public static final int RoundedImageView_riv_border_color = 1;
        public static final int RoundedImageView_riv_border_width = 2;
        public static final int RoundedImageView_riv_corner_radius = 3;
        public static final int RoundedImageView_riv_corner_radius_bottom_left = 4;
        public static final int RoundedImageView_riv_corner_radius_bottom_right = 5;
        public static final int RoundedImageView_riv_corner_radius_top_left = 6;
        public static final int RoundedImageView_riv_corner_radius_top_right = 7;
        public static final int RoundedImageView_riv_mutate_background = 8;
        public static final int RoundedImageView_riv_oval = 9;
        public static final int RoundedImageView_riv_tile_mode = 10;
        public static final int RoundedImageView_riv_tile_mode_x = 11;
        public static final int RoundedImageView_riv_tile_mode_y = 12;

        private styleable() {
        }
    }

}

