/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.ColorStateList
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapShader
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.Matrix
 *  android.graphics.Matrix$ScaleToFit
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.LayerDrawable
 *  android.util.Log
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashSet
 *  java.util.Iterator
 */
package com.makeramen.roundedimageview;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.Log;
import android.widget.ImageView;
import java.util.HashSet;
import java.util.Iterator;

public class RoundedDrawable
extends Drawable {
    public static final int DEFAULT_BORDER_COLOR = -16777216;
    public static final String TAG = "RoundedDrawable";
    private final Bitmap mBitmap;
    private final int mBitmapHeight;
    private final Paint mBitmapPaint;
    private final RectF mBitmapRect;
    private final int mBitmapWidth;
    private ColorStateList mBorderColor;
    private final Paint mBorderPaint;
    private final RectF mBorderRect;
    private float mBorderWidth;
    private final RectF mBounds = new RectF();
    private float mCornerRadius;
    private final boolean[] mCornersRounded;
    private final RectF mDrawableRect = new RectF();
    private boolean mOval;
    private boolean mRebuildShader;
    private ImageView.ScaleType mScaleType;
    private final Matrix mShaderMatrix;
    private final RectF mSquareCornersRect;
    private Shader.TileMode mTileModeX;
    private Shader.TileMode mTileModeY;

    public RoundedDrawable(Bitmap bitmap) {
        Paint paint;
        int n;
        int n2;
        Paint paint2;
        RectF rectF;
        this.mBitmapRect = rectF = new RectF();
        this.mBorderRect = new RectF();
        this.mShaderMatrix = new Matrix();
        this.mSquareCornersRect = new RectF();
        this.mTileModeX = Shader.TileMode.CLAMP;
        this.mTileModeY = Shader.TileMode.CLAMP;
        this.mRebuildShader = true;
        this.mCornerRadius = 0.0f;
        this.mCornersRounded = new boolean[]{true, true, true, true};
        this.mOval = false;
        this.mBorderWidth = 0.0f;
        this.mBorderColor = ColorStateList.valueOf((int)-16777216);
        this.mScaleType = ImageView.ScaleType.FIT_CENTER;
        this.mBitmap = bitmap;
        this.mBitmapWidth = n = bitmap.getWidth();
        this.mBitmapHeight = n2 = bitmap.getHeight();
        rectF.set(0.0f, 0.0f, (float)n, (float)n2);
        this.mBitmapPaint = paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        this.mBorderPaint = paint2 = new Paint();
        paint2.setStyle(Paint.Style.STROKE);
        paint2.setAntiAlias(true);
        paint2.setColor(this.mBorderColor.getColorForState(this.getState(), -16777216));
        paint2.setStrokeWidth(this.mBorderWidth);
    }

    private static boolean all(boolean[] arrbl) {
        int n = arrbl.length;
        for (int i = 0; i < n; ++i) {
            if (!arrbl[i]) continue;
            return false;
        }
        return true;
    }

    private static boolean any(boolean[] arrbl) {
        int n = arrbl.length;
        for (int i = 0; i < n; ++i) {
            if (!arrbl[i]) continue;
            return true;
        }
        return false;
    }

    public static Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable)drawable).getBitmap();
        }
        int n = Math.max((int)drawable.getIntrinsicWidth(), (int)2);
        int n2 = Math.max((int)drawable.getIntrinsicHeight(), (int)2);
        try {
            Bitmap bitmap = Bitmap.createBitmap((int)n, (int)n2, (Bitmap.Config)Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);
            return bitmap;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            Log.w((String)TAG, (String)"Failed to create bitmap from drawable!");
            return null;
        }
    }

    public static RoundedDrawable fromBitmap(Bitmap bitmap) {
        if (bitmap != null) {
            return new RoundedDrawable(bitmap);
        }
        return null;
    }

    public static Drawable fromDrawable(Drawable drawable) {
        if (drawable != null) {
            if (drawable instanceof RoundedDrawable) {
                return drawable;
            }
            if (drawable instanceof LayerDrawable) {
                LayerDrawable layerDrawable = (LayerDrawable)drawable;
                int n = layerDrawable.getNumberOfLayers();
                for (int i = 0; i < n; ++i) {
                    Drawable drawable2 = layerDrawable.getDrawable(i);
                    layerDrawable.setDrawableByLayerId(layerDrawable.getId(i), RoundedDrawable.fromDrawable(drawable2));
                }
                return layerDrawable;
            }
            Bitmap bitmap = RoundedDrawable.drawableToBitmap(drawable);
            if (bitmap != null) {
                return new RoundedDrawable(bitmap);
            }
        }
        return drawable;
    }

    private static boolean only(int n, boolean[] arrbl) {
        boolean bl;
        int n2 = 0;
        int n3 = arrbl.length;
        do {
            bl = true;
            if (n2 >= n3) break;
            boolean bl2 = arrbl[n2];
            if (n2 != n) {
                bl = false;
            }
            if (bl2 != bl) {
                return false;
            }
            ++n2;
        } while (true);
        return bl;
    }

    private void redrawBitmapForSquareCorners(Canvas canvas) {
        if (RoundedDrawable.all(this.mCornersRounded)) {
            return;
        }
        if (this.mCornerRadius == 0.0f) {
            return;
        }
        float f = this.mDrawableRect.left;
        float f2 = this.mDrawableRect.top;
        float f3 = f + this.mDrawableRect.width();
        float f4 = f2 + this.mDrawableRect.height();
        float f5 = this.mCornerRadius;
        if (!this.mCornersRounded[0]) {
            this.mSquareCornersRect.set(f, f2, f + f5, f2 + f5);
            canvas.drawRect(this.mSquareCornersRect, this.mBitmapPaint);
        }
        if (!this.mCornersRounded[1]) {
            this.mSquareCornersRect.set(f3 - f5, f2, f3, f5);
            canvas.drawRect(this.mSquareCornersRect, this.mBitmapPaint);
        }
        if (!this.mCornersRounded[2]) {
            this.mSquareCornersRect.set(f3 - f5, f4 - f5, f3, f4);
            canvas.drawRect(this.mSquareCornersRect, this.mBitmapPaint);
        }
        if (!this.mCornersRounded[3]) {
            this.mSquareCornersRect.set(f, f4 - f5, f + f5, f4);
            canvas.drawRect(this.mSquareCornersRect, this.mBitmapPaint);
        }
    }

    private void redrawBorderForSquareCorners(Canvas canvas) {
        if (RoundedDrawable.all(this.mCornersRounded)) {
            return;
        }
        if (this.mCornerRadius == 0.0f) {
            return;
        }
        float f = this.mDrawableRect.left;
        float f2 = this.mDrawableRect.top;
        float f3 = f + this.mDrawableRect.width();
        float f4 = f2 + this.mDrawableRect.height();
        float f5 = this.mCornerRadius;
        float f6 = this.mBorderWidth / 2.0f;
        if (!this.mCornersRounded[0]) {
            canvas.drawLine(f - f6, f2, f + f5, f2, this.mBorderPaint);
            canvas.drawLine(f, f2 - f6, f, f2 + f5, this.mBorderPaint);
        }
        if (!this.mCornersRounded[1]) {
            canvas.drawLine(f3 - f5 - f6, f2, f3, f2, this.mBorderPaint);
            canvas.drawLine(f3, f2 - f6, f3, f2 + f5, this.mBorderPaint);
        }
        if (!this.mCornersRounded[2]) {
            canvas.drawLine(f3 - f5 - f6, f4, f3 + f6, f4, this.mBorderPaint);
            canvas.drawLine(f3, f4 - f5, f3, f4, this.mBorderPaint);
        }
        if (!this.mCornersRounded[3]) {
            canvas.drawLine(f - f6, f4, f + f5, f4, this.mBorderPaint);
            canvas.drawLine(f, f4 - f5, f, f4, this.mBorderPaint);
        }
    }

    private void updateShaderMatrix() {
        switch (1.$SwitchMap$android$widget$ImageView$ScaleType[this.mScaleType.ordinal()]) {
            default: {
                this.mBorderRect.set(this.mBitmapRect);
                this.mShaderMatrix.setRectToRect(this.mBitmapRect, this.mBounds, Matrix.ScaleToFit.CENTER);
                this.mShaderMatrix.mapRect(this.mBorderRect);
                RectF rectF = this.mBorderRect;
                float f = this.mBorderWidth;
                rectF.inset(f / 2.0f, f / 2.0f);
                this.mShaderMatrix.setRectToRect(this.mBitmapRect, this.mBorderRect, Matrix.ScaleToFit.FILL);
                break;
            }
            case 7: {
                this.mBorderRect.set(this.mBounds);
                RectF rectF = this.mBorderRect;
                float f = this.mBorderWidth;
                rectF.inset(f / 2.0f, f / 2.0f);
                this.mShaderMatrix.reset();
                this.mShaderMatrix.setRectToRect(this.mBitmapRect, this.mBorderRect, Matrix.ScaleToFit.FILL);
                break;
            }
            case 6: {
                this.mBorderRect.set(this.mBitmapRect);
                this.mShaderMatrix.setRectToRect(this.mBitmapRect, this.mBounds, Matrix.ScaleToFit.START);
                this.mShaderMatrix.mapRect(this.mBorderRect);
                RectF rectF = this.mBorderRect;
                float f = this.mBorderWidth;
                rectF.inset(f / 2.0f, f / 2.0f);
                this.mShaderMatrix.setRectToRect(this.mBitmapRect, this.mBorderRect, Matrix.ScaleToFit.FILL);
                break;
            }
            case 5: {
                this.mBorderRect.set(this.mBitmapRect);
                this.mShaderMatrix.setRectToRect(this.mBitmapRect, this.mBounds, Matrix.ScaleToFit.END);
                this.mShaderMatrix.mapRect(this.mBorderRect);
                RectF rectF = this.mBorderRect;
                float f = this.mBorderWidth;
                rectF.inset(f / 2.0f, f / 2.0f);
                this.mShaderMatrix.setRectToRect(this.mBitmapRect, this.mBorderRect, Matrix.ScaleToFit.FILL);
                break;
            }
            case 3: {
                this.mShaderMatrix.reset();
                float f = (float)this.mBitmapWidth <= this.mBounds.width() && (float)this.mBitmapHeight <= this.mBounds.height() ? 1.0f : Math.min((float)(this.mBounds.width() / (float)this.mBitmapWidth), (float)(this.mBounds.height() / (float)this.mBitmapHeight));
                float f2 = (int)(0.5f + 0.5f * (this.mBounds.width() - f * (float)this.mBitmapWidth));
                float f3 = (int)(0.5f + 0.5f * (this.mBounds.height() - f * (float)this.mBitmapHeight));
                this.mShaderMatrix.setScale(f, f);
                this.mShaderMatrix.postTranslate(f2, f3);
                this.mBorderRect.set(this.mBitmapRect);
                this.mShaderMatrix.mapRect(this.mBorderRect);
                RectF rectF = this.mBorderRect;
                float f4 = this.mBorderWidth;
                rectF.inset(f4 / 2.0f, f4 / 2.0f);
                this.mShaderMatrix.setRectToRect(this.mBitmapRect, this.mBorderRect, Matrix.ScaleToFit.FILL);
                break;
            }
            case 2: {
                float f;
                float f5;
                this.mBorderRect.set(this.mBounds);
                RectF rectF = this.mBorderRect;
                float f6 = this.mBorderWidth;
                rectF.inset(f6 / 2.0f, f6 / 2.0f);
                this.mShaderMatrix.reset();
                float f7 = 0.0f;
                if ((float)this.mBitmapWidth * this.mBorderRect.height() > this.mBorderRect.width() * (float)this.mBitmapHeight) {
                    f = this.mBorderRect.height() / (float)this.mBitmapHeight;
                    f7 = 0.5f * (this.mBorderRect.width() - f * (float)this.mBitmapWidth);
                    f5 = 0.0f;
                } else {
                    f = this.mBorderRect.width() / (float)this.mBitmapWidth;
                    f5 = 0.5f * (this.mBorderRect.height() - f * (float)this.mBitmapHeight);
                }
                this.mShaderMatrix.setScale(f, f);
                Matrix matrix = this.mShaderMatrix;
                float f8 = (int)(f7 + 0.5f);
                float f9 = this.mBorderWidth;
                matrix.postTranslate(f8 + f9 / 2.0f, (float)((int)(0.5f + f5)) + f9 / 2.0f);
                break;
            }
            case 1: {
                this.mBorderRect.set(this.mBounds);
                RectF rectF = this.mBorderRect;
                float f = this.mBorderWidth;
                rectF.inset(f / 2.0f, f / 2.0f);
                this.mShaderMatrix.reset();
                this.mShaderMatrix.setTranslate((float)((int)(0.5f + 0.5f * (this.mBorderRect.width() - (float)this.mBitmapWidth))), (float)((int)(0.5f + 0.5f * (this.mBorderRect.height() - (float)this.mBitmapHeight))));
            }
        }
        this.mDrawableRect.set(this.mBorderRect);
    }

    public void draw(Canvas canvas) {
        if (this.mRebuildShader) {
            BitmapShader bitmapShader = new BitmapShader(this.mBitmap, this.mTileModeX, this.mTileModeY);
            if (this.mTileModeX == Shader.TileMode.CLAMP && this.mTileModeY == Shader.TileMode.CLAMP) {
                bitmapShader.setLocalMatrix(this.mShaderMatrix);
            }
            this.mBitmapPaint.setShader((Shader)bitmapShader);
            this.mRebuildShader = false;
        }
        if (this.mOval) {
            if (this.mBorderWidth > 0.0f) {
                canvas.drawOval(this.mDrawableRect, this.mBitmapPaint);
                canvas.drawOval(this.mBorderRect, this.mBorderPaint);
                return;
            }
            canvas.drawOval(this.mDrawableRect, this.mBitmapPaint);
            return;
        }
        if (RoundedDrawable.any(this.mCornersRounded)) {
            float f = this.mCornerRadius;
            if (this.mBorderWidth > 0.0f) {
                canvas.drawRoundRect(this.mDrawableRect, f, f, this.mBitmapPaint);
                canvas.drawRoundRect(this.mBorderRect, f, f, this.mBorderPaint);
                this.redrawBitmapForSquareCorners(canvas);
                this.redrawBorderForSquareCorners(canvas);
            } else {
                canvas.drawRoundRect(this.mDrawableRect, f, f, this.mBitmapPaint);
                this.redrawBitmapForSquareCorners(canvas);
            }
            return;
        }
        canvas.drawRect(this.mDrawableRect, this.mBitmapPaint);
        if (this.mBorderWidth > 0.0f) {
            canvas.drawRect(this.mBorderRect, this.mBorderPaint);
        }
    }

    public int getAlpha() {
        return this.mBitmapPaint.getAlpha();
    }

    public int getBorderColor() {
        return this.mBorderColor.getDefaultColor();
    }

    public ColorStateList getBorderColors() {
        return this.mBorderColor;
    }

    public float getBorderWidth() {
        return this.mBorderWidth;
    }

    public ColorFilter getColorFilter() {
        return this.mBitmapPaint.getColorFilter();
    }

    public float getCornerRadius() {
        return this.mCornerRadius;
    }

    public float getCornerRadius(int n) {
        if (this.mCornersRounded[n]) {
            return this.mCornerRadius;
        }
        return 0.0f;
    }

    public int getIntrinsicHeight() {
        return this.mBitmapHeight;
    }

    public int getIntrinsicWidth() {
        return this.mBitmapWidth;
    }

    public int getOpacity() {
        return -3;
    }

    public ImageView.ScaleType getScaleType() {
        return this.mScaleType;
    }

    public Bitmap getSourceBitmap() {
        return this.mBitmap;
    }

    public Shader.TileMode getTileModeX() {
        return this.mTileModeX;
    }

    public Shader.TileMode getTileModeY() {
        return this.mTileModeY;
    }

    public boolean isOval() {
        return this.mOval;
    }

    public boolean isStateful() {
        return this.mBorderColor.isStateful();
    }

    protected void onBoundsChange(Rect rect) {
        super.onBoundsChange(rect);
        this.mBounds.set(rect);
        this.updateShaderMatrix();
    }

    protected boolean onStateChange(int[] arrn) {
        int n = this.mBorderColor.getColorForState(arrn, 0);
        if (this.mBorderPaint.getColor() != n) {
            this.mBorderPaint.setColor(n);
            return true;
        }
        return super.onStateChange(arrn);
    }

    public void setAlpha(int n) {
        this.mBitmapPaint.setAlpha(n);
        this.invalidateSelf();
    }

    public RoundedDrawable setBorderColor(int n) {
        return this.setBorderColor(ColorStateList.valueOf((int)n));
    }

    public RoundedDrawable setBorderColor(ColorStateList colorStateList) {
        ColorStateList colorStateList2 = colorStateList != null ? colorStateList : ColorStateList.valueOf((int)0);
        this.mBorderColor = colorStateList2;
        this.mBorderPaint.setColor(colorStateList2.getColorForState(this.getState(), -16777216));
        return this;
    }

    public RoundedDrawable setBorderWidth(float f) {
        this.mBorderWidth = f;
        this.mBorderPaint.setStrokeWidth(f);
        return this;
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.mBitmapPaint.setColorFilter(colorFilter);
        this.invalidateSelf();
    }

    public RoundedDrawable setCornerRadius(float f) {
        this.setCornerRadius(f, f, f, f);
        return this;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public RoundedDrawable setCornerRadius(float f, float f2, float f3, float f4) {
        HashSet hashSet = new HashSet(4);
        hashSet.add((Object)Float.valueOf((float)f));
        hashSet.add((Object)Float.valueOf((float)f2));
        hashSet.add((Object)Float.valueOf((float)f3));
        hashSet.add((Object)Float.valueOf((float)f4));
        hashSet.remove((Object)Float.valueOf((float)0.0f));
        int n = hashSet.size();
        int n2 = 1;
        if (n > n2) throw new IllegalArgumentException("Multiple nonzero corner radii not yet supported.");
        if (!hashSet.isEmpty()) {
            float f5 = ((Float)hashSet.iterator().next()).floatValue();
            if (Float.isInfinite((float)f5) || Float.isNaN((float)f5) || f5 < 0.0f) throw new IllegalArgumentException("Invalid radius value: " + f5);
            this.mCornerRadius = f5;
        } else {
            this.mCornerRadius = 0.0f;
        }
        boolean[] arrbl = this.mCornersRounded;
        int n3 = f > 0.0f ? n2 : 0;
        arrbl[0] = n3;
        int n4 = f2 > 0.0f ? n2 : 0;
        arrbl[n2] = n4;
        int n5 = f3 > 0.0f ? n2 : 0;
        arrbl[2] = n5;
        if (!(f4 > 0.0f)) {
            n2 = 0;
        }
        arrbl[3] = n2;
        return this;
    }

    public RoundedDrawable setCornerRadius(int n, float f) {
        float f2;
        if (f != 0.0f && (f2 = this.mCornerRadius) != 0.0f && f2 != f) {
            throw new IllegalArgumentException("Multiple nonzero corner radii not yet supported.");
        }
        if (f == 0.0f) {
            if (RoundedDrawable.only(n, this.mCornersRounded)) {
                this.mCornerRadius = 0.0f;
            }
            this.mCornersRounded[n] = false;
            return this;
        }
        if (this.mCornerRadius == 0.0f) {
            this.mCornerRadius = f;
        }
        this.mCornersRounded[n] = true;
        return this;
    }

    public void setDither(boolean bl) {
        this.mBitmapPaint.setDither(bl);
        this.invalidateSelf();
    }

    public void setFilterBitmap(boolean bl) {
        this.mBitmapPaint.setFilterBitmap(bl);
        this.invalidateSelf();
    }

    public RoundedDrawable setOval(boolean bl) {
        this.mOval = bl;
        return this;
    }

    public RoundedDrawable setScaleType(ImageView.ScaleType scaleType) {
        if (scaleType == null) {
            scaleType = ImageView.ScaleType.FIT_CENTER;
        }
        if (this.mScaleType != scaleType) {
            this.mScaleType = scaleType;
            this.updateShaderMatrix();
        }
        return this;
    }

    public RoundedDrawable setTileModeX(Shader.TileMode tileMode) {
        if (this.mTileModeX != tileMode) {
            this.mTileModeX = tileMode;
            this.mRebuildShader = true;
            this.invalidateSelf();
        }
        return this;
    }

    public RoundedDrawable setTileModeY(Shader.TileMode tileMode) {
        if (this.mTileModeY != tileMode) {
            this.mTileModeY = tileMode;
            this.mRebuildShader = true;
            this.invalidateSelf();
        }
        return this;
    }

    public Bitmap toBitmap() {
        return RoundedDrawable.drawableToBitmap(this);
    }

}

