/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  com.makeramen.roundedimageview.RoundedTransformationBuilder$1
 *  com.squareup.picasso.Transformation
 *  java.lang.Object
 */
package com.makeramen.roundedimageview;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.ImageView;
import com.makeramen.roundedimageview.RoundedTransformationBuilder;
import com.squareup.picasso.Transformation;

public final class RoundedTransformationBuilder {
    private ColorStateList mBorderColor = ColorStateList.valueOf((int)-16777216);
    private float mBorderWidth = 0.0f;
    private float[] mCornerRadii = new float[]{0.0f, 0.0f, 0.0f, 0.0f};
    private final DisplayMetrics mDisplayMetrics = Resources.getSystem().getDisplayMetrics();
    private boolean mOval = false;
    private ImageView.ScaleType mScaleType = ImageView.ScaleType.FIT_CENTER;

    static /* synthetic */ boolean access$000(RoundedTransformationBuilder roundedTransformationBuilder) {
        return roundedTransformationBuilder.mOval;
    }

    static /* synthetic */ ColorStateList access$100(RoundedTransformationBuilder roundedTransformationBuilder) {
        return roundedTransformationBuilder.mBorderColor;
    }

    static /* synthetic */ float access$200(RoundedTransformationBuilder roundedTransformationBuilder) {
        return roundedTransformationBuilder.mBorderWidth;
    }

    static /* synthetic */ float[] access$300(RoundedTransformationBuilder roundedTransformationBuilder) {
        return roundedTransformationBuilder.mCornerRadii;
    }

    static /* synthetic */ ImageView.ScaleType access$400(RoundedTransformationBuilder roundedTransformationBuilder) {
        return roundedTransformationBuilder.mScaleType;
    }

    public RoundedTransformationBuilder borderColor(int n) {
        this.mBorderColor = ColorStateList.valueOf((int)n);
        return this;
    }

    public RoundedTransformationBuilder borderColor(ColorStateList colorStateList) {
        this.mBorderColor = colorStateList;
        return this;
    }

    public RoundedTransformationBuilder borderWidth(float f) {
        this.mBorderWidth = f;
        return this;
    }

    public RoundedTransformationBuilder borderWidthDp(float f) {
        this.mBorderWidth = TypedValue.applyDimension((int)1, (float)f, (DisplayMetrics)this.mDisplayMetrics);
        return this;
    }

    public Transformation build() {
        return new 1(this);
    }

    public RoundedTransformationBuilder cornerRadius(float f) {
        float[] arrf = this.mCornerRadii;
        arrf[0] = f;
        arrf[1] = f;
        arrf[2] = f;
        arrf[3] = f;
        return this;
    }

    public RoundedTransformationBuilder cornerRadius(int n, float f) {
        this.mCornerRadii[n] = f;
        return this;
    }

    public RoundedTransformationBuilder cornerRadiusDp(float f) {
        return this.cornerRadius(TypedValue.applyDimension((int)1, (float)f, (DisplayMetrics)this.mDisplayMetrics));
    }

    public RoundedTransformationBuilder cornerRadiusDp(int n, float f) {
        return this.cornerRadius(n, TypedValue.applyDimension((int)1, (float)f, (DisplayMetrics)this.mDisplayMetrics));
    }

    public RoundedTransformationBuilder oval(boolean bl) {
        this.mOval = bl;
        return this;
    }

    public RoundedTransformationBuilder scaleType(ImageView.ScaleType scaleType) {
        this.mScaleType = scaleType;
        return this;
    }
}

