/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.yalantis.ucrop.util;

public final class CubicEasing {
    public static float easeIn(float f, float f2, float f3, float f4) {
        float f5 = f / f4;
        return f2 + f5 * (f5 * (f5 * f3));
    }

    public static float easeInOut(float f, float f2, float f3, float f4) {
        float f5 = f / (f4 / 2.0f);
        if (f5 < 1.0f) {
            return f2 + f5 * (f5 * (f5 * (f3 / 2.0f)));
        }
        float f6 = f3 / 2.0f;
        float f7 = f5 - 2.0f;
        return f2 + f6 * (2.0f + f7 * (f7 * f7));
    }

    public static float easeOut(float f, float f2, float f3, float f4) {
        float f5 = f / f4 - 1.0f;
        return f2 + f3 * (1.0f + f5 * (f5 * f5));
    }
}

