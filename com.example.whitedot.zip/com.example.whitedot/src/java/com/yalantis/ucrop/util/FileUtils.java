/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.provider.DocumentsContract
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Audio
 *  android.provider.MediaStore$Audio$Media
 *  android.provider.MediaStore$Images
 *  android.provider.MediaStore$Images$Media
 *  android.provider.MediaStore$Video
 *  android.provider.MediaStore$Video$Media
 *  android.text.TextUtils
 *  android.util.Log
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Long
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.channels.FileChannel
 *  java.nio.channels.WritableByteChannel
 *  java.util.Locale
 */
package com.yalantis.ucrop.util;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Locale;

public class FileUtils {
    private static final String TAG = "FileUtils";

    private FileUtils() {
    }

    public static void copyFile(String string2, String string3) throws IOException {
        if (string2.equalsIgnoreCase(string3)) {
            return;
        }
        FileChannel fileChannel = null;
        FileChannel fileChannel2 = null;
        try {
            fileChannel2 = new FileInputStream(new File(string2)).getChannel();
            fileChannel = new FileOutputStream(new File(string3)).getChannel();
            long l = fileChannel2.size();
            fileChannel2.transferTo(0L, l, (WritableByteChannel)fileChannel);
            fileChannel2.close();
            return;
        }
        finally {
            if (fileChannel2 != null) {
                fileChannel2.close();
            }
            if (fileChannel != null) {
                fileChannel.close();
            }
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String getDataColumn(Context var0, Uri var1_1, String var2_2, String[] var3_3) {
        block5 : {
            var4_4 = null;
            var5_5 = new String[]{"_data"};
            var4_4 = var0.getContentResolver().query(var1_1, var5_5, var2_2, var3_3, null);
            if (var4_4 == null || !var4_4.moveToFirst()) break block5;
            var11_6 = var4_4.getString(var4_4.getColumnIndexOrThrow("_data"));
            if (var4_4 == null) return var11_6;
            var4_4.close();
            return var11_6;
        }
        if (var4_4 == null) return null;
lbl12: // 2 sources:
        do {
            var4_4.close();
            return null;
            break;
        } while (true);
        {
            catch (Throwable var10_7) {
            }
            catch (IllegalArgumentException var6_8) {}
            {
                var7_9 = Locale.getDefault();
                var8_10 = new Object[]{var6_8.getMessage()};
                Log.i((String)"FileUtils", (String)String.format((Locale)var7_9, (String)"getDataColumn: _data - [%s]", (Object[])var8_10));
                if (var4_4 == null) return null;
                ** continue;
            }
        }
        if (var4_4 == null) throw var10_7;
        var4_4.close();
        throw var10_7;
    }

    public static String getPath(Context context, Uri uri) {
        boolean bl = Build.VERSION.SDK_INT >= 19;
        if (bl && DocumentsContract.isDocumentUri((Context)context, (Uri)uri)) {
            if (FileUtils.isExternalStorageDocument(uri)) {
                String[] arrstring = DocumentsContract.getDocumentId((Uri)uri).split(":");
                if ("primary".equalsIgnoreCase(arrstring[0])) {
                    return (Object)Environment.getExternalStorageDirectory() + "/" + arrstring[1];
                }
                return null;
            }
            if (FileUtils.isDownloadsDocument(uri)) {
                String string2 = DocumentsContract.getDocumentId((Uri)uri);
                if (!TextUtils.isEmpty((CharSequence)string2)) {
                    try {
                        String string3 = FileUtils.getDataColumn(context, ContentUris.withAppendedId((Uri)Uri.parse((String)"content://downloads/public_downloads"), (long)Long.valueOf((String)string2)), null, null);
                        return string3;
                    }
                    catch (NumberFormatException numberFormatException) {
                        Log.i((String)TAG, (String)numberFormatException.getMessage());
                        return null;
                    }
                }
                return null;
            }
            if (FileUtils.isMediaDocument(uri)) {
                Uri uri2;
                String[] arrstring = DocumentsContract.getDocumentId((Uri)uri).split(":");
                String string4 = arrstring[0];
                if ("image".equals((Object)string4)) {
                    uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals((Object)string4)) {
                    uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else {
                    boolean bl2 = "audio".equals((Object)string4);
                    uri2 = null;
                    if (bl2) {
                        uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    }
                }
                String[] arrstring2 = new String[]{arrstring[1]};
                return FileUtils.getDataColumn(context, uri2, "_id=?", arrstring2);
            }
        } else {
            if ("content".equalsIgnoreCase(uri.getScheme())) {
                if (FileUtils.isGooglePhotosUri(uri)) {
                    return uri.getLastPathSegment();
                }
                return FileUtils.getDataColumn(context, uri, null, null);
            }
            if ("file".equalsIgnoreCase(uri.getScheme())) {
                return uri.getPath();
            }
        }
        return null;
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals((Object)uri.getAuthority());
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals((Object)uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals((Object)uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals((Object)uri.getAuthority());
    }
}

