/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Point
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.util.Log
 *  android.view.Display
 *  android.view.WindowManager
 *  java.io.Closeable
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.util.concurrent.Executor
 */
package com.yalantis.ucrop.util;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Point;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import com.yalantis.ucrop.callback.BitmapLoadCallback;
import com.yalantis.ucrop.task.BitmapLoadTask;
import com.yalantis.ucrop.util.EglUtils;
import com.yalantis.ucrop.util.ImageHeaderParser;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.Executor;

public class BitmapLoadUtils {
    private static final String TAG = "BitmapLoadUtils";

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int calculateInSampleSize(BitmapFactory.Options options, int n, int n2) {
        int n3 = options.outHeight;
        int n4 = options.outWidth;
        int n5 = 1;
        if (n3 <= n2 && n4 <= n) return n5;
        while (n3 / n5 > n2 || n4 / n5 > n) {
            n5 *= 2;
        }
        return n5;
    }

    public static int calculateMaxBitmapSize(Context context) {
        int n;
        WindowManager windowManager = (WindowManager)context.getSystemService("window");
        Point point = new Point();
        if (windowManager != null) {
            windowManager.getDefaultDisplay().getSize(point);
        }
        int n2 = point.x;
        int n3 = point.y;
        int n4 = (int)Math.sqrt((double)(Math.pow((double)n2, (double)2.0) + Math.pow((double)n3, (double)2.0)));
        Canvas canvas = new Canvas();
        int n5 = Math.min((int)canvas.getMaximumBitmapWidth(), (int)canvas.getMaximumBitmapHeight());
        if (n5 > 0) {
            n4 = Math.min((int)n4, (int)n5);
        }
        if ((n = EglUtils.getMaxTextureSize()) > 0) {
            n4 = Math.min((int)n4, (int)n);
        }
        Log.d((String)TAG, (String)("maxBitmapSize: " + n4));
        return n4;
    }

    public static void close(Closeable closeable) {
        if (closeable != null && closeable instanceof Closeable) {
            try {
                closeable.close();
                return;
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
    }

    public static void decodeBitmapInBackground(Context context, Uri uri, Uri uri2, int n, int n2, BitmapLoadCallback bitmapLoadCallback) {
        BitmapLoadTask bitmapLoadTask = new BitmapLoadTask(context, uri, uri2, n, n2, bitmapLoadCallback);
        bitmapLoadTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Void[0]);
    }

    public static int exifToDegrees(int n) {
        switch (n) {
            default: {
                return 0;
            }
            case 7: 
            case 8: {
                return 270;
            }
            case 5: 
            case 6: {
                return 90;
            }
            case 3: 
            case 4: 
        }
        return 180;
    }

    public static int exifToTranslation(int n) {
        switch (n) {
            default: {
                return 1;
            }
            case 2: 
            case 4: 
            case 5: 
            case 7: 
        }
        return -1;
    }

    public static int getExifOrientation(Context context, Uri uri) {
        InputStream inputStream;
        int n;
        block3 : {
            n = 0;
            try {
                inputStream = context.getContentResolver().openInputStream(uri);
                if (inputStream != null) break block3;
                return 0;
            }
            catch (IOException iOException) {
                Log.e((String)TAG, (String)("getExifOrientation: " + uri.toString()), (Throwable)iOException);
                return n;
            }
        }
        n = new ImageHeaderParser(inputStream).getOrientation();
        BitmapLoadUtils.close((Closeable)inputStream);
        return n;
    }

    public static Bitmap transformBitmap(Bitmap bitmap, Matrix matrix) {
        try {
            int n = bitmap.getWidth();
            int n2 = bitmap.getHeight();
            Bitmap bitmap2 = Bitmap.createBitmap((Bitmap)bitmap, (int)0, (int)0, (int)n, (int)n2, (Matrix)matrix, (boolean)true);
            boolean bl = bitmap.sameAs(bitmap2);
            if (!bl) {
                bitmap = bitmap2;
            }
            return bitmap;
        }
        catch (OutOfMemoryError outOfMemoryError) {
            Log.e((String)TAG, (String)"transformBitmap: ", (Throwable)outOfMemoryError);
            return bitmap;
        }
    }
}

