/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  android.util.Log
 *  androidx.exifinterface.media.ExifInterface
 *  com.yalantis.ucrop.util.ImageHeaderParser$StreamReader
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.Buffer
 *  java.nio.ByteBuffer
 *  java.nio.ByteOrder
 *  java.nio.charset.Charset
 */
package com.yalantis.ucrop.util;

import android.text.TextUtils;
import android.util.Log;
import androidx.exifinterface.media.ExifInterface;
import com.yalantis.ucrop.util.ImageHeaderParser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;

/*
 * Exception performing whole class analysis.
 */
public class ImageHeaderParser {
    private static final int[] BYTES_PER_FORMAT;
    private static final int EXIF_MAGIC_NUMBER = 65496;
    private static final int EXIF_SEGMENT_TYPE = 225;
    private static final int INTEL_TIFF_MAGIC_NUMBER = 18761;
    private static final String JPEG_EXIF_SEGMENT_PREAMBLE = "Exif\u0000\u0000";
    private static final byte[] JPEG_EXIF_SEGMENT_PREAMBLE_BYTES;
    private static final int MARKER_EOI = 217;
    private static final int MOTOROLA_TIFF_MAGIC_NUMBER = 19789;
    private static final int ORIENTATION_TAG_TYPE = 274;
    private static final int SEGMENT_SOS = 218;
    private static final int SEGMENT_START_ID = 255;
    private static final String TAG = "ImageHeaderParser";
    public static final int UNKNOWN_ORIENTATION = -1;
    private final Reader reader;

    static {
        JPEG_EXIF_SEGMENT_PREAMBLE_BYTES = JPEG_EXIF_SEGMENT_PREAMBLE.getBytes(Charset.forName((String)"UTF-8"));
        BYTES_PER_FORMAT = new int[]{0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8};
    }

    public ImageHeaderParser(InputStream inputStream) {
        this.reader = new /* Unavailable Anonymous Inner Class!! */;
    }

    private static int calcTagOffset(int n, int n2) {
        return n + 2 + n2 * 12;
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void copyExif(ExifInterface var0, int var1_1, int var2_2, String var3_3) {
        var4_4 = new String[]{"FNumber", "DateTime", "DateTimeDigitized", "ExposureTime", "Flash", "FocalLength", "GPSAltitude", "GPSAltitudeRef", "GPSDateStamp", "GPSLatitude", "GPSLatitudeRef", "GPSLongitude", "GPSLongitudeRef", "GPSProcessingMethod", "GPSTimeStamp", "PhotographicSensitivity", "Make", "Model", "SubSecTime", "SubSecTimeDigitized", "SubSecTimeOriginal", "WhiteBalance"};
        var5_5 = new ExifInterface(var3_3);
        var8_6 = var4_4.length;
        var9_7 = 0;
        do {
            block7 : {
                block8 : {
                    if (var9_7 >= var8_6) ** GOTO lbl15
                    var10_8 = var4_4[var9_7];
                    try {
                        var11_9 = var0.getAttribute(var10_8);
                        if (!TextUtils.isEmpty((CharSequence)var11_9)) {
                            var5_5.setAttribute(var10_8, var11_9);
                        }
                        break block7;
lbl15: // 1 sources:
                        var5_5.setAttribute("ImageWidth", String.valueOf((int)var1_1));
                        var5_5.setAttribute("ImageLength", String.valueOf((int)var2_2));
                        var5_5.setAttribute("Orientation", "0");
                        var5_5.saveAttributes();
                        return;
                    }
                    catch (IOException var6_10) {
                        break block8;
                    }
                    catch (IOException var6_11) {
                        // empty catch block
                    }
                }
                Log.d((String)"ImageHeaderParser", (String)var6_12.getMessage());
                return;
            }
            ++var9_7;
        } while (true);
    }

    private static boolean handles(int n) {
        return (n & 65496) == 65496 || n == 19789 || n == 18761;
        {
        }
    }

    private boolean hasJpegExifPreamble(byte[] arrby, int n) {
        boolean bl = arrby != null && n > JPEG_EXIF_SEGMENT_PREAMBLE_BYTES.length;
        if (bl) {
            byte[] arrby2;
            for (int i = 0; i < (arrby2 = JPEG_EXIF_SEGMENT_PREAMBLE_BYTES).length; ++i) {
                if (arrby[i] == arrby2[i]) continue;
                return false;
            }
        }
        return bl;
    }

    private int moveToExifSegmentAndGetLength() throws IOException {
        int n;
        block7 : {
            long l;
            short s;
            do {
                short s2;
                if ((s2 = this.reader.getUInt8()) != 255) {
                    if (Log.isLoggable((String)TAG, (int)3)) {
                        Log.d((String)TAG, (String)("Unknown segmentId=" + s2));
                    }
                    return -1;
                }
                s = this.reader.getUInt8();
                if (s == 218) {
                    return -1;
                }
                if (s == 217) {
                    if (Log.isLoggable((String)TAG, (int)3)) {
                        Log.d((String)TAG, (String)"Found MARKER_EOI in exif segment");
                    }
                    return -1;
                }
                n = -2 + this.reader.getUInt16();
                if (s == 225) break block7;
            } while ((l = this.reader.skip(n)) == (long)n);
            if (Log.isLoggable((String)TAG, (int)3)) {
                Log.d((String)TAG, (String)("Unable to skip enough data, type: " + s + ", wanted to skip: " + n + ", but actually skipped: " + l));
            }
            return -1;
        }
        return n;
    }

    private static int parseExifSegment(RandomAccessReader randomAccessReader) {
        ByteOrder byteOrder;
        RandomAccessReader randomAccessReader2 = randomAccessReader;
        int n = JPEG_EXIF_SEGMENT_PREAMBLE.length();
        short s = randomAccessReader2.getInt16(n);
        int n2 = 3;
        if (s == 19789) {
            byteOrder = ByteOrder.BIG_ENDIAN;
        } else if (s == 18761) {
            byteOrder = ByteOrder.LITTLE_ENDIAN;
        } else {
            if (Log.isLoggable((String)TAG, (int)n2)) {
                Log.d((String)TAG, (String)("Unknown endianness = " + s));
            }
            byteOrder = ByteOrder.BIG_ENDIAN;
        }
        randomAccessReader2.order(byteOrder);
        int n3 = n + randomAccessReader2.getInt32(n + 4);
        int n4 = randomAccessReader2.getInt16(n3);
        for (int i = 0; i < n4; ++i) {
            int n5;
            int n6 = ImageHeaderParser.calcTagOffset(n3, i);
            short s2 = randomAccessReader2.getInt16(n6);
            if (s2 != 274) {
                n5 = n2;
            } else {
                short s3 = randomAccessReader2.getInt16(n6 + 2);
                if (s3 >= 1 && s3 <= 12) {
                    int n7 = randomAccessReader2.getInt32(n6 + 4);
                    if (n7 < 0) {
                        if (Log.isLoggable((String)TAG, (int)n2)) {
                            Log.d((String)TAG, (String)"Negative tiff component count");
                            n5 = n2;
                        } else {
                            n5 = n2;
                        }
                    } else {
                        int n8;
                        if (Log.isLoggable((String)TAG, (int)n2)) {
                            Log.d((String)TAG, (String)("Got tagIndex=" + i + " tagType=" + s2 + " formatCode=" + s3 + " componentCount=" + n7));
                        }
                        if ((n8 = n7 + BYTES_PER_FORMAT[s3]) > 4) {
                            if (Log.isLoggable((String)TAG, (int)n2)) {
                                Log.d((String)TAG, (String)("Got byte count > 4, not orientation, continuing, formatCode=" + s3));
                                n5 = n2;
                            } else {
                                n5 = n2;
                            }
                        } else {
                            int n9 = n6 + 8;
                            if (n9 >= 0 && n9 <= randomAccessReader.length()) {
                                if (n8 >= 0 && n9 + n8 <= randomAccessReader.length()) {
                                    return randomAccessReader2.getInt16(n9);
                                }
                                if (Log.isLoggable((String)TAG, (int)3)) {
                                    Log.d((String)TAG, (String)("Illegal number of bytes for TI tag data tagType=" + s2));
                                    n5 = 3;
                                } else {
                                    n5 = 3;
                                }
                            } else if (Log.isLoggable((String)TAG, (int)3)) {
                                Log.d((String)TAG, (String)("Illegal tagValueOffset=" + n9 + " tagType=" + s2));
                                n5 = 3;
                            } else {
                                n5 = 3;
                            }
                        }
                    }
                } else {
                    n5 = 3;
                    if (Log.isLoggable((String)TAG, (int)n5)) {
                        Log.d((String)TAG, (String)("Got invalid format code = " + s3));
                    }
                }
            }
            n2 = n5;
            randomAccessReader2 = randomAccessReader;
        }
        return -1;
    }

    private int parseExifSegment(byte[] arrby, int n) throws IOException {
        int n2 = this.reader.read(arrby, n);
        if (n2 != n) {
            if (Log.isLoggable((String)TAG, (int)3)) {
                Log.d((String)TAG, (String)("Unable to read exif segment data, length: " + n + ", actually read: " + n2));
            }
            return -1;
        }
        if (this.hasJpegExifPreamble(arrby, n)) {
            return ImageHeaderParser.parseExifSegment(new RandomAccessReader(arrby, n));
        }
        if (Log.isLoggable((String)TAG, (int)3)) {
            Log.d((String)TAG, (String)"Missing jpeg exif preamble");
        }
        return -1;
    }

    public int getOrientation() throws IOException {
        int n = this.reader.getUInt16();
        if (!ImageHeaderParser.handles(n)) {
            if (Log.isLoggable((String)TAG, (int)3)) {
                Log.d((String)TAG, (String)("Parser doesn't handle magic number: " + n));
            }
            return -1;
        }
        int n2 = this.moveToExifSegmentAndGetLength();
        if (n2 == -1) {
            if (Log.isLoggable((String)TAG, (int)3)) {
                Log.d((String)TAG, (String)"Failed to parse exif segment length, or exif segment not found");
            }
            return -1;
        }
        return this.parseExifSegment(new byte[n2], n2);
    }

    private static class RandomAccessReader {
        private final ByteBuffer data;

        public RandomAccessReader(byte[] arrby, int n) {
            this.data = (ByteBuffer)ByteBuffer.wrap((byte[])arrby).order(ByteOrder.BIG_ENDIAN).limit(n);
        }

        public short getInt16(int n) {
            return this.data.getShort(n);
        }

        public int getInt32(int n) {
            return this.data.getInt(n);
        }

        public int length() {
            return this.data.remaining();
        }

        public void order(ByteOrder byteOrder) {
            this.data.order(byteOrder);
        }
    }

    private static interface Reader {
        public int getUInt16() throws IOException;

        public short getUInt8() throws IOException;

        public int read(byte[] var1, int var2) throws IOException;

        public long skip(long var1) throws IOException;
    }

}

