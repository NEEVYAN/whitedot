/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.StateListDrawable
 */
package com.yalantis.ucrop.util;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;

public class SelectedStateListDrawable
extends StateListDrawable {
    private int mSelectionColor;

    public SelectedStateListDrawable(Drawable drawable, int n) {
        this.mSelectionColor = n;
        this.addState(new int[]{16842913}, drawable);
        this.addState(new int[0], drawable);
    }

    public boolean isStateful() {
        return true;
    }

    protected boolean onStateChange(int[] arrn) {
        boolean bl = false;
        int n = arrn.length;
        for (int i = 0; i < n; ++i) {
            if (arrn[i] != 16842913) continue;
            bl = true;
        }
        if (bl) {
            super.setColorFilter(this.mSelectionColor, PorterDuff.Mode.SRC_ATOP);
        } else {
            super.clearColorFilter();
        }
        return super.onStateChange(arrn);
    }
}

