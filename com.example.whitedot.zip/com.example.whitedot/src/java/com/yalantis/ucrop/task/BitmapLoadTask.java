/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Matrix
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.util.Log
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.Void
 *  okhttp3.Call
 *  okhttp3.Dispatcher
 *  okhttp3.OkHttpClient
 *  okhttp3.Request
 *  okhttp3.Request$Builder
 *  okhttp3.Response
 *  okhttp3.ResponseBody
 *  okio.BufferedSource
 *  okio.Okio
 *  okio.Sink
 */
package com.yalantis.ucrop.task;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import com.yalantis.ucrop.callback.BitmapLoadCallback;
import com.yalantis.ucrop.model.ExifInfo;
import com.yalantis.ucrop.util.BitmapLoadUtils;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import okhttp3.Call;
import okhttp3.Dispatcher;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.BufferedSource;
import okio.Okio;
import okio.Sink;

public class BitmapLoadTask
extends AsyncTask<Void, Void, BitmapWorkerResult> {
    private static final int MAX_BITMAP_SIZE = 104857600;
    private static final String TAG = "BitmapWorkerTask";
    private final BitmapLoadCallback mBitmapLoadCallback;
    private final Context mContext;
    private Uri mInputUri;
    private Uri mOutputUri;
    private final int mRequiredHeight;
    private final int mRequiredWidth;

    public BitmapLoadTask(Context context, Uri uri, Uri uri2, int n, int n2, BitmapLoadCallback bitmapLoadCallback) {
        this.mContext = context;
        this.mInputUri = uri;
        this.mOutputUri = uri2;
        this.mRequiredWidth = n;
        this.mRequiredHeight = n2;
        this.mBitmapLoadCallback = bitmapLoadCallback;
    }

    private boolean checkSize(Bitmap bitmap, BitmapFactory.Options options) {
        int n = bitmap != null ? bitmap.getByteCount() : 0;
        if (n > 104857600) {
            options.inSampleSize = 2 * options.inSampleSize;
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void copyFile(Uri uri, Uri uri2) throws NullPointerException, IOException {
        block5 : {
            Log.d((String)TAG, (String)"copyFile");
            if (uri2 == null) {
                throw new NullPointerException("Output Uri is null - cannot copy image");
            }
            InputStream inputStream = null;
            FileOutputStream fileOutputStream = null;
            try {
                int n;
                inputStream = this.mContext.getContentResolver().openInputStream(uri);
                fileOutputStream = new FileOutputStream(new File(uri2.getPath()));
                if (inputStream == null) break block5;
                byte[] arrby = new byte[1024];
                while ((n = inputStream.read(arrby)) > 0) {
                    fileOutputStream.write(arrby, 0, n);
                }
            }
            catch (Throwable throwable) {
                BitmapLoadUtils.close(fileOutputStream);
                BitmapLoadUtils.close((Closeable)inputStream);
                this.mInputUri = this.mOutputUri;
                throw throwable;
            }
            BitmapLoadUtils.close((Closeable)fileOutputStream);
            BitmapLoadUtils.close((Closeable)inputStream);
            this.mInputUri = this.mOutputUri;
            return;
        }
        throw new NullPointerException("InputStream for given input Uri is null");
    }

    private void downloadFile(Uri uri, Uri uri2) throws NullPointerException, IOException {
        Log.d((String)TAG, (String)"downloadFile");
        if (uri2 != null) {
            block7 : {
                OutputStream outputStream;
                OkHttpClient okHttpClient = new OkHttpClient();
                BufferedSource bufferedSource = null;
                Sink sink = null;
                Response response = null;
                try {
                    response = okHttpClient.newCall(new Request.Builder().url(uri.toString()).build()).execute();
                    bufferedSource = response.body().source();
                    outputStream = this.mContext.getContentResolver().openOutputStream(uri2);
                    sink = null;
                    if (outputStream == null) break block7;
                }
                catch (Throwable throwable) {
                    BitmapLoadUtils.close(bufferedSource);
                    BitmapLoadUtils.close(sink);
                    if (response != null) {
                        BitmapLoadUtils.close((Closeable)response.body());
                    }
                    okHttpClient.dispatcher().cancelAll();
                    this.mInputUri = this.mOutputUri;
                    throw throwable;
                }
                sink = Okio.sink((OutputStream)outputStream);
                bufferedSource.readAll(sink);
                BitmapLoadUtils.close((Closeable)bufferedSource);
                BitmapLoadUtils.close((Closeable)sink);
                if (response != null) {
                    BitmapLoadUtils.close((Closeable)response.body());
                }
                okHttpClient.dispatcher().cancelAll();
                this.mInputUri = this.mOutputUri;
                return;
            }
            throw new NullPointerException("OutputStream for given output Uri is null");
        }
        throw new NullPointerException("Output Uri is null - cannot download image");
    }

    private void processInputUri() throws NullPointerException, IOException {
        void var3_7;
        String string2 = this.mInputUri.getScheme();
        Log.d((String)TAG, (String)("Uri scheme: " + string2));
        if (!"http".equals((Object)string2) && !"https".equals((Object)string2)) {
            if ("content".equals((Object)string2)) {
                void var6_4;
                try {
                    this.copyFile(this.mInputUri, this.mOutputUri);
                    return;
                }
                catch (IOException iOException) {
                }
                catch (NullPointerException nullPointerException) {
                    // empty catch block
                }
                Log.e((String)TAG, (String)"Copying failed", (Throwable)var6_4);
                throw var6_4;
            }
            if ("file".equals((Object)string2)) {
                return;
            }
            Log.e((String)TAG, (String)("Invalid Uri scheme " + string2));
            throw new IllegalArgumentException("Invalid Uri scheme" + string2);
        }
        try {
            this.downloadFile(this.mInputUri, this.mOutputUri);
            return;
        }
        catch (IOException iOException) {
        }
        catch (NullPointerException nullPointerException) {
            // empty catch block
        }
        Log.e((String)TAG, (String)"Downloading failed", (Throwable)var3_7);
        throw var3_7;
    }

    protected /* varargs */ BitmapWorkerResult doInBackground(Void ... arrvoid) {
        void var2_19;
        if (this.mInputUri == null) {
            return new BitmapWorkerResult((Exception)((Object)new NullPointerException("Input Uri cannot be null")));
        }
        try {
            this.processInputUri();
        }
        catch (IOException iOException) {
        }
        catch (NullPointerException nullPointerException) {
            // empty catch block
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        options.inSampleSize = BitmapLoadUtils.calculateInSampleSize(options, this.mRequiredWidth, this.mRequiredHeight);
        options.inJustDecodeBounds = false;
        Bitmap bitmap = null;
        boolean bl = false;
        while (!bl) {
            InputStream inputStream;
            block18 : {
                inputStream = this.mContext.getContentResolver().openInputStream(this.mInputUri);
                try {
                    int n;
                    bitmap = BitmapFactory.decodeStream((InputStream)inputStream, null, (BitmapFactory.Options)options);
                    if (options.outWidth == -1 || (n = options.outHeight) == -1) break block18;
                }
                catch (Throwable throwable) {
                    try {
                        BitmapLoadUtils.close((Closeable)inputStream);
                        throw throwable;
                    }
                    catch (IOException iOException) {
                        Log.e((String)TAG, (String)"doInBackground: ImageDecoder.createSource: ", (Throwable)iOException);
                        return new BitmapWorkerResult((Exception)new IllegalArgumentException("Bitmap could not be decoded from the Uri: [" + (Object)this.mInputUri + "]", (Throwable)iOException));
                    }
                    catch (OutOfMemoryError outOfMemoryError) {
                        Log.e((String)TAG, (String)"doInBackground: BitmapFactory.decodeFileDescriptor: ", (Throwable)outOfMemoryError);
                        options.inSampleSize = 2 * options.inSampleSize;
                        continue;
                    }
                }
                BitmapLoadUtils.close((Closeable)inputStream);
                boolean bl2 = this.checkSize(bitmap, options);
                if (bl2) continue;
                bl = true;
                continue;
            }
            BitmapWorkerResult bitmapWorkerResult = new BitmapWorkerResult((Exception)new IllegalArgumentException("Bounds for bitmap could not be retrieved from the Uri: [" + (Object)this.mInputUri + "]"));
            BitmapLoadUtils.close((Closeable)inputStream);
            return bitmapWorkerResult;
        }
        if (bitmap == null) {
            return new BitmapWorkerResult((Exception)new IllegalArgumentException("Bitmap could not be decoded from the Uri: [" + (Object)this.mInputUri + "]"));
        }
        int n = BitmapLoadUtils.getExifOrientation(this.mContext, this.mInputUri);
        int n2 = BitmapLoadUtils.exifToDegrees(n);
        int n3 = BitmapLoadUtils.exifToTranslation(n);
        ExifInfo exifInfo = new ExifInfo(n, n2, n3);
        Matrix matrix = new Matrix();
        if (n2 != 0) {
            matrix.preRotate((float)n2);
        }
        if (n3 != 1) {
            matrix.postScale((float)n3, 1.0f);
        }
        if (!matrix.isIdentity()) {
            return new BitmapWorkerResult(BitmapLoadUtils.transformBitmap(bitmap, matrix), exifInfo);
        }
        return new BitmapWorkerResult(bitmap, exifInfo);
        return new BitmapWorkerResult((Exception)var2_19);
    }

    protected void onPostExecute(BitmapWorkerResult bitmapWorkerResult) {
        if (bitmapWorkerResult.mBitmapWorkerException == null) {
            BitmapLoadCallback bitmapLoadCallback = this.mBitmapLoadCallback;
            Bitmap bitmap = bitmapWorkerResult.mBitmapResult;
            ExifInfo exifInfo = bitmapWorkerResult.mExifInfo;
            String string2 = this.mInputUri.getPath();
            Uri uri = this.mOutputUri;
            String string3 = uri == null ? null : uri.getPath();
            bitmapLoadCallback.onBitmapLoaded(bitmap, exifInfo, string2, string3);
            return;
        }
        this.mBitmapLoadCallback.onFailure(bitmapWorkerResult.mBitmapWorkerException);
    }

    public static class BitmapWorkerResult {
        Bitmap mBitmapResult;
        Exception mBitmapWorkerException;
        ExifInfo mExifInfo;

        public BitmapWorkerResult(Bitmap bitmap, ExifInfo exifInfo) {
            this.mBitmapResult = bitmap;
            this.mExifInfo = exifInfo;
        }

        public BitmapWorkerResult(Exception exception) {
            this.mBitmapWorkerException = exception;
        }
    }

}

