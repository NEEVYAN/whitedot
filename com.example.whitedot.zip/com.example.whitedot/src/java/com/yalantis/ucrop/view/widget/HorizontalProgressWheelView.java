/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Cap
 *  android.graphics.Paint$Style
 *  android.graphics.Rect
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.view.View
 *  androidx.core.content.ContextCompat
 *  java.lang.Object
 */
package com.yalantis.ucrop.view.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.core.content.ContextCompat;
import com.yalantis.ucrop.R;

public class HorizontalProgressWheelView
extends View {
    private final Rect mCanvasClipBounds = new Rect();
    private float mLastTouchedPosition;
    private int mMiddleLineColor;
    private int mProgressLineHeight;
    private int mProgressLineMargin;
    private Paint mProgressLinePaint;
    private int mProgressLineWidth;
    private Paint mProgressMiddleLinePaint;
    private boolean mScrollStarted;
    private ScrollingListener mScrollingListener;
    private float mTotalScrollDistance;

    public HorizontalProgressWheelView(Context context) {
        this(context, null);
    }

    public HorizontalProgressWheelView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public HorizontalProgressWheelView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init();
    }

    public HorizontalProgressWheelView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
    }

    private void init() {
        Paint paint;
        Paint paint2;
        this.mMiddleLineColor = ContextCompat.getColor((Context)this.getContext(), (int)R.color.ucrop_color_widget_rotate_mid_line);
        this.mProgressLineWidth = this.getContext().getResources().getDimensionPixelSize(R.dimen.ucrop_width_horizontal_wheel_progress_line);
        this.mProgressLineHeight = this.getContext().getResources().getDimensionPixelSize(R.dimen.ucrop_height_horizontal_wheel_progress_line);
        this.mProgressLineMargin = this.getContext().getResources().getDimensionPixelSize(R.dimen.ucrop_margin_horizontal_wheel_progress_line);
        this.mProgressLinePaint = paint = new Paint(1);
        paint.setStyle(Paint.Style.STROKE);
        this.mProgressLinePaint.setStrokeWidth((float)this.mProgressLineWidth);
        this.mProgressLinePaint.setColor(this.getResources().getColor(R.color.ucrop_color_progress_wheel_line));
        this.mProgressMiddleLinePaint = paint2 = new Paint(this.mProgressLinePaint);
        paint2.setColor(this.mMiddleLineColor);
        this.mProgressMiddleLinePaint.setStrokeCap(Paint.Cap.ROUND);
        this.mProgressMiddleLinePaint.setStrokeWidth((float)this.getContext().getResources().getDimensionPixelSize(R.dimen.ucrop_width_middle_wheel_progress_line));
    }

    private void onScrollEvent(MotionEvent motionEvent, float f) {
        this.mTotalScrollDistance -= f;
        this.postInvalidate();
        this.mLastTouchedPosition = motionEvent.getX();
        ScrollingListener scrollingListener = this.mScrollingListener;
        if (scrollingListener != null) {
            scrollingListener.onScroll(-f, this.mTotalScrollDistance);
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.getClipBounds(this.mCanvasClipBounds);
        int n = this.mCanvasClipBounds.width();
        int n2 = this.mProgressLineWidth;
        int n3 = this.mProgressLineMargin;
        int n4 = n / (n2 + n3);
        float f = this.mTotalScrollDistance % (float)(n3 + n2);
        for (int i = 0; i < n4; ++i) {
            if (i < n4 / 4) {
                this.mProgressLinePaint.setAlpha((int)(255.0f * ((float)i / (float)(n4 / 4))));
            } else if (i > n4 * 3 / 4) {
                this.mProgressLinePaint.setAlpha((int)(255.0f * ((float)(n4 - i) / (float)(n4 / 4))));
            } else {
                this.mProgressLinePaint.setAlpha(255);
            }
            canvas.drawLine(-f + (float)this.mCanvasClipBounds.left + (float)(i * (this.mProgressLineWidth + this.mProgressLineMargin)), (float)this.mCanvasClipBounds.centerY() - (float)this.mProgressLineHeight / 4.0f, -f + (float)this.mCanvasClipBounds.left + (float)(i * (this.mProgressLineWidth + this.mProgressLineMargin)), (float)this.mCanvasClipBounds.centerY() + (float)this.mProgressLineHeight / 4.0f, this.mProgressLinePaint);
        }
        canvas.drawLine((float)this.mCanvasClipBounds.centerX(), (float)this.mCanvasClipBounds.centerY() - (float)this.mProgressLineHeight / 2.0f, (float)this.mCanvasClipBounds.centerX(), (float)this.mCanvasClipBounds.centerY() + (float)this.mProgressLineHeight / 2.0f, this.mProgressMiddleLinePaint);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            default: {
                return true;
            }
            case 2: {
                float f = motionEvent.getX() - this.mLastTouchedPosition;
                if (f == 0.0f) break;
                if (!this.mScrollStarted) {
                    this.mScrollStarted = true;
                    ScrollingListener scrollingListener = this.mScrollingListener;
                    if (scrollingListener != null) {
                        scrollingListener.onScrollStart();
                    }
                }
                this.onScrollEvent(motionEvent, f);
                return true;
            }
            case 1: {
                ScrollingListener scrollingListener = this.mScrollingListener;
                if (scrollingListener == null) break;
                this.mScrollStarted = false;
                scrollingListener.onScrollEnd();
                return true;
            }
            case 0: {
                this.mLastTouchedPosition = motionEvent.getX();
            }
        }
        return true;
    }

    public void setMiddleLineColor(int n) {
        this.mMiddleLineColor = n;
        this.mProgressMiddleLinePaint.setColor(n);
        this.invalidate();
    }

    public void setScrollingListener(ScrollingListener scrollingListener) {
        this.mScrollingListener = scrollingListener;
    }

    public static interface ScrollingListener {
        public void onScroll(float var1, float var2);

        public void onScrollEnd();

        public void onScrollStart();
    }

}

