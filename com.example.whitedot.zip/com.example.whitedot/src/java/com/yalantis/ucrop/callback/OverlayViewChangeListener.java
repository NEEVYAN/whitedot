/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.RectF
 *  java.lang.Object
 */
package com.yalantis.ucrop.callback;

import android.graphics.RectF;

public interface OverlayViewChangeListener {
    public void onCropRectUpdated(RectF var1);
}

