/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package com.yalantis.ucrop;

public final class BuildConfig {
    @Deprecated
    public static final String APPLICATION_ID = "com.yalantis.ucrop";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final String LIBRARY_PACKAGE_NAME = "com.yalantis.ucrop";
    public static final int VERSION_CODE = 25;
    public static final String VERSION_NAME = "2.2.5-non-native";
}

