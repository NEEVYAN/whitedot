/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.firebase.ui.common;

public final class ChangeEventType
extends Enum<ChangeEventType> {
    private static final /* synthetic */ ChangeEventType[] $VALUES;
    public static final /* enum */ ChangeEventType ADDED;
    public static final /* enum */ ChangeEventType CHANGED;
    public static final /* enum */ ChangeEventType MOVED;
    public static final /* enum */ ChangeEventType REMOVED;

    static {
        ChangeEventType changeEventType;
        ChangeEventType changeEventType2;
        ChangeEventType changeEventType3;
        ChangeEventType changeEventType4;
        ADDED = changeEventType3 = new ChangeEventType();
        CHANGED = changeEventType2 = new ChangeEventType();
        REMOVED = changeEventType4 = new ChangeEventType();
        MOVED = changeEventType = new ChangeEventType();
        $VALUES = new ChangeEventType[]{changeEventType3, changeEventType2, changeEventType4, changeEventType};
    }

    public static ChangeEventType valueOf(String string2) {
        return (ChangeEventType)Enum.valueOf(ChangeEventType.class, (String)string2);
    }

    public static ChangeEventType[] values() {
        return (ChangeEventType[])$VALUES.clone();
    }
}

