/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.LruCache
 *  java.lang.Object
 *  java.lang.String
 */
package com.firebase.ui.common;

import android.util.LruCache;
import com.firebase.ui.common.BaseSnapshotParser;

public abstract class BaseCachingSnapshotParser<S, T>
implements BaseSnapshotParser<S, T> {
    private static final int MAX_CACHE_SIZE = 100;
    private final LruCache<String, T> mObjectCache = new LruCache(100);
    private final BaseSnapshotParser<S, T> mParser;

    public BaseCachingSnapshotParser(BaseSnapshotParser<S, T> baseSnapshotParser) {
        this.mParser = baseSnapshotParser;
    }

    public void clear() {
        this.mObjectCache.evictAll();
    }

    public abstract String getId(S var1);

    public void invalidate(S s) {
        this.mObjectCache.remove((Object)this.getId(s));
    }

    @Override
    public T parseSnapshot(S s) {
        String string2 = this.getId(s);
        Object object = this.mObjectCache.get((Object)string2);
        if (object == null) {
            T t = this.mParser.parseSnapshot(s);
            this.mObjectCache.put((Object)string2, t);
            object = t;
        }
        return (T)object;
    }
}

