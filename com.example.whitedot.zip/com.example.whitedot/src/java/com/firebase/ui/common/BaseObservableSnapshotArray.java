/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.AbstractList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.CopyOnWriteArrayList
 */
package com.firebase.ui.common;

import com.firebase.ui.common.BaseCachingSnapshotParser;
import com.firebase.ui.common.BaseChangeEventListener;
import com.firebase.ui.common.ChangeEventType;
import com.firebase.ui.common.Preconditions;
import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public abstract class BaseObservableSnapshotArray<S, E, L extends BaseChangeEventListener<S, E>, T>
extends AbstractList<T> {
    private final BaseCachingSnapshotParser<S, T> mCachingParser;
    private boolean mHasDataChanged = false;
    private final List<L> mListeners = new CopyOnWriteArrayList();

    public BaseObservableSnapshotArray(BaseCachingSnapshotParser<S, T> baseCachingSnapshotParser) {
        this.mCachingParser = Preconditions.checkNotNull(baseCachingSnapshotParser);
    }

    public L addChangeEventListener(L l) {
        Preconditions.checkNotNull(l);
        boolean bl = this.isListening();
        this.mListeners.add(l);
        for (int i = 0; i < this.size(); ++i) {
            l.onChildChanged(ChangeEventType.ADDED, this.getSnapshot(i), i, -1);
        }
        if (this.mHasDataChanged) {
            l.onDataChanged();
        }
        if (!bl) {
            this.onCreate();
        }
        return l;
    }

    public void clear() {
        this.getSnapshots().clear();
        this.notifyOnDataChanged();
    }

    public T get(int n) {
        return this.mCachingParser.parseSnapshot(this.getSnapshot(n));
    }

    public S getSnapshot(int n) {
        return (S)this.getSnapshots().get(n);
    }

    protected abstract List<S> getSnapshots();

    public boolean isListening() {
        return true ^ this.mListeners.isEmpty();
    }

    public boolean isListening(L l) {
        return this.mListeners.contains(l);
    }

    protected final void notifyOnChildChanged(ChangeEventType changeEventType, S s, int n, int n2) {
        if (changeEventType == ChangeEventType.CHANGED || changeEventType == ChangeEventType.REMOVED) {
            this.mCachingParser.invalidate(s);
        }
        Iterator iterator = this.mListeners.iterator();
        while (iterator.hasNext()) {
            ((BaseChangeEventListener)iterator.next()).onChildChanged(changeEventType, s, n, n2);
        }
    }

    protected final void notifyOnDataChanged() {
        this.mHasDataChanged = true;
        Iterator iterator = this.mListeners.iterator();
        while (iterator.hasNext()) {
            ((BaseChangeEventListener)iterator.next()).onDataChanged();
        }
    }

    protected final void notifyOnError(E e) {
        Iterator iterator = this.mListeners.iterator();
        while (iterator.hasNext()) {
            ((BaseChangeEventListener)iterator.next()).onError(e);
        }
    }

    protected void onCreate() {
    }

    protected void onDestroy() {
        this.mHasDataChanged = false;
        this.getSnapshots().clear();
        this.mCachingParser.clear();
    }

    public void removeAllListeners() {
        Iterator iterator = this.mListeners.iterator();
        while (iterator.hasNext()) {
            this.removeChangeEventListener((BaseChangeEventListener)iterator.next());
        }
    }

    public void removeChangeEventListener(L l) {
        Preconditions.checkNotNull(l);
        boolean bl = this.isListening();
        this.mListeners.remove(l);
        if (!this.isListening() && bl) {
            this.onDestroy();
        }
    }

    public int size() {
        return this.getSnapshots().size();
    }
}

