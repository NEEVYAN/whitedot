/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.firebase.ui.common;

import com.firebase.ui.common.ChangeEventType;

public interface BaseChangeEventListener<S, E> {
    public void onChildChanged(ChangeEventType var1, S var2, int var3, int var4);

    public void onDataChanged();

    public void onError(E var1);
}

