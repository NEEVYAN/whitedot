/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.firebase.ui.common;

public final class R {
    private R() {
    }

    public static final class id {
        public static final int view_tree_lifecycle_owner = 2131362386;
        public static final int view_tree_view_model_store_owner = 2131362389;

        private id() {
        }
    }

}

