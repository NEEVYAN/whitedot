/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package com.firebase.ui.common;

public final class Preconditions {
    public static void assertNonNull(Object object, String string2) {
        if (object != null) {
            return;
        }
        throw new RuntimeException(string2);
    }

    public static void assertNull(Object object, String string2) {
        if (object == null) {
            return;
        }
        throw new RuntimeException(string2);
    }

    public static <T> T checkNotNull(T t) {
        if (t != null) {
            return t;
        }
        throw new IllegalArgumentException("Argument cannot be null.");
    }
}

