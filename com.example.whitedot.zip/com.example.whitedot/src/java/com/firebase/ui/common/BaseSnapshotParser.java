/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.firebase.ui.common;

public interface BaseSnapshotParser<S, T> {
    public T parseSnapshot(S var1);
}

