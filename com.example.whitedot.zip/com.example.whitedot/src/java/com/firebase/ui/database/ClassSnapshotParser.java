/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.database.DataSnapshot
 *  java.lang.Class
 *  java.lang.Object
 */
package com.firebase.ui.database;

import com.firebase.ui.common.Preconditions;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.database.DataSnapshot;

public class ClassSnapshotParser<T>
implements SnapshotParser<T> {
    private Class<T> mClass;

    public ClassSnapshotParser(Class<T> class_) {
        this.mClass = Preconditions.checkNotNull(class_);
    }

    @Override
    public T parseSnapshot(DataSnapshot dataSnapshot) {
        return (T)dataSnapshot.getValue(this.mClass);
    }
}

