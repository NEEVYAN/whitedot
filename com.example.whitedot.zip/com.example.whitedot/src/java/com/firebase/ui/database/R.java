/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.firebase.ui.database;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int alpha = 2130968622;
        public static final int buttonSize = 2130968700;
        public static final int circleCrop = 2130968755;
        public static final int colorScheme = 2130968798;
        public static final int coordinatorLayoutStyle = 2130968827;
        public static final int fastScrollEnabled = 2130968939;
        public static final int fastScrollHorizontalThumbDrawable = 2130968940;
        public static final int fastScrollHorizontalTrackDrawable = 2130968941;
        public static final int fastScrollVerticalThumbDrawable = 2130968942;
        public static final int fastScrollVerticalTrackDrawable = 2130968943;
        public static final int font = 2130968966;
        public static final int fontProviderAuthority = 2130968968;
        public static final int fontProviderCerts = 2130968969;
        public static final int fontProviderFetchStrategy = 2130968970;
        public static final int fontProviderFetchTimeout = 2130968971;
        public static final int fontProviderPackage = 2130968972;
        public static final int fontProviderQuery = 2130968973;
        public static final int fontStyle = 2130968975;
        public static final int fontVariationSettings = 2130968976;
        public static final int fontWeight = 2130968977;
        public static final int imageAspectRatio = 2130969013;
        public static final int imageAspectRatioAdjust = 2130969014;
        public static final int keylines = 2130969052;
        public static final int layoutManager = 2130969060;
        public static final int layout_anchor = 2130969061;
        public static final int layout_anchorGravity = 2130969062;
        public static final int layout_behavior = 2130969063;
        public static final int layout_dodgeInsetEdges = 2130969112;
        public static final int layout_insetEdge = 2130969122;
        public static final int layout_keyline = 2130969123;
        public static final int recyclerViewStyle = 2130969280;
        public static final int reverseLayout = 2130969285;
        public static final int scopeUris = 2130969304;
        public static final int spanCount = 2130969372;
        public static final int stackFromEnd = 2130969383;
        public static final int statusBarBackground = 2130969396;
        public static final int ttcIndex = 2130969535;

        private attr() {
        }
    }

    public static final class color {
        public static final int androidx_core_ripple_material_light = 2131099675;
        public static final int androidx_core_secondary_text_default_material_light = 2131099676;
        public static final int common_google_signin_btn_text_dark = 2131099703;
        public static final int common_google_signin_btn_text_dark_default = 2131099704;
        public static final int common_google_signin_btn_text_dark_disabled = 2131099705;
        public static final int common_google_signin_btn_text_dark_focused = 2131099706;
        public static final int common_google_signin_btn_text_dark_pressed = 2131099707;
        public static final int common_google_signin_btn_text_light = 2131099708;
        public static final int common_google_signin_btn_text_light_default = 2131099709;
        public static final int common_google_signin_btn_text_light_disabled = 2131099710;
        public static final int common_google_signin_btn_text_light_focused = 2131099711;
        public static final int common_google_signin_btn_text_light_pressed = 2131099712;
        public static final int common_google_signin_btn_tint = 2131099713;
        public static final int notification_action_color_filter = 2131099846;
        public static final int notification_icon_bg_color = 2131099847;
        public static final int notification_material_background_media_default_color = 2131099848;
        public static final int primary_text_default_material_dark = 2131099853;
        public static final int ripple_material_light = 2131099864;
        public static final int secondary_text_default_material_dark = 2131099865;
        public static final int secondary_text_default_material_light = 2131099866;

        private color() {
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2131166032;
        public static final int compat_button_inset_vertical_material = 2131166033;
        public static final int compat_button_padding_horizontal_material = 2131166034;
        public static final int compat_button_padding_vertical_material = 2131166035;
        public static final int compat_control_corner_material = 2131166036;
        public static final int compat_notification_large_icon_max_height = 2131166037;
        public static final int compat_notification_large_icon_max_width = 2131166038;
        public static final int fastscroll_default_thickness = 2131166088;
        public static final int fastscroll_margin = 2131166089;
        public static final int fastscroll_minimum_range = 2131166090;
        public static final int item_touch_helper_max_drag_scroll_per_frame = 2131166098;
        public static final int item_touch_helper_swipe_escape_max_velocity = 2131166099;
        public static final int item_touch_helper_swipe_escape_velocity = 2131166100;
        public static final int notification_action_icon_size = 2131166268;
        public static final int notification_action_text_size = 2131166269;
        public static final int notification_big_circle_margin = 2131166270;
        public static final int notification_content_margin_start = 2131166271;
        public static final int notification_large_icon_height = 2131166272;
        public static final int notification_large_icon_width = 2131166273;
        public static final int notification_main_column_padding_top = 2131166274;
        public static final int notification_media_narrow_margin = 2131166275;
        public static final int notification_right_icon_size = 2131166276;
        public static final int notification_right_side_padding_top = 2131166277;
        public static final int notification_small_icon_background_padding = 2131166278;
        public static final int notification_small_icon_size_as_large = 2131166279;
        public static final int notification_subtext_size = 2131166280;
        public static final int notification_top_pad = 2131166281;
        public static final int notification_top_pad_large_text = 2131166282;
        public static final int subtitle_corner_radius = 2131166284;
        public static final int subtitle_outline_width = 2131166285;
        public static final int subtitle_shadow_offset = 2131166286;
        public static final int subtitle_shadow_radius = 2131166287;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int common_full_open_on_phone = 2131230842;
        public static final int common_google_signin_btn_icon_dark = 2131230843;
        public static final int common_google_signin_btn_icon_dark_focused = 2131230844;
        public static final int common_google_signin_btn_icon_dark_normal = 2131230845;
        public static final int common_google_signin_btn_icon_dark_normal_background = 2131230846;
        public static final int common_google_signin_btn_icon_disabled = 2131230847;
        public static final int common_google_signin_btn_icon_light = 2131230848;
        public static final int common_google_signin_btn_icon_light_focused = 2131230849;
        public static final int common_google_signin_btn_icon_light_normal = 2131230850;
        public static final int common_google_signin_btn_icon_light_normal_background = 2131230851;
        public static final int common_google_signin_btn_text_dark = 2131230852;
        public static final int common_google_signin_btn_text_dark_focused = 2131230853;
        public static final int common_google_signin_btn_text_dark_normal = 2131230854;
        public static final int common_google_signin_btn_text_dark_normal_background = 2131230855;
        public static final int common_google_signin_btn_text_disabled = 2131230856;
        public static final int common_google_signin_btn_text_light = 2131230857;
        public static final int common_google_signin_btn_text_light_focused = 2131230858;
        public static final int common_google_signin_btn_text_light_normal = 2131230859;
        public static final int common_google_signin_btn_text_light_normal_background = 2131230860;
        public static final int googleg_disabled_color_18 = 2131232254;
        public static final int googleg_standard_color_18 = 2131232255;
        public static final int notification_action_background = 2131232310;
        public static final int notification_bg = 2131232311;
        public static final int notification_bg_low = 2131232312;
        public static final int notification_bg_low_normal = 2131232313;
        public static final int notification_bg_low_pressed = 2131232314;
        public static final int notification_bg_normal = 2131232315;
        public static final int notification_bg_normal_pressed = 2131232316;
        public static final int notification_icon_background = 2131232317;
        public static final int notification_template_icon_bg = 2131232318;
        public static final int notification_template_icon_low_bg = 2131232319;
        public static final int notification_tile_bg = 2131232320;
        public static final int notify_panel_notification_icon_bg = 2131232321;

        private drawable() {
        }
    }

    public static final class id {
        public static final int accessibility_action_clickable_span = 2131361820;
        public static final int accessibility_custom_action_0 = 2131361821;
        public static final int accessibility_custom_action_1 = 2131361822;
        public static final int accessibility_custom_action_10 = 2131361823;
        public static final int accessibility_custom_action_11 = 2131361824;
        public static final int accessibility_custom_action_12 = 2131361825;
        public static final int accessibility_custom_action_13 = 2131361826;
        public static final int accessibility_custom_action_14 = 2131361827;
        public static final int accessibility_custom_action_15 = 2131361828;
        public static final int accessibility_custom_action_16 = 2131361829;
        public static final int accessibility_custom_action_17 = 2131361830;
        public static final int accessibility_custom_action_18 = 2131361831;
        public static final int accessibility_custom_action_19 = 2131361832;
        public static final int accessibility_custom_action_2 = 2131361833;
        public static final int accessibility_custom_action_20 = 2131361834;
        public static final int accessibility_custom_action_21 = 2131361835;
        public static final int accessibility_custom_action_22 = 2131361836;
        public static final int accessibility_custom_action_23 = 2131361837;
        public static final int accessibility_custom_action_24 = 2131361838;
        public static final int accessibility_custom_action_25 = 2131361839;
        public static final int accessibility_custom_action_26 = 2131361840;
        public static final int accessibility_custom_action_27 = 2131361841;
        public static final int accessibility_custom_action_28 = 2131361842;
        public static final int accessibility_custom_action_29 = 2131361843;
        public static final int accessibility_custom_action_3 = 2131361844;
        public static final int accessibility_custom_action_30 = 2131361845;
        public static final int accessibility_custom_action_31 = 2131361846;
        public static final int accessibility_custom_action_4 = 2131361847;
        public static final int accessibility_custom_action_5 = 2131361848;
        public static final int accessibility_custom_action_6 = 2131361849;
        public static final int accessibility_custom_action_7 = 2131361850;
        public static final int accessibility_custom_action_8 = 2131361851;
        public static final int accessibility_custom_action_9 = 2131361852;
        public static final int action0 = 2131361853;
        public static final int action_container = 2131361864;
        public static final int action_divider = 2131361866;
        public static final int action_image = 2131361867;
        public static final int action_text = 2131361873;
        public static final int actions = 2131361874;
        public static final int adjust_height = 2131361878;
        public static final int adjust_width = 2131361879;
        public static final int async = 2131361892;
        public static final int auto = 2131361893;
        public static final int blocking = 2131361904;
        public static final int bottom = 2131361905;
        public static final int cancel_action = 2131361924;
        public static final int chronometer = 2131361941;
        public static final int dark = 2131361967;
        public static final int dialog_button = 2131361985;
        public static final int end = 2131362021;
        public static final int end_padder = 2131362022;
        public static final int forever = 2131362043;
        public static final int icon = 2131362071;
        public static final int icon_group = 2131362072;
        public static final int icon_only = 2131362073;
        public static final int info = 2131362090;
        public static final int italic = 2131362092;
        public static final int item_touch_helper_previous_elevation = 2131362093;
        public static final int left = 2131362103;
        public static final int light = 2131362106;
        public static final int line1 = 2131362107;
        public static final int line3 = 2131362108;
        public static final int media_actions = 2131362125;
        public static final int none = 2131362173;
        public static final int normal = 2131362174;
        public static final int notification_background = 2131362176;
        public static final int notification_main_column = 2131362177;
        public static final int notification_main_column_container = 2131362178;
        public static final int right = 2131362218;
        public static final int right_icon = 2131362219;
        public static final int right_side = 2131362220;
        public static final int standard = 2131362284;
        public static final int start = 2131362285;
        public static final int status_bar_latest_event_content = 2131362295;
        public static final int tag_accessibility_actions = 2131362308;
        public static final int tag_accessibility_clickable_spans = 2131362309;
        public static final int tag_accessibility_heading = 2131362310;
        public static final int tag_accessibility_pane_title = 2131362311;
        public static final int tag_screen_reader_focusable = 2131362315;
        public static final int tag_transition_group = 2131362317;
        public static final int tag_unhandled_key_event_manager = 2131362318;
        public static final int tag_unhandled_key_listeners = 2131362319;
        public static final int text = 2131362323;
        public static final int text2 = 2131362324;
        public static final int time = 2131362341;
        public static final int title = 2131362342;
        public static final int top = 2131362357;
        public static final int view_tree_lifecycle_owner = 2131362386;
        public static final int view_tree_view_model_store_owner = 2131362389;
        public static final int wide = 2131362393;

        private id() {
        }
    }

    public static final class integer {
        public static final int cancel_button_image_alpha = 2131427332;
        public static final int google_play_services_version = 2131427336;
        public static final int status_bar_notification_info_maxnum = 2131427349;

        private integer() {
        }
    }

    public static final class layout {
        public static final int custom_dialog = 2131558440;
        public static final int notification_action = 2131558499;
        public static final int notification_action_tombstone = 2131558500;
        public static final int notification_media_action = 2131558501;
        public static final int notification_media_cancel_action = 2131558502;
        public static final int notification_template_big_media = 2131558503;
        public static final int notification_template_big_media_custom = 2131558504;
        public static final int notification_template_big_media_narrow = 2131558505;
        public static final int notification_template_big_media_narrow_custom = 2131558506;
        public static final int notification_template_custom_big = 2131558507;
        public static final int notification_template_icon_group = 2131558508;
        public static final int notification_template_lines_media = 2131558509;
        public static final int notification_template_media = 2131558510;
        public static final int notification_template_media_custom = 2131558511;
        public static final int notification_template_part_chronometer = 2131558512;
        public static final int notification_template_part_time = 2131558513;

        private layout() {
        }
    }

    public static final class string {
        public static final int common_google_play_services_enable_button = 2131951654;
        public static final int common_google_play_services_enable_text = 2131951655;
        public static final int common_google_play_services_enable_title = 2131951656;
        public static final int common_google_play_services_install_button = 2131951657;
        public static final int common_google_play_services_install_text = 2131951658;
        public static final int common_google_play_services_install_title = 2131951659;
        public static final int common_google_play_services_notification_channel_name = 2131951660;
        public static final int common_google_play_services_notification_ticker = 2131951661;
        public static final int common_google_play_services_unknown_issue = 2131951662;
        public static final int common_google_play_services_unsupported_text = 2131951663;
        public static final int common_google_play_services_update_button = 2131951664;
        public static final int common_google_play_services_update_text = 2131951665;
        public static final int common_google_play_services_update_title = 2131951666;
        public static final int common_google_play_services_updating_text = 2131951667;
        public static final int common_google_play_services_wear_update_text = 2131951668;
        public static final int common_open_on_phone = 2131951669;
        public static final int common_signin_button_text = 2131951670;
        public static final int common_signin_button_text_long = 2131951671;
        public static final int status_bar_notification_info_overflow = 2131951751;

        private string() {
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 2132017496;
        public static final int TextAppearance_Compat_Notification_Info = 2132017497;
        public static final int TextAppearance_Compat_Notification_Info_Media = 2132017498;
        public static final int TextAppearance_Compat_Notification_Line2 = 2132017499;
        public static final int TextAppearance_Compat_Notification_Line2_Media = 2132017500;
        public static final int TextAppearance_Compat_Notification_Media = 2132017501;
        public static final int TextAppearance_Compat_Notification_Time = 2132017502;
        public static final int TextAppearance_Compat_Notification_Time_Media = 2132017503;
        public static final int TextAppearance_Compat_Notification_Title = 2132017504;
        public static final int TextAppearance_Compat_Notification_Title_Media = 2132017505;
        public static final int Widget_Compat_NotificationActionContainer = 2132017732;
        public static final int Widget_Compat_NotificationActionText = 2132017733;
        public static final int Widget_Support_CoordinatorLayout = 2132017838;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] ColorStateListItem = new int[]{16843173, 16843551, 16844359, 2130968622, 2130969053};
        public static final int ColorStateListItem_alpha = 3;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int ColorStateListItem_android_lStar = 2;
        public static final int ColorStateListItem_lStar = 4;
        public static final int[] CoordinatorLayout = new int[]{2130969052, 2130969396};
        public static final int[] CoordinatorLayout_Layout = new int[]{16842931, 2130969061, 2130969062, 2130969063, 2130969112, 2130969122, 2130969123};
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static final int CoordinatorLayout_Layout_layout_anchor = 1;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static final int CoordinatorLayout_Layout_layout_behavior = 3;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static final int CoordinatorLayout_Layout_layout_keyline = 6;
        public static final int CoordinatorLayout_keylines = 0;
        public static final int CoordinatorLayout_statusBarBackground = 1;
        public static final int[] FontFamily = new int[]{2130968968, 2130968969, 2130968970, 2130968971, 2130968972, 2130968973, 2130968974};
        public static final int[] FontFamilyFont = new int[]{16844082, 16844083, 16844095, 16844143, 16844144, 2130968966, 2130968975, 2130968976, 2130968977, 2130969535};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int FontFamily_fontProviderSystemFontFamily = 6;
        public static final int[] GradientColor = new int[]{16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = new int[]{16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
        public static final int[] LoadingImageView = new int[]{2130968755, 2130969013, 2130969014};
        public static final int LoadingImageView_circleCrop = 0;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 2;
        public static final int[] RecyclerView = new int[]{16842948, 16842987, 16842993, 2130968939, 2130968940, 2130968941, 2130968942, 2130968943, 2130969060, 2130969285, 2130969372, 2130969383};
        public static final int RecyclerView_android_clipToPadding = 1;
        public static final int RecyclerView_android_descendantFocusability = 2;
        public static final int RecyclerView_android_orientation = 0;
        public static final int RecyclerView_fastScrollEnabled = 3;
        public static final int RecyclerView_fastScrollHorizontalThumbDrawable = 4;
        public static final int RecyclerView_fastScrollHorizontalTrackDrawable = 5;
        public static final int RecyclerView_fastScrollVerticalThumbDrawable = 6;
        public static final int RecyclerView_fastScrollVerticalTrackDrawable = 7;
        public static final int RecyclerView_layoutManager = 8;
        public static final int RecyclerView_reverseLayout = 9;
        public static final int RecyclerView_spanCount = 10;
        public static final int RecyclerView_stackFromEnd = 11;
        public static final int[] SignInButton = new int[]{2130968700, 2130968798, 2130969304};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_colorScheme = 1;
        public static final int SignInButton_scopeUris = 2;

        private styleable() {
        }
    }

}

