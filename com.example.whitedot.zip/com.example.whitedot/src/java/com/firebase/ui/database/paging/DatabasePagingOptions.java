/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.LiveData
 *  androidx.paging.Pager
 *  androidx.paging.PagingConfig
 *  androidx.paging.PagingData
 *  androidx.paging.PagingLiveData
 *  androidx.paging.PagingSource
 *  androidx.recyclerview.widget.DiffUtil
 *  androidx.recyclerview.widget.DiffUtil$ItemCallback
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.Query
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.jvm.functions.Function0
 */
package com.firebase.ui.database.paging;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.paging.Pager;
import androidx.paging.PagingConfig;
import androidx.paging.PagingData;
import androidx.paging.PagingLiveData;
import androidx.paging.PagingSource;
import androidx.recyclerview.widget.DiffUtil;
import com.firebase.ui.database.ClassSnapshotParser;
import com.firebase.ui.database.SnapshotParser;
import com.firebase.ui.database.paging.DatabasePagingOptions$Builder$$ExternalSyntheticLambda0;
import com.firebase.ui.database.paging.DatabasePagingSource;
import com.firebase.ui.database.paging.DefaultSnapshotDiffCallback;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.Query;
import kotlin.jvm.functions.Function0;

public final class DatabasePagingOptions<T> {
    private final LiveData<PagingData<DataSnapshot>> mData;
    private final DiffUtil.ItemCallback<DataSnapshot> mDiffCallback;
    private final LifecycleOwner mOwner;
    private final SnapshotParser<T> mParser;

    private DatabasePagingOptions(LiveData<PagingData<DataSnapshot>> liveData, SnapshotParser<T> snapshotParser, DiffUtil.ItemCallback<DataSnapshot> itemCallback, LifecycleOwner lifecycleOwner) {
        this.mParser = snapshotParser;
        this.mData = liveData;
        this.mDiffCallback = itemCallback;
        this.mOwner = lifecycleOwner;
    }

    public LiveData<PagingData<DataSnapshot>> getData() {
        return this.mData;
    }

    public DiffUtil.ItemCallback<DataSnapshot> getDiffCallback() {
        return this.mDiffCallback;
    }

    public LifecycleOwner getOwner() {
        return this.mOwner;
    }

    public SnapshotParser<T> getParser() {
        return this.mParser;
    }

    public static final class Builder<T> {
        private LiveData<PagingData<DataSnapshot>> mData;
        private DiffUtil.ItemCallback<DataSnapshot> mDiffCallback;
        private LifecycleOwner mOwner;
        private SnapshotParser<T> mParser;

        static /* synthetic */ PagingSource lambda$setQuery$0(Query query) {
            return new DatabasePagingSource(query);
        }

        public DatabasePagingOptions<T> build() {
            if (this.mData != null) {
                if (this.mDiffCallback == null) {
                    this.mDiffCallback = new DefaultSnapshotDiffCallback<T>(this.mParser);
                }
                DatabasePagingOptions databasePagingOptions = new DatabasePagingOptions(this.mData, this.mParser, this.mDiffCallback, this.mOwner);
                return databasePagingOptions;
            }
            throw new IllegalStateException("Must call setQuery() before calling build().");
        }

        public Builder<T> setDiffCallback(DiffUtil.ItemCallback<DataSnapshot> itemCallback) {
            this.mDiffCallback = itemCallback;
            return this;
        }

        public Builder<T> setLifecycleOwner(LifecycleOwner lifecycleOwner) {
            this.mOwner = lifecycleOwner;
            return this;
        }

        public Builder<T> setQuery(Query query, PagingConfig pagingConfig, SnapshotParser<T> snapshotParser) {
            this.mData = PagingLiveData.cachedIn((LiveData)PagingLiveData.getLiveData((Pager)new Pager(pagingConfig, (Function0)new DatabasePagingOptions$Builder$$ExternalSyntheticLambda0(query))), (Lifecycle)this.mOwner.getLifecycle());
            this.mParser = snapshotParser;
            return this;
        }

        public Builder<T> setQuery(Query query, PagingConfig pagingConfig, Class<T> class_) {
            return this.setQuery(query, pagingConfig, new ClassSnapshotParser<T>(class_));
        }
    }

}

