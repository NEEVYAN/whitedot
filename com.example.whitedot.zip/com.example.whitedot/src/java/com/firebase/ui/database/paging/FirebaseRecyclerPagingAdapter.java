/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.LifecycleObserver
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.LiveData
 *  androidx.lifecycle.Observer
 *  androidx.lifecycle.OnLifecycleEvent
 *  androidx.paging.PagingData
 *  androidx.paging.PagingDataAdapter
 *  androidx.recyclerview.widget.DiffUtil
 *  androidx.recyclerview.widget.DiffUtil$ItemCallback
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseReference
 *  java.lang.Object
 */
package com.firebase.ui.database.paging;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.paging.PagingData;
import androidx.paging.PagingDataAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.database.SnapshotParser;
import com.firebase.ui.database.paging.DatabasePagingOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;

public abstract class FirebaseRecyclerPagingAdapter<T, VH extends RecyclerView.ViewHolder>
extends PagingDataAdapter<DataSnapshot, VH>
implements LifecycleObserver {
    private final Observer<PagingData<DataSnapshot>> mDataObserver = new Observer<PagingData<DataSnapshot>>(){

        public void onChanged(PagingData<DataSnapshot> pagingData) {
            if (pagingData == null) {
                return;
            }
            FirebaseRecyclerPagingAdapter firebaseRecyclerPagingAdapter = FirebaseRecyclerPagingAdapter.this;
            firebaseRecyclerPagingAdapter.submitData(firebaseRecyclerPagingAdapter.mOptions.getOwner().getLifecycle(), pagingData);
        }
    };
    private DatabasePagingOptions<T> mOptions;
    private LiveData<PagingData<DataSnapshot>> mPagingData;
    private SnapshotParser<T> mParser;

    public FirebaseRecyclerPagingAdapter(DatabasePagingOptions<T> databasePagingOptions) {
        super(databasePagingOptions.getDiffCallback());
        this.mOptions = databasePagingOptions;
        this.init();
    }

    public DatabaseReference getRef(int n) {
        return ((DataSnapshot)this.getItem(n)).getRef();
    }

    public void init() {
        this.mPagingData = this.mOptions.getData();
        this.mParser = this.mOptions.getParser();
        if (this.mOptions.getOwner() != null) {
            this.mOptions.getOwner().getLifecycle().addObserver((LifecycleObserver)this);
        }
    }

    public void onBindViewHolder(VH VH, int n) {
        DataSnapshot dataSnapshot = (DataSnapshot)this.getItem(n);
        this.onBindViewHolder(VH, n, this.mParser.parseSnapshot((Object)dataSnapshot));
    }

    protected abstract void onBindViewHolder(VH var1, int var2, T var3);

    @OnLifecycleEvent(value=Lifecycle.Event.ON_START)
    public void startListening() {
        this.mPagingData.observeForever(this.mDataObserver);
    }

    @OnLifecycleEvent(value=Lifecycle.Event.ON_STOP)
    public void stopListening() {
        this.mPagingData.removeObserver(this.mDataObserver);
    }

    public void updateOptions(DatabasePagingOptions<T> databasePagingOptions) {
        this.mOptions = databasePagingOptions;
        boolean bl = this.mPagingData.hasObservers();
        if (this.mOptions.getOwner() != null) {
            this.mOptions.getOwner().getLifecycle().removeObserver((LifecycleObserver)this);
        }
        this.stopListening();
        this.init();
        if (bl) {
            this.startListening();
        }
    }

}

