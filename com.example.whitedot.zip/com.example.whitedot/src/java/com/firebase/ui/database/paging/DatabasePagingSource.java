/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.paging.PagingSource
 *  androidx.paging.PagingSource$LoadParams
 *  androidx.paging.PagingSource$LoadResult
 *  androidx.paging.PagingSource$LoadResult$Error
 *  androidx.paging.PagingSource$LoadResult$Page
 *  androidx.paging.PagingState
 *  androidx.paging.rxjava3.RxPagingSource
 *  com.google.android.gms.tasks.Task
 *  com.google.android.gms.tasks.Tasks
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseException
 *  com.google.firebase.database.Query
 *  io.reactivex.rxjava3.core.Scheduler
 *  io.reactivex.rxjava3.core.Single
 *  io.reactivex.rxjava3.functions.Function
 *  io.reactivex.rxjava3.schedulers.Schedulers
 *  java.lang.Exception
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.Callable
 *  java.util.concurrent.ExecutionException
 */
package com.firebase.ui.database.paging;

import androidx.paging.PagingSource;
import androidx.paging.PagingState;
import androidx.paging.rxjava3.RxPagingSource;
import com.firebase.ui.database.paging.DatabasePagingSource$$ExternalSyntheticLambda0;
import com.firebase.ui.database.paging.DatabasePagingSource$$ExternalSyntheticLambda1;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.Query;
import io.reactivex.rxjava3.core.Scheduler;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.functions.Function;
import io.reactivex.rxjava3.schedulers.Schedulers;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class DatabasePagingSource
extends RxPagingSource<String, DataSnapshot> {
    private static final String DETAILS_DATABASE_NOT_FOUND = "No data was returned for the given query: ";
    private static final String MESSAGE_DATABASE_NOT_FOUND = "Data not found at given child path!";
    private static final String STATUS_DATABASE_NOT_FOUND = "DATA_NOT_FOUND";
    private final Query mQuery;

    public static /* synthetic */ PagingSource.LoadResult.Error $r8$lambda$sW8_8fjeCXzioMOULyzC1AXsiZI(Throwable throwable) {
        return new PagingSource.LoadResult.Error(throwable);
    }

    public DatabasePagingSource(Query query) {
        this.mQuery = query;
    }

    private String getLastPageKey(List<DataSnapshot> list) {
        if (list.isEmpty()) {
            return null;
        }
        return ((DataSnapshot)list.get(-1 + list.size())).getKey();
    }

    private PagingSource.LoadResult<String, DataSnapshot> toLoadResult(List<DataSnapshot> list, String string2) {
        PagingSource.LoadResult.Page page = new PagingSource.LoadResult.Page(list, null, (Object)string2, Integer.MIN_VALUE, Integer.MIN_VALUE);
        return page;
    }

    public String getRefreshKey(PagingState<String, DataSnapshot> pagingState) {
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    /* synthetic */ PagingSource.LoadResult lambda$loadSingle$0$com-firebase-ui-database-paging-DatabasePagingSource(Task task, PagingSource.LoadParams loadParams) throws Exception {
        String string2;
        ArrayList arrayList;
        try {
            Tasks.await((Task)task);
            DataSnapshot dataSnapshot = (DataSnapshot)task.getResult();
            if (!dataSnapshot.exists()) throw DatabaseError.fromStatus((String)STATUS_DATABASE_NOT_FOUND, (String)MESSAGE_DATABASE_NOT_FOUND, (String)(DETAILS_DATABASE_NOT_FOUND + this.mQuery.toString())).toException();
            arrayList = new ArrayList();
            if (loadParams.getKey() == null) {
                Iterator iterator = dataSnapshot.getChildren().iterator();
                while (iterator.hasNext()) {
                    arrayList.add((Object)((DataSnapshot)iterator.next()));
                }
            } else {
                Iterator iterator = dataSnapshot.getChildren().iterator();
                if (iterator.hasNext()) {
                    iterator.next();
                }
                while (iterator.hasNext()) {
                    arrayList.add((Object)((DataSnapshot)iterator.next()));
                }
            }
            boolean bl = arrayList.isEmpty();
            string2 = null;
            if (bl) return this.toLoadResult((List<DataSnapshot>)arrayList, string2);
        }
        catch (ExecutionException executionException) {
            if (!(executionException.getCause() instanceof Exception)) throw new Exception((Throwable)executionException);
            throw (Exception)executionException.getCause();
        }
        string2 = this.getLastPageKey((List<DataSnapshot>)arrayList);
        return this.toLoadResult((List<DataSnapshot>)arrayList, string2);
    }

    public Single<PagingSource.LoadResult<String, DataSnapshot>> loadSingle(PagingSource.LoadParams<String> loadParams) {
        Task task = loadParams.getKey() == null ? this.mQuery.limitToFirst(loadParams.getLoadSize()).get() : this.mQuery.startAt(null, (String)loadParams.getKey()).limitToFirst(1 + loadParams.getLoadSize()).get();
        return Single.fromCallable((Callable)new DatabasePagingSource$$ExternalSyntheticLambda1(this, task, loadParams)).subscribeOn(Schedulers.io()).onErrorReturn((Function)DatabasePagingSource$$ExternalSyntheticLambda0.INSTANCE);
    }
}

