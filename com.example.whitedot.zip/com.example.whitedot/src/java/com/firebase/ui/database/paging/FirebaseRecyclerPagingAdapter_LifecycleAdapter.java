/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.GeneratedAdapter
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.MethodCallsLogger
 *  java.lang.Object
 *  java.lang.String
 */
package com.firebase.ui.database.paging;

import androidx.lifecycle.GeneratedAdapter;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MethodCallsLogger;
import com.firebase.ui.database.paging.FirebaseRecyclerPagingAdapter;

public class FirebaseRecyclerPagingAdapter_LifecycleAdapter
implements GeneratedAdapter {
    final FirebaseRecyclerPagingAdapter mReceiver;

    FirebaseRecyclerPagingAdapter_LifecycleAdapter(FirebaseRecyclerPagingAdapter firebaseRecyclerPagingAdapter) {
        this.mReceiver = firebaseRecyclerPagingAdapter;
    }

    public void callMethods(LifecycleOwner lifecycleOwner, Lifecycle.Event event, boolean bl, MethodCallsLogger methodCallsLogger) {
        boolean bl2 = methodCallsLogger != null;
        if (bl) {
            return;
        }
        if (event == Lifecycle.Event.ON_START) {
            if (!bl2 || methodCallsLogger.approveCall("startListening", 1)) {
                this.mReceiver.startListening();
            }
            return;
        }
        if (event == Lifecycle.Event.ON_STOP) {
            if (!bl2 || methodCallsLogger.approveCall("stopListening", 1)) {
                this.mReceiver.stopListening();
            }
            return;
        }
    }
}

