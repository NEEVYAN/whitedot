/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  java.lang.Object
 */
package com.firebase.ui.database;

import com.firebase.ui.common.BaseChangeEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

public interface ChangeEventListener
extends BaseChangeEventListener<DataSnapshot, DatabaseError> {
}

