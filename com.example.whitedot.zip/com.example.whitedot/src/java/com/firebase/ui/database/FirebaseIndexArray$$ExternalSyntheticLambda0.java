/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.database.DataSnapshot
 *  java.lang.Object
 */
package com.firebase.ui.database;

import com.firebase.ui.database.FirebaseIndexArray;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.database.DataSnapshot;

public final class FirebaseIndexArray$$ExternalSyntheticLambda0
implements SnapshotParser {
    public static final /* synthetic */ FirebaseIndexArray$$ExternalSyntheticLambda0 INSTANCE;

    static /* synthetic */ {
        INSTANCE = new FirebaseIndexArray$$ExternalSyntheticLambda0();
    }

    private /* synthetic */ FirebaseIndexArray$$ExternalSyntheticLambda0() {
    }

    @Override
    public final Object parseSnapshot(Object object) {
        return FirebaseIndexArray.lambda$new$0((DataSnapshot)object);
    }
}

