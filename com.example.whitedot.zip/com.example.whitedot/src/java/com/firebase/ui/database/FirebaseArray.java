/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.database.ChildEventListener
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.Query
 *  com.google.firebase.database.ValueEventListener
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package com.firebase.ui.database;

import com.firebase.ui.common.ChangeEventType;
import com.firebase.ui.database.ObservableSnapshotArray;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FirebaseArray<T>
extends ObservableSnapshotArray<T>
implements ChildEventListener,
ValueEventListener {
    private Query mQuery;
    private final List<DataSnapshot> mSnapshots = new ArrayList();

    public FirebaseArray(Query query, SnapshotParser<T> snapshotParser) {
        super(snapshotParser);
        this.mQuery = query;
    }

    private int getIndexForKey(String string2) {
        int n = 0;
        Iterator iterator = this.mSnapshots.iterator();
        while (iterator.hasNext()) {
            if (((DataSnapshot)iterator.next()).getKey().equals((Object)string2)) {
                return n;
            }
            ++n;
        }
        throw new IllegalArgumentException("Key not found");
    }

    @Override
    protected List<DataSnapshot> getSnapshots() {
        return this.mSnapshots;
    }

    public void onCancelled(DatabaseError databaseError) {
        this.notifyOnError(databaseError);
    }

    public void onChildAdded(DataSnapshot dataSnapshot, String string2) {
        int n = 0;
        if (string2 != null) {
            n = 1 + this.getIndexForKey(string2);
        }
        this.mSnapshots.add(n, (Object)dataSnapshot);
        this.notifyOnChildChanged(ChangeEventType.ADDED, dataSnapshot, n, -1);
    }

    public void onChildChanged(DataSnapshot dataSnapshot, String string2) {
        int n = this.getIndexForKey(dataSnapshot.getKey());
        this.mSnapshots.set(n, (Object)dataSnapshot);
        this.notifyOnChildChanged(ChangeEventType.CHANGED, dataSnapshot, n, -1);
    }

    public void onChildMoved(DataSnapshot dataSnapshot, String string2) {
        int n = this.getIndexForKey(dataSnapshot.getKey());
        this.mSnapshots.remove(n);
        int n2 = string2 == null ? 0 : 1 + this.getIndexForKey(string2);
        this.mSnapshots.add(n2, (Object)dataSnapshot);
        this.notifyOnChildChanged(ChangeEventType.MOVED, dataSnapshot, n2, n);
    }

    public void onChildRemoved(DataSnapshot dataSnapshot) {
        int n = this.getIndexForKey(dataSnapshot.getKey());
        this.mSnapshots.remove(n);
        this.notifyOnChildChanged(ChangeEventType.REMOVED, dataSnapshot, n, -1);
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        this.mQuery.addChildEventListener((ChildEventListener)this);
        this.mQuery.addValueEventListener((ValueEventListener)this);
    }

    public void onDataChange(DataSnapshot dataSnapshot) {
        this.notifyOnDataChanged();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.mQuery.removeEventListener((ValueEventListener)this);
        this.mQuery.removeEventListener((ChildEventListener)this);
    }
}

