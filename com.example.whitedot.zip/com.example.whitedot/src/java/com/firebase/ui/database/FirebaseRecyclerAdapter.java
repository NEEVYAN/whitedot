/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.LifecycleObserver
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.OnLifecycleEvent
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseException
 *  com.google.firebase.database.DatabaseReference
 *  java.lang.IllegalStateException
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.firebase.ui.database;

import android.util.Log;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.common.ChangeEventType;
import com.firebase.ui.database.FirebaseAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.firebase.ui.database.ObservableSnapshotArray;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.DatabaseReference;

public abstract class FirebaseRecyclerAdapter<T, VH extends RecyclerView.ViewHolder>
extends RecyclerView.Adapter<VH>
implements FirebaseAdapter<T> {
    private static final String TAG = "FirebaseRecyclerAdapter";
    private FirebaseRecyclerOptions<T> mOptions;
    private ObservableSnapshotArray<T> mSnapshots;

    public FirebaseRecyclerAdapter(FirebaseRecyclerOptions<T> firebaseRecyclerOptions) {
        this.mOptions = firebaseRecyclerOptions;
        this.mSnapshots = firebaseRecyclerOptions.getSnapshots();
        if (this.mOptions.getOwner() != null) {
            this.mOptions.getOwner().getLifecycle().addObserver((LifecycleObserver)this);
        }
    }

    @OnLifecycleEvent(value=Lifecycle.Event.ON_DESTROY)
    void cleanup(LifecycleOwner lifecycleOwner) {
        lifecycleOwner.getLifecycle().removeObserver((LifecycleObserver)this);
    }

    @Override
    public T getItem(int n) {
        return this.mSnapshots.get(n);
    }

    public int getItemCount() {
        if (this.mSnapshots.isListening(this)) {
            return this.mSnapshots.size();
        }
        return 0;
    }

    @Override
    public DatabaseReference getRef(int n) {
        return ((DataSnapshot)this.mSnapshots.getSnapshot(n)).getRef();
    }

    @Override
    public ObservableSnapshotArray<T> getSnapshots() {
        return this.mSnapshots;
    }

    public void onBindViewHolder(VH VH, int n) {
        this.onBindViewHolder(VH, n, this.getItem(n));
    }

    protected abstract void onBindViewHolder(VH var1, int var2, T var3);

    @Override
    public void onChildChanged(ChangeEventType changeEventType, DataSnapshot dataSnapshot, int n, int n2) {
        switch (1.$SwitchMap$com$firebase$ui$common$ChangeEventType[changeEventType.ordinal()]) {
            default: {
                throw new IllegalStateException("Incomplete case statement");
            }
            case 4: {
                this.notifyItemMoved(n2, n);
                return;
            }
            case 3: {
                this.notifyItemRemoved(n);
                return;
            }
            case 2: {
                this.notifyItemChanged(n);
                return;
            }
            case 1: 
        }
        this.notifyItemInserted(n);
    }

    @Override
    public void onDataChanged() {
    }

    @Override
    public void onError(DatabaseError databaseError) {
        Log.w((String)"FirebaseRecyclerAdapter", (Throwable)databaseError.toException());
    }

    @OnLifecycleEvent(value=Lifecycle.Event.ON_START)
    @Override
    public void startListening() {
        if (!this.mSnapshots.isListening(this)) {
            this.mSnapshots.addChangeEventListener(this);
        }
    }

    @OnLifecycleEvent(value=Lifecycle.Event.ON_STOP)
    @Override
    public void stopListening() {
        this.mSnapshots.removeChangeEventListener(this);
    }

    public void updateOptions(FirebaseRecyclerOptions<T> firebaseRecyclerOptions) {
        boolean bl = this.mSnapshots.isListening(this);
        if (this.mOptions.getOwner() != null) {
            this.mOptions.getOwner().getLifecycle().removeObserver((LifecycleObserver)this);
        }
        this.mSnapshots.clear();
        this.stopListening();
        this.mOptions = firebaseRecyclerOptions;
        this.mSnapshots = firebaseRecyclerOptions.getSnapshots();
        if (firebaseRecyclerOptions.getOwner() != null) {
            firebaseRecyclerOptions.getOwner().getLifecycle().addObserver((LifecycleObserver)this);
        }
        if (bl) {
            this.startListening();
        }
    }

}

