/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.database.DataSnapshot
 *  java.lang.Object
 *  java.lang.String
 */
package com.firebase.ui.database;

import com.firebase.ui.common.BaseCachingSnapshotParser;
import com.firebase.ui.common.BaseSnapshotParser;
import com.google.firebase.database.DataSnapshot;

public class CachingSnapshotParser<T>
extends BaseCachingSnapshotParser<DataSnapshot, T> {
    public CachingSnapshotParser(BaseSnapshotParser<DataSnapshot, T> baseSnapshotParser) {
        super(baseSnapshotParser);
    }

    @Override
    public String getId(DataSnapshot dataSnapshot) {
        return dataSnapshot.getKey();
    }
}

