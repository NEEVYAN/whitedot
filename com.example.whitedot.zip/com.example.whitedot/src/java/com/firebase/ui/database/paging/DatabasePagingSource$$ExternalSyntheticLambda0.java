/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.paging.PagingSource
 *  androidx.paging.PagingSource$LoadResult
 *  io.reactivex.rxjava3.functions.Function
 *  java.lang.Object
 *  java.lang.Throwable
 */
package com.firebase.ui.database.paging;

import androidx.paging.PagingSource;
import com.firebase.ui.database.paging.DatabasePagingSource;
import io.reactivex.rxjava3.functions.Function;

public final class DatabasePagingSource$$ExternalSyntheticLambda0
implements Function {
    public static final /* synthetic */ DatabasePagingSource$$ExternalSyntheticLambda0 INSTANCE;

    static /* synthetic */ {
        INSTANCE = new DatabasePagingSource$$ExternalSyntheticLambda0();
    }

    private /* synthetic */ DatabasePagingSource$$ExternalSyntheticLambda0() {
    }

    public final Object apply(Object object) {
        return (PagingSource.LoadResult)DatabasePagingSource.$r8$lambda$sW8_8fjeCXzioMOULyzC1AXsiZI((Throwable)object);
    }
}

