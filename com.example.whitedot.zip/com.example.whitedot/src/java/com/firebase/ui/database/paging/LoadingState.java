/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.firebase.ui.database.paging;

public final class LoadingState
extends Enum<LoadingState> {
    private static final /* synthetic */ LoadingState[] $VALUES;
    public static final /* enum */ LoadingState ERROR;
    public static final /* enum */ LoadingState FINISHED;
    public static final /* enum */ LoadingState LOADED;
    public static final /* enum */ LoadingState LOADING_INITIAL;
    public static final /* enum */ LoadingState LOADING_MORE;

    static {
        LoadingState loadingState;
        LoadingState loadingState2;
        LoadingState loadingState3;
        LoadingState loadingState4;
        LoadingState loadingState5;
        LOADING_INITIAL = loadingState4 = new LoadingState();
        LOADING_MORE = loadingState3 = new LoadingState();
        LOADED = loadingState = new LoadingState();
        FINISHED = loadingState2 = new LoadingState();
        ERROR = loadingState5 = new LoadingState();
        $VALUES = new LoadingState[]{loadingState4, loadingState3, loadingState, loadingState2, loadingState5};
    }

    public static LoadingState valueOf(String string2) {
        return (LoadingState)Enum.valueOf(LoadingState.class, (String)string2);
    }

    public static LoadingState[] values() {
        return (LoadingState[])$VALUES.clone();
    }
}

