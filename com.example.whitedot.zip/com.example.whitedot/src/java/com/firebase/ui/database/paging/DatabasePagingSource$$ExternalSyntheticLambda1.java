/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.paging.PagingSource
 *  androidx.paging.PagingSource$LoadParams
 *  androidx.paging.PagingSource$LoadResult
 *  com.google.android.gms.tasks.Task
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package com.firebase.ui.database.paging;

import androidx.paging.PagingSource;
import com.firebase.ui.database.paging.DatabasePagingSource;
import com.google.android.gms.tasks.Task;
import java.util.concurrent.Callable;

public final class DatabasePagingSource$$ExternalSyntheticLambda1
implements Callable {
    public final /* synthetic */ DatabasePagingSource f$0;
    public final /* synthetic */ Task f$1;
    public final /* synthetic */ PagingSource.LoadParams f$2;

    public /* synthetic */ DatabasePagingSource$$ExternalSyntheticLambda1(DatabasePagingSource databasePagingSource, Task task, PagingSource.LoadParams loadParams) {
        this.f$0 = databasePagingSource;
        this.f$1 = task;
        this.f$2 = loadParams;
    }

    public final Object call() {
        return this.f$0.lambda$loadSingle$0$com-firebase-ui-database-paging-DatabasePagingSource(this.f$1, this.f$2);
    }
}

