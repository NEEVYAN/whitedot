/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.recyclerview.widget.DiffUtil
 *  androidx.recyclerview.widget.DiffUtil$ItemCallback
 *  com.google.firebase.database.DataSnapshot
 *  java.lang.Object
 *  java.lang.String
 */
package com.firebase.ui.database.paging;

import androidx.recyclerview.widget.DiffUtil;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.database.DataSnapshot;

public class DefaultSnapshotDiffCallback<T>
extends DiffUtil.ItemCallback<DataSnapshot> {
    private final SnapshotParser<T> mParser;

    public DefaultSnapshotDiffCallback(SnapshotParser<T> snapshotParser) {
        this.mParser = snapshotParser;
    }

    public boolean areContentsTheSame(DataSnapshot dataSnapshot, DataSnapshot dataSnapshot2) {
        return this.mParser.parseSnapshot((Object)dataSnapshot).equals(this.mParser.parseSnapshot((Object)dataSnapshot2));
    }

    public boolean areItemsTheSame(DataSnapshot dataSnapshot, DataSnapshot dataSnapshot2) {
        return dataSnapshot.getKey().equals((Object)dataSnapshot2.getKey());
    }
}

