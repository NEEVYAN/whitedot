/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  java.lang.Object
 */
package com.firebase.ui.database;

import com.firebase.ui.common.BaseCachingSnapshotParser;
import com.firebase.ui.common.BaseObservableSnapshotArray;
import com.firebase.ui.common.BaseSnapshotParser;
import com.firebase.ui.database.CachingSnapshotParser;
import com.firebase.ui.database.ChangeEventListener;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

public abstract class ObservableSnapshotArray<T>
extends BaseObservableSnapshotArray<DataSnapshot, DatabaseError, ChangeEventListener, T> {
    public ObservableSnapshotArray(SnapshotParser<T> snapshotParser) {
        super(new CachingSnapshotParser(snapshotParser));
    }
}

