/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.LifecycleOwner
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.Query
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 */
package com.firebase.ui.database;

import androidx.lifecycle.LifecycleOwner;
import com.firebase.ui.common.Preconditions;
import com.firebase.ui.database.ClassSnapshotParser;
import com.firebase.ui.database.FirebaseArray;
import com.firebase.ui.database.FirebaseIndexArray;
import com.firebase.ui.database.ObservableSnapshotArray;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;

public final class FirebaseListOptions<T> {
    private static final String ERR_SNAPSHOTS_SET = "Snapshot array already set. Call only one of setSnapshotArray, setQuery, or setIndexedQuery.";
    private final int mLayout;
    private final LifecycleOwner mOwner;
    private final ObservableSnapshotArray<T> mSnapshots;

    private FirebaseListOptions(ObservableSnapshotArray<T> observableSnapshotArray, int n, LifecycleOwner lifecycleOwner) {
        this.mSnapshots = observableSnapshotArray;
        this.mLayout = n;
        this.mOwner = lifecycleOwner;
    }

    public int getLayout() {
        return this.mLayout;
    }

    public LifecycleOwner getOwner() {
        return this.mOwner;
    }

    public ObservableSnapshotArray<T> getSnapshots() {
        return this.mSnapshots;
    }

    public static final class Builder<T> {
        private Integer mLayout;
        private LifecycleOwner mOwner;
        private ObservableSnapshotArray<T> mSnapshots;

        public FirebaseListOptions<T> build() {
            Preconditions.assertNonNull(this.mSnapshots, "Snapshot array cannot be null. Call setQuery or setSnapshotArray.");
            Preconditions.assertNonNull((Object)this.mLayout, "Layout cannot be null. Call setLayout.");
            return new FirebaseListOptions(this.mSnapshots, this.mLayout, this.mOwner);
        }

        public Builder<T> setIndexedQuery(Query query, DatabaseReference databaseReference, SnapshotParser<T> snapshotParser) {
            Preconditions.assertNull(this.mSnapshots, FirebaseListOptions.ERR_SNAPSHOTS_SET);
            this.mSnapshots = new FirebaseIndexArray<T>(query, databaseReference, snapshotParser);
            return this;
        }

        public Builder<T> setIndexedQuery(Query query, DatabaseReference databaseReference, Class<T> class_) {
            return this.setIndexedQuery(query, databaseReference, new ClassSnapshotParser<T>(class_));
        }

        public Builder<T> setLayout(int n) {
            this.mLayout = n;
            return this;
        }

        public Builder<T> setLifecycleOwner(LifecycleOwner lifecycleOwner) {
            this.mOwner = lifecycleOwner;
            return this;
        }

        public Builder<T> setQuery(Query query, SnapshotParser<T> snapshotParser) {
            Preconditions.assertNull(this.mSnapshots, FirebaseListOptions.ERR_SNAPSHOTS_SET);
            this.mSnapshots = new FirebaseArray<T>(query, snapshotParser);
            return this;
        }

        public Builder<T> setQuery(Query query, Class<T> class_) {
            return this.setQuery(query, new ClassSnapshotParser<T>(class_));
        }

        public Builder<T> setSnapshotArray(ObservableSnapshotArray<T> observableSnapshotArray) {
            Preconditions.assertNull(this.mSnapshots, FirebaseListOptions.ERR_SNAPSHOTS_SET);
            this.mSnapshots = observableSnapshotArray;
            return this;
        }
    }

}

