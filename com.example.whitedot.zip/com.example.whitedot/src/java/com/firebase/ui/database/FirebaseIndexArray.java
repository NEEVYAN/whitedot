/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.google.firebase.database.DataSnapshot
 *  com.google.firebase.database.DatabaseError
 *  com.google.firebase.database.DatabaseReference
 *  com.google.firebase.database.Query
 *  com.google.firebase.database.ValueEventListener
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 */
package com.firebase.ui.database;

import android.util.Log;
import com.firebase.ui.common.ChangeEventType;
import com.firebase.ui.database.ChangeEventListener;
import com.firebase.ui.database.FirebaseArray;
import com.firebase.ui.database.FirebaseIndexArray$$ExternalSyntheticLambda0;
import com.firebase.ui.database.ObservableSnapshotArray;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FirebaseIndexArray<T>
extends ObservableSnapshotArray<T>
implements ChangeEventListener {
    private static final String TAG = "FirebaseIndexArray";
    private DatabaseReference mDataRef;
    private final List<DataSnapshot> mDataSnapshots = new ArrayList();
    private boolean mHasPendingMoveOrDelete;
    private final FirebaseArray<String> mKeySnapshots;
    private final List<String> mKeysWithPendingUpdate = new ArrayList();
    private final Map<DatabaseReference, ValueEventListener> mRefs = new HashMap();

    public FirebaseIndexArray(Query query, DatabaseReference databaseReference, SnapshotParser<T> snapshotParser) {
        super(snapshotParser);
        this.mDataRef = databaseReference;
        this.mKeySnapshots = new FirebaseArray(query, FirebaseIndexArray$$ExternalSyntheticLambda0.INSTANCE);
    }

    private boolean isKeyAtIndex(String string2, int n) {
        return n >= 0 && n < this.size() && ((DataSnapshot)this.mDataSnapshots.get(n)).getKey().equals((Object)string2);
    }

    static /* synthetic */ String lambda$new$0(DataSnapshot dataSnapshot) {
        return dataSnapshot.getKey();
    }

    private void onKeyAdded(DataSnapshot dataSnapshot, int n) {
        String string2 = dataSnapshot.getKey();
        DatabaseReference databaseReference = this.mDataRef.child(string2);
        this.mKeysWithPendingUpdate.add((Object)string2);
        this.mRefs.put((Object)databaseReference, (Object)databaseReference.addValueEventListener((ValueEventListener)new DataRefListener(n)));
    }

    private void onKeyMoved(DataSnapshot dataSnapshot, int n, int n2) {
        String string2 = dataSnapshot.getKey();
        if (this.isKeyAtIndex(string2, n2)) {
            DataSnapshot dataSnapshot2 = (DataSnapshot)this.mDataSnapshots.remove(n2);
            int n3 = this.returnOrFindIndexForKey(n, string2);
            this.mHasPendingMoveOrDelete = true;
            this.mDataSnapshots.add(n3, (Object)dataSnapshot2);
            this.notifyOnChildChanged(ChangeEventType.MOVED, dataSnapshot2, n3, n2);
        }
    }

    private void onKeyRemoved(DataSnapshot dataSnapshot, int n) {
        int n2;
        String string2 = dataSnapshot.getKey();
        ValueEventListener valueEventListener = (ValueEventListener)this.mRefs.remove((Object)this.mDataRef.getRef().child(string2));
        if (valueEventListener != null) {
            this.mDataRef.child(string2).removeEventListener(valueEventListener);
        }
        if (this.isKeyAtIndex(string2, n2 = this.returnOrFindIndexForKey(n, string2))) {
            DataSnapshot dataSnapshot2 = (DataSnapshot)this.mDataSnapshots.remove(n2);
            this.mHasPendingMoveOrDelete = true;
            this.notifyOnChildChanged(ChangeEventType.REMOVED, dataSnapshot2, n2, -1);
        }
    }

    private int returnOrFindIndexForKey(int n, String string2) {
        String string3;
        if (this.isKeyAtIndex(string2, n)) {
            return n;
        }
        int n2 = this.size();
        int n3 = 0;
        for (int i = 0; n3 < n2 && i < this.mKeySnapshots.size() && !string2.equals((Object)(string3 = (String)this.mKeySnapshots.get(i))); ++i) {
            if (!((DataSnapshot)this.mDataSnapshots.get(n3)).getKey().equals((Object)string3)) continue;
            ++n3;
        }
        return n3;
    }

    @Override
    protected List<DataSnapshot> getSnapshots() {
        return this.mDataSnapshots;
    }

    @Override
    public void onChildChanged(ChangeEventType changeEventType, DataSnapshot dataSnapshot, int n, int n2) {
        switch (1.$SwitchMap$com$firebase$ui$common$ChangeEventType[changeEventType.ordinal()]) {
            default: {
                return;
            }
            case 4: {
                this.onKeyRemoved(dataSnapshot, n);
                return;
            }
            case 3: {
                return;
            }
            case 2: {
                this.onKeyMoved(dataSnapshot, n, n2);
                return;
            }
            case 1: 
        }
        this.onKeyAdded(dataSnapshot, n);
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        this.mKeySnapshots.addChangeEventListener(this);
    }

    @Override
    public void onDataChanged() {
        if (this.mHasPendingMoveOrDelete || this.mKeySnapshots.isEmpty()) {
            this.notifyOnDataChanged();
            this.mHasPendingMoveOrDelete = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.mKeySnapshots.removeChangeEventListener(this);
        for (DatabaseReference databaseReference : this.mRefs.keySet()) {
            databaseReference.removeEventListener((ValueEventListener)this.mRefs.get((Object)databaseReference));
        }
        this.mRefs.clear();
    }

    @Override
    public void onError(DatabaseError databaseError) {
        Log.e((String)TAG, (String)"A fatal error occurred retrieving the necessary keys to populate your adapter.");
    }

    private final class DataRefListener
    implements ValueEventListener {
        private int currentIndex;

        public DataRefListener(int n) {
            this.currentIndex = n;
        }

        public void onCancelled(DatabaseError databaseError) {
            FirebaseIndexArray.this.notifyOnError((Object)databaseError);
        }

        public void onDataChange(DataSnapshot dataSnapshot) {
            int n;
            String string2 = dataSnapshot.getKey();
            this.currentIndex = n = FirebaseIndexArray.this.returnOrFindIndexForKey(this.currentIndex, string2);
            if (dataSnapshot.getValue() != null) {
                if (FirebaseIndexArray.this.isKeyAtIndex(string2, n)) {
                    FirebaseIndexArray.this.mDataSnapshots.set(n, (Object)dataSnapshot);
                    FirebaseIndexArray.this.notifyOnChildChanged(ChangeEventType.CHANGED, (Object)dataSnapshot, n, -1);
                } else {
                    FirebaseIndexArray.this.mDataSnapshots.add(n, (Object)dataSnapshot);
                    FirebaseIndexArray.this.notifyOnChildChanged(ChangeEventType.ADDED, (Object)dataSnapshot, n, -1);
                }
            } else if (FirebaseIndexArray.this.isKeyAtIndex(string2, n)) {
                FirebaseIndexArray.this.mDataSnapshots.remove(n);
                FirebaseIndexArray.this.notifyOnChildChanged(ChangeEventType.REMOVED, (Object)dataSnapshot, n, -1);
            } else {
                Log.w((String)FirebaseIndexArray.TAG, (String)("Key not found at ref: " + (Object)dataSnapshot.getRef()));
            }
            FirebaseIndexArray.this.mKeysWithPendingUpdate.remove((Object)string2);
            if (FirebaseIndexArray.this.mKeysWithPendingUpdate.isEmpty()) {
                FirebaseIndexArray.this.notifyOnDataChanged();
            }
        }
    }

}

