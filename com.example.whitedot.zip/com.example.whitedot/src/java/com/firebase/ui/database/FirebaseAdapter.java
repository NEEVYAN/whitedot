/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.LifecycleObserver
 *  com.google.firebase.database.DatabaseReference
 *  java.lang.Object
 */
package com.firebase.ui.database;

import androidx.lifecycle.LifecycleObserver;
import com.firebase.ui.database.ChangeEventListener;
import com.firebase.ui.database.ObservableSnapshotArray;
import com.google.firebase.database.DatabaseReference;

interface FirebaseAdapter<T>
extends ChangeEventListener,
LifecycleObserver {
    public T getItem(int var1);

    public DatabaseReference getRef(int var1);

    public ObservableSnapshotArray<T> getSnapshots();

    public void startListening();

    public void stopListening();
}

