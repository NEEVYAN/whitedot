/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.database.Query
 *  java.lang.Object
 *  kotlin.jvm.functions.Function0
 */
package com.firebase.ui.database.paging;

import com.firebase.ui.database.paging.DatabasePagingOptions;
import com.google.firebase.database.Query;
import kotlin.jvm.functions.Function0;

public final class DatabasePagingOptions$Builder$$ExternalSyntheticLambda0
implements Function0 {
    public final /* synthetic */ Query f$0;

    public /* synthetic */ DatabasePagingOptions$Builder$$ExternalSyntheticLambda0(Query query) {
        this.f$0 = query;
    }

    public final Object invoke() {
        return DatabasePagingOptions.Builder.lambda$setQuery$0(this.f$0);
    }
}

