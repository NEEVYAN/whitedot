/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firebase.database.DataSnapshot
 *  java.lang.Object
 */
package com.firebase.ui.database;

import com.firebase.ui.common.BaseSnapshotParser;
import com.google.firebase.database.DataSnapshot;

public interface SnapshotParser<T>
extends BaseSnapshotParser<DataSnapshot, T> {
}

