/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.errorprone.annotations;

public final class Modifier
extends Enum<Modifier> {
    private static final /* synthetic */ Modifier[] $VALUES;
    public static final /* enum */ Modifier ABSTRACT;
    public static final /* enum */ Modifier DEFAULT;
    public static final /* enum */ Modifier FINAL;
    public static final /* enum */ Modifier NATIVE;
    public static final /* enum */ Modifier PRIVATE;
    public static final /* enum */ Modifier PROTECTED;
    public static final /* enum */ Modifier PUBLIC;
    public static final /* enum */ Modifier STATIC;
    public static final /* enum */ Modifier STRICTFP;
    public static final /* enum */ Modifier SYNCHRONIZED;
    public static final /* enum */ Modifier TRANSIENT;
    public static final /* enum */ Modifier VOLATILE;

    static {
        Modifier modifier;
        Modifier modifier2;
        Modifier modifier3;
        Modifier modifier4;
        Modifier modifier5;
        Modifier modifier6;
        Modifier modifier7;
        Modifier modifier8;
        Modifier modifier9;
        Modifier modifier10;
        Modifier modifier11;
        Modifier modifier12;
        PUBLIC = modifier6 = new Modifier();
        PROTECTED = modifier4 = new Modifier();
        PRIVATE = modifier11 = new Modifier();
        ABSTRACT = modifier = new Modifier();
        DEFAULT = modifier9 = new Modifier();
        STATIC = modifier5 = new Modifier();
        FINAL = modifier3 = new Modifier();
        TRANSIENT = modifier12 = new Modifier();
        VOLATILE = modifier8 = new Modifier();
        SYNCHRONIZED = modifier7 = new Modifier();
        NATIVE = modifier2 = new Modifier();
        STRICTFP = modifier10 = new Modifier();
        $VALUES = new Modifier[]{modifier6, modifier4, modifier11, modifier, modifier9, modifier5, modifier3, modifier12, modifier8, modifier7, modifier2, modifier10};
    }

    public static Modifier valueOf(String string2) {
        return (Modifier)Enum.valueOf(Modifier.class, (String)string2);
    }

    public static Modifier[] values() {
        return (Modifier[])$VALUES.clone();
    }
}

