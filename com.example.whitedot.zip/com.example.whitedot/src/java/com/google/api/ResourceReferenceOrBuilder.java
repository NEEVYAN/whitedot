/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.MessageLiteOrBuilder
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.api;

import com.google.protobuf.ByteString;
import com.google.protobuf.MessageLiteOrBuilder;

public interface ResourceReferenceOrBuilder
extends MessageLiteOrBuilder {
    public String getChildType();

    public ByteString getChildTypeBytes();

    public String getType();

    public ByteString getTypeBytes();
}

