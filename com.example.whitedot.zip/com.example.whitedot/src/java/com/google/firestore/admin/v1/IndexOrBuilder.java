/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firestore.admin.v1.Index
 *  com.google.firestore.admin.v1.Index$IndexField
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.MessageLiteOrBuilder
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.google.firestore.admin.v1;

import com.google.firestore.admin.v1.Index;
import com.google.protobuf.ByteString;
import com.google.protobuf.MessageLiteOrBuilder;
import java.util.List;

public interface IndexOrBuilder
extends MessageLiteOrBuilder {
    public Index.IndexField getFields(int var1);

    public int getFieldsCount();

    public List<Index.IndexField> getFieldsList();

    public String getName();

    public ByteString getNameBytes();

    public Index.QueryScope getQueryScope();

    public int getQueryScopeValue();

    public Index.State getState();

    public int getStateValue();
}

