/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$EnumLite
 *  com.google.protobuf.Internal$EnumLiteMap
 *  com.google.protobuf.Internal$EnumVerifier
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.MessageLiteOrBuilder
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Enum
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 *  java.nio.ByteBuffer
 *  java.util.Collections
 *  java.util.List
 */
package com.google.firestore.admin.v1;

import com.google.firestore.admin.v1.Index;
import com.google.firestore.admin.v1.IndexOrBuilder;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;

public final class Index
extends GeneratedMessageLite<Index, Builder>
implements IndexOrBuilder {
    private static final Index DEFAULT_INSTANCE;
    public static final int FIELDS_FIELD_NUMBER = 3;
    public static final int NAME_FIELD_NUMBER = 1;
    private static volatile Parser<Index> PARSER;
    public static final int QUERY_SCOPE_FIELD_NUMBER = 2;
    public static final int STATE_FIELD_NUMBER = 4;
    private Internal.ProtobufList<IndexField> fields_ = Index.emptyProtobufList();
    private String name_ = "";
    private int queryScope_;
    private int state_;

    static {
        Index index;
        DEFAULT_INSTANCE = index = new Index();
        GeneratedMessageLite.registerDefaultInstance(Index.class, (GeneratedMessageLite)index);
    }

    private Index() {
    }

    private void addAllFields(Iterable<? extends IndexField> iterable) {
        this.ensureFieldsIsMutable();
        AbstractMessageLite.addAll(iterable, this.fields_);
    }

    private void addFields(int n, IndexField indexField) {
        indexField.getClass();
        this.ensureFieldsIsMutable();
        this.fields_.add(n, (Object)indexField);
    }

    private void addFields(IndexField indexField) {
        indexField.getClass();
        this.ensureFieldsIsMutable();
        this.fields_.add((Object)indexField);
    }

    private void clearFields() {
        this.fields_ = Index.emptyProtobufList();
    }

    private void clearName() {
        this.name_ = Index.getDefaultInstance().getName();
    }

    private void clearQueryScope() {
        this.queryScope_ = 0;
    }

    private void clearState() {
        this.state_ = 0;
    }

    private void ensureFieldsIsMutable() {
        Internal.ProtobufList<IndexField> protobufList = this.fields_;
        if (!protobufList.isModifiable()) {
            this.fields_ = GeneratedMessageLite.mutableCopy(protobufList);
        }
    }

    public static Index getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.createBuilder();
    }

    public static Builder newBuilder(Index index) {
        return (Builder)DEFAULT_INSTANCE.createBuilder((GeneratedMessageLite)index);
    }

    public static Index parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (Index)Index.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Index parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Index)Index.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Index parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (Index)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static Index parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Index)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Index parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (Index)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static Index parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Index)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Index parseFrom(InputStream inputStream) throws IOException {
        return (Index)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static Index parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (Index)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Index parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
        return (Index)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer);
    }

    public static Index parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Index)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Index parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (Index)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static Index parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (Index)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<Index> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeFields(int n) {
        this.ensureFieldsIsMutable();
        this.fields_.remove(n);
    }

    private void setFields(int n, IndexField indexField) {
        indexField.getClass();
        this.ensureFieldsIsMutable();
        this.fields_.set(n, (Object)indexField);
    }

    private void setName(String string) {
        string.getClass();
        this.name_ = string;
    }

    private void setNameBytes(ByteString byteString) {
        Index.checkByteStringIsUtf8((ByteString)byteString);
        this.name_ = byteString.toStringUtf8();
    }

    private void setQueryScope(QueryScope queryScope) {
        this.queryScope_ = queryScope.getNumber();
    }

    private void setQueryScopeValue(int n) {
        this.queryScope_ = n;
    }

    private void setState(State state) {
        this.state_ = state.getNumber();
    }

    private void setStateValue(int n) {
        this.state_ = n;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object object, Object object2) {
        switch (1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke[methodToInvoke.ordinal()]) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                return null;
            }
            case 6: {
                return (byte)1;
            }
            case 5: {
                Parser<Index> parser = PARSER;
                if (parser != null) {
                    return parser;
                }
                Class<Index> class_ = Index.class;
                synchronized (Index.class) {
                    GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser = PARSER;
                    if (defaultInstanceBasedParser == null) {
                        PARSER = defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DEFAULT_INSTANCE);
                    }
                    // ** MonitorExit[var8_5] (shouldn't be in output)
                    return defaultInstanceBasedParser;
                }
            }
            case 4: {
                return DEFAULT_INSTANCE;
            }
            case 3: {
                Object[] arrobject = new Object[]{"name_", "queryScope_", "fields_", IndexField.class, "state_"};
                return Index.newMessageInfo((MessageLite)DEFAULT_INSTANCE, (String)"\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0001\u0000\u0001\u0208\u0002\f\u0003\u001b\u0004\f", (Object[])arrobject);
            }
            case 2: {
                return new Builder();
            }
            case 1: 
        }
        return new Index();
    }

    @Override
    public IndexField getFields(int n) {
        return (IndexField)this.fields_.get(n);
    }

    @Override
    public int getFieldsCount() {
        return this.fields_.size();
    }

    @Override
    public List<IndexField> getFieldsList() {
        return this.fields_;
    }

    public IndexFieldOrBuilder getFieldsOrBuilder(int n) {
        return this.fields_.get(n);
    }

    public List<? extends IndexFieldOrBuilder> getFieldsOrBuilderList() {
        return this.fields_;
    }

    @Override
    public String getName() {
        return this.name_;
    }

    @Override
    public ByteString getNameBytes() {
        return ByteString.copyFromUtf8((String)this.name_);
    }

    @Override
    public QueryScope getQueryScope() {
        QueryScope queryScope = QueryScope.forNumber(this.queryScope_);
        if (queryScope == null) {
            return QueryScope.UNRECOGNIZED;
        }
        return queryScope;
    }

    @Override
    public int getQueryScopeValue() {
        return this.queryScope_;
    }

    @Override
    public State getState() {
        State state = State.forNumber(this.state_);
        if (state == null) {
            return State.UNRECOGNIZED;
        }
        return state;
    }

    @Override
    public int getStateValue() {
        return this.state_;
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<Index, Builder>
    implements IndexOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public Builder addAllFields(Iterable<? extends IndexField> iterable) {
            this.copyOnWrite();
            ((Index)this.instance).addAllFields((Iterable<? extends IndexField>)iterable);
            return this;
        }

        public Builder addFields(int n, IndexField.Builder builder) {
            this.copyOnWrite();
            ((Index)this.instance).addFields(n, (IndexField)builder.build());
            return this;
        }

        public Builder addFields(int n, IndexField indexField) {
            this.copyOnWrite();
            ((Index)this.instance).addFields(n, indexField);
            return this;
        }

        public Builder addFields(IndexField.Builder builder) {
            this.copyOnWrite();
            ((Index)this.instance).addFields((IndexField)builder.build());
            return this;
        }

        public Builder addFields(IndexField indexField) {
            this.copyOnWrite();
            ((Index)this.instance).addFields(indexField);
            return this;
        }

        public Builder clearFields() {
            this.copyOnWrite();
            ((Index)this.instance).clearFields();
            return this;
        }

        public Builder clearName() {
            this.copyOnWrite();
            ((Index)this.instance).clearName();
            return this;
        }

        public Builder clearQueryScope() {
            this.copyOnWrite();
            ((Index)this.instance).clearQueryScope();
            return this;
        }

        public Builder clearState() {
            this.copyOnWrite();
            ((Index)this.instance).clearState();
            return this;
        }

        @Override
        public IndexField getFields(int n) {
            return ((Index)this.instance).getFields(n);
        }

        @Override
        public int getFieldsCount() {
            return ((Index)this.instance).getFieldsCount();
        }

        @Override
        public List<IndexField> getFieldsList() {
            return Collections.unmodifiableList(((Index)this.instance).getFieldsList());
        }

        @Override
        public String getName() {
            return ((Index)this.instance).getName();
        }

        @Override
        public ByteString getNameBytes() {
            return ((Index)this.instance).getNameBytes();
        }

        @Override
        public QueryScope getQueryScope() {
            return ((Index)this.instance).getQueryScope();
        }

        @Override
        public int getQueryScopeValue() {
            return ((Index)this.instance).getQueryScopeValue();
        }

        @Override
        public State getState() {
            return ((Index)this.instance).getState();
        }

        @Override
        public int getStateValue() {
            return ((Index)this.instance).getStateValue();
        }

        public Builder removeFields(int n) {
            this.copyOnWrite();
            ((Index)this.instance).removeFields(n);
            return this;
        }

        public Builder setFields(int n, IndexField.Builder builder) {
            this.copyOnWrite();
            ((Index)this.instance).setFields(n, (IndexField)builder.build());
            return this;
        }

        public Builder setFields(int n, IndexField indexField) {
            this.copyOnWrite();
            ((Index)this.instance).setFields(n, indexField);
            return this;
        }

        public Builder setName(String string) {
            this.copyOnWrite();
            ((Index)this.instance).setName(string);
            return this;
        }

        public Builder setNameBytes(ByteString byteString) {
            this.copyOnWrite();
            ((Index)this.instance).setNameBytes(byteString);
            return this;
        }

        public Builder setQueryScope(QueryScope queryScope) {
            this.copyOnWrite();
            ((Index)this.instance).setQueryScope(queryScope);
            return this;
        }

        public Builder setQueryScopeValue(int n) {
            this.copyOnWrite();
            ((Index)this.instance).setQueryScopeValue(n);
            return this;
        }

        public Builder setState(State state) {
            this.copyOnWrite();
            ((Index)this.instance).setState(state);
            return this;
        }

        public Builder setStateValue(int n) {
            this.copyOnWrite();
            ((Index)this.instance).setStateValue(n);
            return this;
        }
    }

    public static final class IndexField
    extends GeneratedMessageLite<IndexField, Builder>
    implements IndexFieldOrBuilder {
        public static final int ARRAY_CONFIG_FIELD_NUMBER = 3;
        private static final IndexField DEFAULT_INSTANCE;
        public static final int FIELD_PATH_FIELD_NUMBER = 1;
        public static final int ORDER_FIELD_NUMBER = 2;
        private static volatile Parser<IndexField> PARSER;
        private String fieldPath_ = "";
        private int valueModeCase_ = 0;
        private Object valueMode_;

        static {
            IndexField indexField;
            DEFAULT_INSTANCE = indexField = new IndexField();
            GeneratedMessageLite.registerDefaultInstance(IndexField.class, (GeneratedMessageLite)indexField);
        }

        private IndexField() {
        }

        private void clearArrayConfig() {
            if (this.valueModeCase_ == 3) {
                this.valueModeCase_ = 0;
                this.valueMode_ = null;
            }
        }

        private void clearFieldPath() {
            this.fieldPath_ = IndexField.getDefaultInstance().getFieldPath();
        }

        private void clearOrder() {
            if (this.valueModeCase_ == 2) {
                this.valueModeCase_ = 0;
                this.valueMode_ = null;
            }
        }

        private void clearValueMode() {
            this.valueModeCase_ = 0;
            this.valueMode_ = null;
        }

        public static IndexField getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder)DEFAULT_INSTANCE.createBuilder();
        }

        public static Builder newBuilder(IndexField indexField) {
            return (Builder)DEFAULT_INSTANCE.createBuilder((GeneratedMessageLite)indexField);
        }

        public static IndexField parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (IndexField)IndexField.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
        }

        public static IndexField parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (IndexField)IndexField.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static IndexField parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (IndexField)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
        }

        public static IndexField parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (IndexField)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static IndexField parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (IndexField)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
        }

        public static IndexField parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (IndexField)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static IndexField parseFrom(InputStream inputStream) throws IOException {
            return (IndexField)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
        }

        public static IndexField parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (IndexField)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static IndexField parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (IndexField)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer);
        }

        public static IndexField parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (IndexField)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static IndexField parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
            return (IndexField)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
        }

        public static IndexField parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (IndexField)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static Parser<IndexField> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setArrayConfig(ArrayConfig arrayConfig) {
            this.valueMode_ = arrayConfig.getNumber();
            this.valueModeCase_ = 3;
        }

        private void setArrayConfigValue(int n) {
            this.valueModeCase_ = 3;
            this.valueMode_ = n;
        }

        private void setFieldPath(String string) {
            string.getClass();
            this.fieldPath_ = string;
        }

        private void setFieldPathBytes(ByteString byteString) {
            IndexField.checkByteStringIsUtf8((ByteString)byteString);
            this.fieldPath_ = byteString.toStringUtf8();
        }

        private void setOrder(Order order) {
            this.valueMode_ = order.getNumber();
            this.valueModeCase_ = 2;
        }

        private void setOrderValue(int n) {
            this.valueModeCase_ = 2;
            this.valueMode_ = n;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object object, Object object2) {
            switch (com.google.firestore.admin.v1.Index$1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke[methodToInvoke.ordinal()]) {
                default: {
                    throw new UnsupportedOperationException();
                }
                case 7: {
                    return null;
                }
                case 6: {
                    return (byte)1;
                }
                case 5: {
                    Parser<IndexField> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    Class<IndexField> class_ = IndexField.class;
                    synchronized (IndexField.class) {
                        GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser = PARSER;
                        if (defaultInstanceBasedParser == null) {
                            PARSER = defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DEFAULT_INSTANCE);
                        }
                        // ** MonitorExit[var8_5] (shouldn't be in output)
                        return defaultInstanceBasedParser;
                    }
                }
                case 4: {
                    return DEFAULT_INSTANCE;
                }
                case 3: {
                    Object[] arrobject = new Object[]{"valueMode_", "valueModeCase_", "fieldPath_"};
                    return IndexField.newMessageInfo((MessageLite)DEFAULT_INSTANCE, (String)"\u0000\u0003\u0001\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0208\u0002?\u0000\u0003?\u0000", (Object[])arrobject);
                }
                case 2: {
                    return new Builder();
                }
                case 1: 
            }
            return new IndexField();
        }

        @Override
        public ArrayConfig getArrayConfig() {
            if (this.valueModeCase_ == 3) {
                ArrayConfig arrayConfig = ArrayConfig.forNumber((Integer)this.valueMode_);
                if (arrayConfig == null) {
                    return ArrayConfig.UNRECOGNIZED;
                }
                return arrayConfig;
            }
            return ArrayConfig.ARRAY_CONFIG_UNSPECIFIED;
        }

        @Override
        public int getArrayConfigValue() {
            if (this.valueModeCase_ == 3) {
                return (Integer)this.valueMode_;
            }
            return 0;
        }

        @Override
        public String getFieldPath() {
            return this.fieldPath_;
        }

        @Override
        public ByteString getFieldPathBytes() {
            return ByteString.copyFromUtf8((String)this.fieldPath_);
        }

        @Override
        public Order getOrder() {
            if (this.valueModeCase_ == 2) {
                Order order = Order.forNumber((Integer)this.valueMode_);
                if (order == null) {
                    return Order.UNRECOGNIZED;
                }
                return order;
            }
            return Order.ORDER_UNSPECIFIED;
        }

        @Override
        public int getOrderValue() {
            if (this.valueModeCase_ == 2) {
                return (Integer)this.valueMode_;
            }
            return 0;
        }

        @Override
        public ValueModeCase getValueModeCase() {
            return ValueModeCase.forNumber(this.valueModeCase_);
        }

        @Override
        public boolean hasArrayConfig() {
            return this.valueModeCase_ == 3;
        }

        @Override
        public boolean hasOrder() {
            return this.valueModeCase_ == 2;
        }

        public static final class Builder
        extends GeneratedMessageLite.Builder<IndexField, Builder>
        implements IndexFieldOrBuilder {
            private Builder() {
                super((GeneratedMessageLite)DEFAULT_INSTANCE);
            }

            public Builder clearArrayConfig() {
                this.copyOnWrite();
                ((IndexField)this.instance).clearArrayConfig();
                return this;
            }

            public Builder clearFieldPath() {
                this.copyOnWrite();
                ((IndexField)this.instance).clearFieldPath();
                return this;
            }

            public Builder clearOrder() {
                this.copyOnWrite();
                ((IndexField)this.instance).clearOrder();
                return this;
            }

            public Builder clearValueMode() {
                this.copyOnWrite();
                ((IndexField)this.instance).clearValueMode();
                return this;
            }

            @Override
            public ArrayConfig getArrayConfig() {
                return ((IndexField)this.instance).getArrayConfig();
            }

            @Override
            public int getArrayConfigValue() {
                return ((IndexField)this.instance).getArrayConfigValue();
            }

            @Override
            public String getFieldPath() {
                return ((IndexField)this.instance).getFieldPath();
            }

            @Override
            public ByteString getFieldPathBytes() {
                return ((IndexField)this.instance).getFieldPathBytes();
            }

            @Override
            public Order getOrder() {
                return ((IndexField)this.instance).getOrder();
            }

            @Override
            public int getOrderValue() {
                return ((IndexField)this.instance).getOrderValue();
            }

            @Override
            public ValueModeCase getValueModeCase() {
                return ((IndexField)this.instance).getValueModeCase();
            }

            @Override
            public boolean hasArrayConfig() {
                return ((IndexField)this.instance).hasArrayConfig();
            }

            @Override
            public boolean hasOrder() {
                return ((IndexField)this.instance).hasOrder();
            }

            public Builder setArrayConfig(ArrayConfig arrayConfig) {
                this.copyOnWrite();
                ((IndexField)this.instance).setArrayConfig(arrayConfig);
                return this;
            }

            public Builder setArrayConfigValue(int n) {
                this.copyOnWrite();
                ((IndexField)this.instance).setArrayConfigValue(n);
                return this;
            }

            public Builder setFieldPath(String string) {
                this.copyOnWrite();
                ((IndexField)this.instance).setFieldPath(string);
                return this;
            }

            public Builder setFieldPathBytes(ByteString byteString) {
                this.copyOnWrite();
                ((IndexField)this.instance).setFieldPathBytes(byteString);
                return this;
            }

            public Builder setOrder(Order order) {
                this.copyOnWrite();
                ((IndexField)this.instance).setOrder(order);
                return this;
            }

            public Builder setOrderValue(int n) {
                this.copyOnWrite();
                ((IndexField)this.instance).setOrderValue(n);
                return this;
            }
        }

    }

}

