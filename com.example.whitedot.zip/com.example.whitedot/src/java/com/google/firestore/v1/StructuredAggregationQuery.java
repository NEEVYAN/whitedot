/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.AbstractMessageLite
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.Int64Value
 *  com.google.protobuf.Int64Value$Builder
 *  com.google.protobuf.Internal
 *  com.google.protobuf.Internal$ProtobufList
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.MessageLiteOrBuilder
 *  com.google.protobuf.Parser
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Enum
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 *  java.nio.ByteBuffer
 *  java.util.Collections
 *  java.util.List
 */
package com.google.firestore.v1;

import com.google.firestore.v1.StructuredAggregationQuery;
import com.google.firestore.v1.StructuredAggregationQueryOrBuilder;
import com.google.firestore.v1.StructuredQuery;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Int64Value;
import com.google.protobuf.Internal;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;

public final class StructuredAggregationQuery
extends GeneratedMessageLite<StructuredAggregationQuery, Builder>
implements StructuredAggregationQueryOrBuilder {
    public static final int AGGREGATIONS_FIELD_NUMBER = 3;
    private static final StructuredAggregationQuery DEFAULT_INSTANCE;
    private static volatile Parser<StructuredAggregationQuery> PARSER;
    public static final int STRUCTURED_QUERY_FIELD_NUMBER = 1;
    private Internal.ProtobufList<Aggregation> aggregations_ = StructuredAggregationQuery.emptyProtobufList();
    private int queryTypeCase_ = 0;
    private Object queryType_;

    static {
        StructuredAggregationQuery structuredAggregationQuery;
        DEFAULT_INSTANCE = structuredAggregationQuery = new StructuredAggregationQuery();
        GeneratedMessageLite.registerDefaultInstance(StructuredAggregationQuery.class, (GeneratedMessageLite)structuredAggregationQuery);
    }

    private StructuredAggregationQuery() {
    }

    private void addAggregations(int n, Aggregation aggregation) {
        aggregation.getClass();
        this.ensureAggregationsIsMutable();
        this.aggregations_.add(n, (Object)aggregation);
    }

    private void addAggregations(Aggregation aggregation) {
        aggregation.getClass();
        this.ensureAggregationsIsMutable();
        this.aggregations_.add((Object)aggregation);
    }

    private void addAllAggregations(Iterable<? extends Aggregation> iterable) {
        this.ensureAggregationsIsMutable();
        AbstractMessageLite.addAll(iterable, this.aggregations_);
    }

    private void clearAggregations() {
        this.aggregations_ = StructuredAggregationQuery.emptyProtobufList();
    }

    private void clearQueryType() {
        this.queryTypeCase_ = 0;
        this.queryType_ = null;
    }

    private void clearStructuredQuery() {
        if (this.queryTypeCase_ == 1) {
            this.queryTypeCase_ = 0;
            this.queryType_ = null;
        }
    }

    private void ensureAggregationsIsMutable() {
        Internal.ProtobufList<Aggregation> protobufList = this.aggregations_;
        if (!protobufList.isModifiable()) {
            this.aggregations_ = GeneratedMessageLite.mutableCopy(protobufList);
        }
    }

    public static StructuredAggregationQuery getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private void mergeStructuredQuery(StructuredQuery structuredQuery) {
        structuredQuery.getClass();
        this.queryType_ = this.queryTypeCase_ == 1 && this.queryType_ != StructuredQuery.getDefaultInstance() ? ((StructuredQuery.Builder)StructuredQuery.newBuilder((StructuredQuery)this.queryType_).mergeFrom((GeneratedMessageLite)structuredQuery)).buildPartial() : structuredQuery;
        this.queryTypeCase_ = 1;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.createBuilder();
    }

    public static Builder newBuilder(StructuredAggregationQuery structuredAggregationQuery) {
        return (Builder)DEFAULT_INSTANCE.createBuilder((GeneratedMessageLite)structuredAggregationQuery);
    }

    public static StructuredAggregationQuery parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (StructuredAggregationQuery)StructuredAggregationQuery.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static StructuredAggregationQuery parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (StructuredAggregationQuery)StructuredAggregationQuery.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static StructuredAggregationQuery parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (StructuredAggregationQuery)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static StructuredAggregationQuery parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (StructuredAggregationQuery)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static StructuredAggregationQuery parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (StructuredAggregationQuery)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static StructuredAggregationQuery parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (StructuredAggregationQuery)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static StructuredAggregationQuery parseFrom(InputStream inputStream) throws IOException {
        return (StructuredAggregationQuery)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static StructuredAggregationQuery parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (StructuredAggregationQuery)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static StructuredAggregationQuery parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
        return (StructuredAggregationQuery)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer);
    }

    public static StructuredAggregationQuery parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (StructuredAggregationQuery)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static StructuredAggregationQuery parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (StructuredAggregationQuery)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static StructuredAggregationQuery parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (StructuredAggregationQuery)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<StructuredAggregationQuery> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void removeAggregations(int n) {
        this.ensureAggregationsIsMutable();
        this.aggregations_.remove(n);
    }

    private void setAggregations(int n, Aggregation aggregation) {
        aggregation.getClass();
        this.ensureAggregationsIsMutable();
        this.aggregations_.set(n, (Object)aggregation);
    }

    private void setStructuredQuery(StructuredQuery structuredQuery) {
        structuredQuery.getClass();
        this.queryType_ = structuredQuery;
        this.queryTypeCase_ = 1;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object object, Object object2) {
        switch (1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke[methodToInvoke.ordinal()]) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                return null;
            }
            case 6: {
                return (byte)1;
            }
            case 5: {
                Parser<StructuredAggregationQuery> parser = PARSER;
                if (parser != null) {
                    return parser;
                }
                Class<StructuredAggregationQuery> class_ = StructuredAggregationQuery.class;
                synchronized (StructuredAggregationQuery.class) {
                    GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser = PARSER;
                    if (defaultInstanceBasedParser == null) {
                        PARSER = defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DEFAULT_INSTANCE);
                    }
                    // ** MonitorExit[var8_5] (shouldn't be in output)
                    return defaultInstanceBasedParser;
                }
            }
            case 4: {
                return DEFAULT_INSTANCE;
            }
            case 3: {
                Object[] arrobject = new Object[]{"queryType_", "queryTypeCase_", StructuredQuery.class, "aggregations_", Aggregation.class};
                return StructuredAggregationQuery.newMessageInfo((MessageLite)DEFAULT_INSTANCE, (String)"\u0000\u0002\u0001\u0000\u0001\u0003\u0002\u0000\u0001\u0000\u0001<\u0000\u0003\u001b", (Object[])arrobject);
            }
            case 2: {
                return new Builder();
            }
            case 1: 
        }
        return new StructuredAggregationQuery();
    }

    @Override
    public Aggregation getAggregations(int n) {
        return (Aggregation)this.aggregations_.get(n);
    }

    @Override
    public int getAggregationsCount() {
        return this.aggregations_.size();
    }

    @Override
    public List<Aggregation> getAggregationsList() {
        return this.aggregations_;
    }

    public AggregationOrBuilder getAggregationsOrBuilder(int n) {
        return this.aggregations_.get(n);
    }

    public List<? extends AggregationOrBuilder> getAggregationsOrBuilderList() {
        return this.aggregations_;
    }

    @Override
    public QueryTypeCase getQueryTypeCase() {
        return QueryTypeCase.forNumber(this.queryTypeCase_);
    }

    @Override
    public StructuredQuery getStructuredQuery() {
        if (this.queryTypeCase_ == 1) {
            return (StructuredQuery)this.queryType_;
        }
        return StructuredQuery.getDefaultInstance();
    }

    @Override
    public boolean hasStructuredQuery() {
        return this.queryTypeCase_ == 1;
    }

    public static final class Aggregation
    extends GeneratedMessageLite<Aggregation, Builder>
    implements AggregationOrBuilder {
        public static final int ALIAS_FIELD_NUMBER = 7;
        public static final int COUNT_FIELD_NUMBER = 1;
        private static final Aggregation DEFAULT_INSTANCE;
        private static volatile Parser<Aggregation> PARSER;
        private String alias_ = "";
        private int operatorCase_ = 0;
        private Object operator_;

        static {
            Aggregation aggregation;
            DEFAULT_INSTANCE = aggregation = new Aggregation();
            GeneratedMessageLite.registerDefaultInstance(Aggregation.class, (GeneratedMessageLite)aggregation);
        }

        private Aggregation() {
        }

        static /* synthetic */ Aggregation access$500() {
            return DEFAULT_INSTANCE;
        }

        private void clearAlias() {
            this.alias_ = Aggregation.getDefaultInstance().getAlias();
        }

        private void clearCount() {
            if (this.operatorCase_ == 1) {
                this.operatorCase_ = 0;
                this.operator_ = null;
            }
        }

        private void clearOperator() {
            this.operatorCase_ = 0;
            this.operator_ = null;
        }

        public static Aggregation getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeCount(Count count) {
            count.getClass();
            this.operator_ = this.operatorCase_ == 1 && this.operator_ != Count.getDefaultInstance() ? ((Count.Builder)Count.newBuilder((Count)this.operator_).mergeFrom((GeneratedMessageLite)count)).buildPartial() : count;
            this.operatorCase_ = 1;
        }

        public static Builder newBuilder() {
            return DEFAULT_INSTANCE.createBuilder();
        }

        public static Builder newBuilder(Aggregation aggregation) {
            return DEFAULT_INSTANCE.createBuilder((GeneratedMessageLite)aggregation);
        }

        public static Aggregation parseDelimitedFrom(InputStream inputStream) throws IOException {
            return (Aggregation)Aggregation.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
        }

        public static Aggregation parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (Aggregation)Aggregation.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static Aggregation parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
            return (Aggregation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
        }

        public static Aggregation parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (Aggregation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static Aggregation parseFrom(CodedInputStream codedInputStream) throws IOException {
            return (Aggregation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
        }

        public static Aggregation parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (Aggregation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static Aggregation parseFrom(InputStream inputStream) throws IOException {
            return (Aggregation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
        }

        public static Aggregation parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
            return (Aggregation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static Aggregation parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
            return (Aggregation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer);
        }

        public static Aggregation parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (Aggregation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static Aggregation parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
            return (Aggregation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
        }

        public static Aggregation parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
            return (Aggregation)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
        }

        public static Parser<Aggregation> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAlias(String string) {
            string.getClass();
            this.alias_ = string;
        }

        private void setAliasBytes(ByteString byteString) {
            Aggregation.checkByteStringIsUtf8((ByteString)byteString);
            this.alias_ = byteString.toStringUtf8();
        }

        private void setCount(Count count) {
            count.getClass();
            this.operator_ = count;
            this.operatorCase_ = 1;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object object, Object object2) {
            switch (1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke[methodToInvoke.ordinal()]) {
                default: {
                    throw new UnsupportedOperationException();
                }
                case 7: {
                    return null;
                }
                case 6: {
                    return (byte)1;
                }
                case 5: {
                    Parser<Aggregation> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    Class<Aggregation> class_ = Aggregation.class;
                    synchronized (Aggregation.class) {
                        GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser = PARSER;
                        if (defaultInstanceBasedParser == null) {
                            PARSER = defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DEFAULT_INSTANCE);
                        }
                        // ** MonitorExit[var8_5] (shouldn't be in output)
                        return defaultInstanceBasedParser;
                    }
                }
                case 4: {
                    return DEFAULT_INSTANCE;
                }
                case 3: {
                    Object[] arrobject = new Object[]{"operator_", "operatorCase_", Count.class, "alias_"};
                    return Aggregation.newMessageInfo((MessageLite)DEFAULT_INSTANCE, (String)"\u0000\u0002\u0001\u0000\u0001\u0007\u0002\u0000\u0000\u0000\u0001<\u0000\u0007\u0208", (Object[])arrobject);
                }
                case 2: {
                    return new AggregationOrBuilder(){

                        public Builder clearAlias() {
                            this.copyOnWrite();
                            ((Aggregation)this.instance).clearAlias();
                            return this;
                        }

                        public Builder clearCount() {
                            this.copyOnWrite();
                            ((Aggregation)this.instance).clearCount();
                            return this;
                        }

                        public Builder clearOperator() {
                            this.copyOnWrite();
                            ((Aggregation)this.instance).clearOperator();
                            return this;
                        }

                        @Override
                        public String getAlias() {
                            return ((Aggregation)this.instance).getAlias();
                        }

                        @Override
                        public ByteString getAliasBytes() {
                            return ((Aggregation)this.instance).getAliasBytes();
                        }

                        @Override
                        public Count getCount() {
                            return ((Aggregation)this.instance).getCount();
                        }

                        @Override
                        public OperatorCase getOperatorCase() {
                            return ((Aggregation)this.instance).getOperatorCase();
                        }

                        @Override
                        public boolean hasCount() {
                            return ((Aggregation)this.instance).hasCount();
                        }

                        public Builder mergeCount(Count count) {
                            this.copyOnWrite();
                            ((Aggregation)this.instance).mergeCount(count);
                            return this;
                        }

                        public Builder setAlias(String string) {
                            this.copyOnWrite();
                            ((Aggregation)this.instance).setAlias(string);
                            return this;
                        }

                        public Builder setAliasBytes(ByteString byteString) {
                            this.copyOnWrite();
                            ((Aggregation)this.instance).setAliasBytes(byteString);
                            return this;
                        }

                        public Builder setCount(Count.Builder builder) {
                            this.copyOnWrite();
                            ((Aggregation)this.instance).setCount((Count)builder.build());
                            return this;
                        }

                        public Builder setCount(Count count) {
                            this.copyOnWrite();
                            ((Aggregation)this.instance).setCount(count);
                            return this;
                        }
                    };
                }
                case 1: 
            }
            return new Aggregation();
        }

        @Override
        public String getAlias() {
            return this.alias_;
        }

        @Override
        public ByteString getAliasBytes() {
            return ByteString.copyFromUtf8((String)this.alias_);
        }

        @Override
        public Count getCount() {
            if (this.operatorCase_ == 1) {
                return (Count)this.operator_;
            }
            return Count.getDefaultInstance();
        }

        @Override
        public OperatorCase getOperatorCase() {
            return OperatorCase.forNumber(this.operatorCase_);
        }

        @Override
        public boolean hasCount() {
            return this.operatorCase_ == 1;
        }

        public static final class Count
        extends GeneratedMessageLite<Count, Builder>
        implements CountOrBuilder {
            private static final Count DEFAULT_INSTANCE;
            private static volatile Parser<Count> PARSER;
            public static final int UP_TO_FIELD_NUMBER = 1;
            private Int64Value upTo_;

            static {
                Count count;
                DEFAULT_INSTANCE = count = new Count();
                GeneratedMessageLite.registerDefaultInstance(Count.class, (GeneratedMessageLite)count);
            }

            private Count() {
            }

            private void clearUpTo() {
                this.upTo_ = null;
            }

            public static Count getDefaultInstance() {
                return DEFAULT_INSTANCE;
            }

            private void mergeUpTo(Int64Value int64Value) {
                int64Value.getClass();
                Int64Value int64Value2 = this.upTo_;
                if (int64Value2 != null && int64Value2 != Int64Value.getDefaultInstance()) {
                    this.upTo_ = (Int64Value)((Int64Value.Builder)Int64Value.newBuilder((Int64Value)this.upTo_).mergeFrom((GeneratedMessageLite)int64Value)).buildPartial();
                    return;
                }
                this.upTo_ = int64Value;
            }

            public static Builder newBuilder() {
                return (Builder)DEFAULT_INSTANCE.createBuilder();
            }

            public static Builder newBuilder(Count count) {
                return (Builder)DEFAULT_INSTANCE.createBuilder((GeneratedMessageLite)count);
            }

            public static Count parseDelimitedFrom(InputStream inputStream) throws IOException {
                return (Count)Count.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
            }

            public static Count parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                return (Count)Count.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
            }

            public static Count parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
                return (Count)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
            }

            public static Count parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return (Count)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
            }

            public static Count parseFrom(CodedInputStream codedInputStream) throws IOException {
                return (Count)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
            }

            public static Count parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                return (Count)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
            }

            public static Count parseFrom(InputStream inputStream) throws IOException {
                return (Count)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
            }

            public static Count parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
                return (Count)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
            }

            public static Count parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
                return (Count)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer);
            }

            public static Count parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return (Count)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer, (ExtensionRegistryLite)extensionRegistryLite);
            }

            public static Count parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
                return (Count)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
            }

            public static Count parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
                return (Count)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
            }

            public static Parser<Count> parser() {
                return DEFAULT_INSTANCE.getParserForType();
            }

            private void setUpTo(Int64Value int64Value) {
                int64Value.getClass();
                this.upTo_ = int64Value;
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object object, Object object2) {
                switch (1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke[methodToInvoke.ordinal()]) {
                    default: {
                        throw new UnsupportedOperationException();
                    }
                    case 7: {
                        return null;
                    }
                    case 6: {
                        return (byte)1;
                    }
                    case 5: {
                        Parser<Count> parser = PARSER;
                        if (parser != null) {
                            return parser;
                        }
                        Class<Count> class_ = Count.class;
                        synchronized (Count.class) {
                            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                PARSER = defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DEFAULT_INSTANCE);
                            }
                            // ** MonitorExit[var8_5] (shouldn't be in output)
                            return defaultInstanceBasedParser;
                        }
                    }
                    case 4: {
                        return DEFAULT_INSTANCE;
                    }
                    case 3: {
                        Object[] arrobject = new Object[]{"upTo_"};
                        return Count.newMessageInfo((MessageLite)DEFAULT_INSTANCE, (String)"\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t", (Object[])arrobject);
                    }
                    case 2: {
                        return new Builder();
                    }
                    case 1: 
                }
                return new Count();
            }

            @Override
            public Int64Value getUpTo() {
                Int64Value int64Value = this.upTo_;
                if (int64Value == null) {
                    int64Value = Int64Value.getDefaultInstance();
                }
                return int64Value;
            }

            @Override
            public boolean hasUpTo() {
                return this.upTo_ != null;
            }

            public static final class Builder
            extends GeneratedMessageLite.Builder<Count, Builder>
            implements CountOrBuilder {
                private Builder() {
                    super((GeneratedMessageLite)DEFAULT_INSTANCE);
                }

                public Builder clearUpTo() {
                    this.copyOnWrite();
                    ((Count)this.instance).clearUpTo();
                    return this;
                }

                @Override
                public Int64Value getUpTo() {
                    return ((Count)this.instance).getUpTo();
                }

                @Override
                public boolean hasUpTo() {
                    return ((Count)this.instance).hasUpTo();
                }

                public Builder mergeUpTo(Int64Value int64Value) {
                    this.copyOnWrite();
                    ((Count)this.instance).mergeUpTo(int64Value);
                    return this;
                }

                public Builder setUpTo(Int64Value.Builder builder) {
                    this.copyOnWrite();
                    ((Count)this.instance).setUpTo((Int64Value)builder.build());
                    return this;
                }

                public Builder setUpTo(Int64Value int64Value) {
                    this.copyOnWrite();
                    ((Count)this.instance).setUpTo(int64Value);
                    return this;
                }
            }

        }

    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<StructuredAggregationQuery, Builder>
    implements StructuredAggregationQueryOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public Builder addAggregations(int n, Aggregation.Builder builder) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).addAggregations(n, (Aggregation)builder.build());
            return this;
        }

        public Builder addAggregations(int n, Aggregation aggregation) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).addAggregations(n, aggregation);
            return this;
        }

        public Builder addAggregations(Aggregation.Builder builder) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).addAggregations((Aggregation)builder.build());
            return this;
        }

        public Builder addAggregations(Aggregation aggregation) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).addAggregations(aggregation);
            return this;
        }

        public Builder addAllAggregations(Iterable<? extends Aggregation> iterable) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).addAllAggregations((Iterable<? extends Aggregation>)iterable);
            return this;
        }

        public Builder clearAggregations() {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).clearAggregations();
            return this;
        }

        public Builder clearQueryType() {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).clearQueryType();
            return this;
        }

        public Builder clearStructuredQuery() {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).clearStructuredQuery();
            return this;
        }

        @Override
        public Aggregation getAggregations(int n) {
            return ((StructuredAggregationQuery)this.instance).getAggregations(n);
        }

        @Override
        public int getAggregationsCount() {
            return ((StructuredAggregationQuery)this.instance).getAggregationsCount();
        }

        @Override
        public List<Aggregation> getAggregationsList() {
            return Collections.unmodifiableList(((StructuredAggregationQuery)this.instance).getAggregationsList());
        }

        @Override
        public QueryTypeCase getQueryTypeCase() {
            return ((StructuredAggregationQuery)this.instance).getQueryTypeCase();
        }

        @Override
        public StructuredQuery getStructuredQuery() {
            return ((StructuredAggregationQuery)this.instance).getStructuredQuery();
        }

        @Override
        public boolean hasStructuredQuery() {
            return ((StructuredAggregationQuery)this.instance).hasStructuredQuery();
        }

        public Builder mergeStructuredQuery(StructuredQuery structuredQuery) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).mergeStructuredQuery(structuredQuery);
            return this;
        }

        public Builder removeAggregations(int n) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).removeAggregations(n);
            return this;
        }

        public Builder setAggregations(int n, Aggregation.Builder builder) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).setAggregations(n, (Aggregation)builder.build());
            return this;
        }

        public Builder setAggregations(int n, Aggregation aggregation) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).setAggregations(n, aggregation);
            return this;
        }

        public Builder setStructuredQuery(StructuredQuery.Builder builder) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).setStructuredQuery((StructuredQuery)builder.build());
            return this;
        }

        public Builder setStructuredQuery(StructuredQuery structuredQuery) {
            this.copyOnWrite();
            ((StructuredAggregationQuery)this.instance).setStructuredQuery(structuredQuery);
            return this;
        }
    }

}

