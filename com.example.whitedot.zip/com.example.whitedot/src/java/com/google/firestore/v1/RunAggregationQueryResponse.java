/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  com.google.protobuf.Timestamp
 *  com.google.protobuf.Timestamp$Builder
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 *  java.nio.ByteBuffer
 */
package com.google.firestore.v1;

import com.google.firestore.v1.AggregationResult;
import com.google.firestore.v1.RunAggregationQueryResponse;
import com.google.firestore.v1.RunAggregationQueryResponseOrBuilder;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.google.protobuf.Timestamp;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public final class RunAggregationQueryResponse
extends GeneratedMessageLite<RunAggregationQueryResponse, Builder>
implements RunAggregationQueryResponseOrBuilder {
    private static final RunAggregationQueryResponse DEFAULT_INSTANCE;
    private static volatile Parser<RunAggregationQueryResponse> PARSER;
    public static final int READ_TIME_FIELD_NUMBER = 3;
    public static final int RESULT_FIELD_NUMBER = 1;
    public static final int TRANSACTION_FIELD_NUMBER = 2;
    private Timestamp readTime_;
    private AggregationResult result_;
    private ByteString transaction_ = ByteString.EMPTY;

    static {
        RunAggregationQueryResponse runAggregationQueryResponse;
        DEFAULT_INSTANCE = runAggregationQueryResponse = new RunAggregationQueryResponse();
        GeneratedMessageLite.registerDefaultInstance(RunAggregationQueryResponse.class, (GeneratedMessageLite)runAggregationQueryResponse);
    }

    private RunAggregationQueryResponse() {
    }

    private void clearReadTime() {
        this.readTime_ = null;
    }

    private void clearResult() {
        this.result_ = null;
    }

    private void clearTransaction() {
        this.transaction_ = RunAggregationQueryResponse.getDefaultInstance().getTransaction();
    }

    public static RunAggregationQueryResponse getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private void mergeReadTime(Timestamp timestamp) {
        timestamp.getClass();
        Timestamp timestamp2 = this.readTime_;
        if (timestamp2 != null && timestamp2 != Timestamp.getDefaultInstance()) {
            this.readTime_ = (Timestamp)((Timestamp.Builder)Timestamp.newBuilder((Timestamp)this.readTime_).mergeFrom((GeneratedMessageLite)timestamp)).buildPartial();
            return;
        }
        this.readTime_ = timestamp;
    }

    private void mergeResult(AggregationResult aggregationResult) {
        aggregationResult.getClass();
        AggregationResult aggregationResult2 = this.result_;
        if (aggregationResult2 != null && aggregationResult2 != AggregationResult.getDefaultInstance()) {
            this.result_ = (AggregationResult)((AggregationResult.Builder)AggregationResult.newBuilder(this.result_).mergeFrom((GeneratedMessageLite)aggregationResult)).buildPartial();
            return;
        }
        this.result_ = aggregationResult;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.createBuilder();
    }

    public static Builder newBuilder(RunAggregationQueryResponse runAggregationQueryResponse) {
        return (Builder)DEFAULT_INSTANCE.createBuilder((GeneratedMessageLite)runAggregationQueryResponse);
    }

    public static RunAggregationQueryResponse parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (RunAggregationQueryResponse)RunAggregationQueryResponse.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static RunAggregationQueryResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (RunAggregationQueryResponse)RunAggregationQueryResponse.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RunAggregationQueryResponse parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (RunAggregationQueryResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static RunAggregationQueryResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (RunAggregationQueryResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RunAggregationQueryResponse parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (RunAggregationQueryResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static RunAggregationQueryResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (RunAggregationQueryResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RunAggregationQueryResponse parseFrom(InputStream inputStream) throws IOException {
        return (RunAggregationQueryResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static RunAggregationQueryResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (RunAggregationQueryResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RunAggregationQueryResponse parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
        return (RunAggregationQueryResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer);
    }

    public static RunAggregationQueryResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (RunAggregationQueryResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static RunAggregationQueryResponse parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (RunAggregationQueryResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static RunAggregationQueryResponse parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (RunAggregationQueryResponse)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<RunAggregationQueryResponse> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    private void setReadTime(Timestamp timestamp) {
        timestamp.getClass();
        this.readTime_ = timestamp;
    }

    private void setResult(AggregationResult aggregationResult) {
        aggregationResult.getClass();
        this.result_ = aggregationResult;
    }

    private void setTransaction(ByteString byteString) {
        byteString.getClass();
        this.transaction_ = byteString;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object object, Object object2) {
        switch (1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke[methodToInvoke.ordinal()]) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                return null;
            }
            case 6: {
                return (byte)1;
            }
            case 5: {
                Parser<RunAggregationQueryResponse> parser = PARSER;
                if (parser != null) {
                    return parser;
                }
                Class<RunAggregationQueryResponse> class_ = RunAggregationQueryResponse.class;
                synchronized (RunAggregationQueryResponse.class) {
                    GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser = PARSER;
                    if (defaultInstanceBasedParser == null) {
                        PARSER = defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DEFAULT_INSTANCE);
                    }
                    // ** MonitorExit[var8_5] (shouldn't be in output)
                    return defaultInstanceBasedParser;
                }
            }
            case 4: {
                return DEFAULT_INSTANCE;
            }
            case 3: {
                Object[] arrobject = new Object[]{"result_", "transaction_", "readTime_"};
                return RunAggregationQueryResponse.newMessageInfo((MessageLite)DEFAULT_INSTANCE, (String)"\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\t\u0002\n\u0003\t", (Object[])arrobject);
            }
            case 2: {
                return new Builder();
            }
            case 1: 
        }
        return new RunAggregationQueryResponse();
    }

    @Override
    public Timestamp getReadTime() {
        Timestamp timestamp = this.readTime_;
        if (timestamp == null) {
            timestamp = Timestamp.getDefaultInstance();
        }
        return timestamp;
    }

    @Override
    public AggregationResult getResult() {
        AggregationResult aggregationResult = this.result_;
        if (aggregationResult == null) {
            aggregationResult = AggregationResult.getDefaultInstance();
        }
        return aggregationResult;
    }

    @Override
    public ByteString getTransaction() {
        return this.transaction_;
    }

    @Override
    public boolean hasReadTime() {
        return this.readTime_ != null;
    }

    @Override
    public boolean hasResult() {
        return this.result_ != null;
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<RunAggregationQueryResponse, Builder>
    implements RunAggregationQueryResponseOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public Builder clearReadTime() {
            this.copyOnWrite();
            ((RunAggregationQueryResponse)this.instance).clearReadTime();
            return this;
        }

        public Builder clearResult() {
            this.copyOnWrite();
            ((RunAggregationQueryResponse)this.instance).clearResult();
            return this;
        }

        public Builder clearTransaction() {
            this.copyOnWrite();
            ((RunAggregationQueryResponse)this.instance).clearTransaction();
            return this;
        }

        @Override
        public Timestamp getReadTime() {
            return ((RunAggregationQueryResponse)this.instance).getReadTime();
        }

        @Override
        public AggregationResult getResult() {
            return ((RunAggregationQueryResponse)this.instance).getResult();
        }

        @Override
        public ByteString getTransaction() {
            return ((RunAggregationQueryResponse)this.instance).getTransaction();
        }

        @Override
        public boolean hasReadTime() {
            return ((RunAggregationQueryResponse)this.instance).hasReadTime();
        }

        @Override
        public boolean hasResult() {
            return ((RunAggregationQueryResponse)this.instance).hasResult();
        }

        public Builder mergeReadTime(Timestamp timestamp) {
            this.copyOnWrite();
            ((RunAggregationQueryResponse)this.instance).mergeReadTime(timestamp);
            return this;
        }

        public Builder mergeResult(AggregationResult aggregationResult) {
            this.copyOnWrite();
            ((RunAggregationQueryResponse)this.instance).mergeResult(aggregationResult);
            return this;
        }

        public Builder setReadTime(Timestamp.Builder builder) {
            this.copyOnWrite();
            ((RunAggregationQueryResponse)this.instance).setReadTime((Timestamp)builder.build());
            return this;
        }

        public Builder setReadTime(Timestamp timestamp) {
            this.copyOnWrite();
            ((RunAggregationQueryResponse)this.instance).setReadTime(timestamp);
            return this;
        }

        public Builder setResult(AggregationResult.Builder builder) {
            this.copyOnWrite();
            ((RunAggregationQueryResponse)this.instance).setResult((AggregationResult)builder.build());
            return this;
        }

        public Builder setResult(AggregationResult aggregationResult) {
            this.copyOnWrite();
            ((RunAggregationQueryResponse)this.instance).setResult(aggregationResult);
            return this;
        }

        public Builder setTransaction(ByteString byteString) {
            this.copyOnWrite();
            ((RunAggregationQueryResponse)this.instance).setTransaction(byteString);
            return this;
        }
    }

}

