/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.ExtensionRegistryLite
 *  java.lang.Object
 */
package com.google.firestore.v1;

import com.google.protobuf.ExtensionRegistryLite;

public final class WriteProto {
    private WriteProto() {
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
    }
}

