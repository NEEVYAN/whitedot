/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firestore.v1.AggregationResult
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.MessageLiteOrBuilder
 *  com.google.protobuf.Timestamp
 *  java.lang.Object
 */
package com.google.firestore.v1;

import com.google.firestore.v1.AggregationResult;
import com.google.protobuf.ByteString;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Timestamp;

public interface RunAggregationQueryResponseOrBuilder
extends MessageLiteOrBuilder {
    public Timestamp getReadTime();

    public AggregationResult getResult();

    public ByteString getTransaction();

    public boolean hasReadTime();

    public boolean hasResult();
}

