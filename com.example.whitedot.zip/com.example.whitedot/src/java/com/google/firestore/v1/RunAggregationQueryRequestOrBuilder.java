/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firestore.v1.RunAggregationQueryRequest
 *  com.google.firestore.v1.StructuredAggregationQuery
 *  com.google.firestore.v1.TransactionOptions
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.MessageLiteOrBuilder
 *  com.google.protobuf.Timestamp
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.firestore.v1;

import com.google.firestore.v1.RunAggregationQueryRequest;
import com.google.firestore.v1.StructuredAggregationQuery;
import com.google.firestore.v1.TransactionOptions;
import com.google.protobuf.ByteString;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Timestamp;

public interface RunAggregationQueryRequestOrBuilder
extends MessageLiteOrBuilder {
    public RunAggregationQueryRequest.ConsistencySelectorCase getConsistencySelectorCase();

    public TransactionOptions getNewTransaction();

    public String getParent();

    public ByteString getParentBytes();

    public RunAggregationQueryRequest.QueryTypeCase getQueryTypeCase();

    public Timestamp getReadTime();

    public StructuredAggregationQuery getStructuredAggregationQuery();

    public ByteString getTransaction();

    public boolean hasNewTransaction();

    public boolean hasReadTime();

    public boolean hasStructuredAggregationQuery();

    public boolean hasTransaction();
}

