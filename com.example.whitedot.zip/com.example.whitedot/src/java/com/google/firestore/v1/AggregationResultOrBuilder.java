/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firestore.v1.Value
 *  com.google.protobuf.MessageLiteOrBuilder
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.google.firestore.v1;

import com.google.firestore.v1.Value;
import com.google.protobuf.MessageLiteOrBuilder;
import java.util.Map;

public interface AggregationResultOrBuilder
extends MessageLiteOrBuilder {
    public boolean containsAggregateFields(String var1);

    @Deprecated
    public Map<String, Value> getAggregateFields();

    public int getAggregateFieldsCount();

    public Map<String, Value> getAggregateFieldsMap();

    public Value getAggregateFieldsOrDefault(String var1, Value var2);

    public Value getAggregateFieldsOrThrow(String var1);
}

