/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firestore.v1.StructuredAggregationQuery
 *  com.google.firestore.v1.StructuredAggregationQuery$Aggregation
 *  com.google.firestore.v1.StructuredQuery
 *  com.google.protobuf.MessageLiteOrBuilder
 *  java.lang.Object
 *  java.util.List
 */
package com.google.firestore.v1;

import com.google.firestore.v1.StructuredAggregationQuery;
import com.google.firestore.v1.StructuredQuery;
import com.google.protobuf.MessageLiteOrBuilder;
import java.util.List;

public interface StructuredAggregationQueryOrBuilder
extends MessageLiteOrBuilder {
    public StructuredAggregationQuery.Aggregation getAggregations(int var1);

    public int getAggregationsCount();

    public List<StructuredAggregationQuery.Aggregation> getAggregationsList();

    public StructuredAggregationQuery.QueryTypeCase getQueryTypeCase();

    public StructuredQuery getStructuredQuery();

    public boolean hasStructuredQuery();
}

