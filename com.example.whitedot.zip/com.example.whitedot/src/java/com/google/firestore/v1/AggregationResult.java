/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.firestore.v1.Value
 *  com.google.protobuf.ByteString
 *  com.google.protobuf.CodedInputStream
 *  com.google.protobuf.ExtensionRegistryLite
 *  com.google.protobuf.GeneratedMessageLite
 *  com.google.protobuf.GeneratedMessageLite$Builder
 *  com.google.protobuf.GeneratedMessageLite$DefaultInstanceBasedParser
 *  com.google.protobuf.GeneratedMessageLite$MethodToInvoke
 *  com.google.protobuf.InvalidProtocolBufferException
 *  com.google.protobuf.MapEntryLite
 *  com.google.protobuf.MapFieldLite
 *  com.google.protobuf.MessageLite
 *  com.google.protobuf.Parser
 *  com.google.protobuf.WireFormat
 *  com.google.protobuf.WireFormat$FieldType
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 *  java.nio.ByteBuffer
 *  java.util.Collections
 *  java.util.Map
 */
package com.google.firestore.v1;

import com.google.firestore.v1.AggregationResult;
import com.google.firestore.v1.AggregationResultOrBuilder;
import com.google.firestore.v1.Value;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.google.protobuf.WireFormat;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Map;

public final class AggregationResult
extends GeneratedMessageLite<AggregationResult, Builder>
implements AggregationResultOrBuilder {
    public static final int AGGREGATE_FIELDS_FIELD_NUMBER = 2;
    private static final AggregationResult DEFAULT_INSTANCE;
    private static volatile Parser<AggregationResult> PARSER;
    private MapFieldLite<String, Value> aggregateFields_ = MapFieldLite.emptyMapField();

    static {
        AggregationResult aggregationResult;
        DEFAULT_INSTANCE = aggregationResult = new AggregationResult();
        GeneratedMessageLite.registerDefaultInstance(AggregationResult.class, (GeneratedMessageLite)aggregationResult);
    }

    private AggregationResult() {
    }

    public static AggregationResult getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    private Map<String, Value> getMutableAggregateFieldsMap() {
        return this.internalGetMutableAggregateFields();
    }

    private MapFieldLite<String, Value> internalGetAggregateFields() {
        return this.aggregateFields_;
    }

    private MapFieldLite<String, Value> internalGetMutableAggregateFields() {
        if (!this.aggregateFields_.isMutable()) {
            this.aggregateFields_ = this.aggregateFields_.mutableCopy();
        }
        return this.aggregateFields_;
    }

    public static Builder newBuilder() {
        return (Builder)DEFAULT_INSTANCE.createBuilder();
    }

    public static Builder newBuilder(AggregationResult aggregationResult) {
        return (Builder)DEFAULT_INSTANCE.createBuilder((GeneratedMessageLite)aggregationResult);
    }

    public static AggregationResult parseDelimitedFrom(InputStream inputStream) throws IOException {
        return (AggregationResult)AggregationResult.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static AggregationResult parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AggregationResult)AggregationResult.parseDelimitedFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AggregationResult parseFrom(ByteString byteString) throws InvalidProtocolBufferException {
        return (AggregationResult)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString);
    }

    public static AggregationResult parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AggregationResult)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteString)byteString, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AggregationResult parseFrom(CodedInputStream codedInputStream) throws IOException {
        return (AggregationResult)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream);
    }

    public static AggregationResult parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AggregationResult)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (CodedInputStream)codedInputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AggregationResult parseFrom(InputStream inputStream) throws IOException {
        return (AggregationResult)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream);
    }

    public static AggregationResult parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) throws IOException {
        return (AggregationResult)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (InputStream)inputStream, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AggregationResult parseFrom(ByteBuffer byteBuffer) throws InvalidProtocolBufferException {
        return (AggregationResult)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer);
    }

    public static AggregationResult parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AggregationResult)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (ByteBuffer)byteBuffer, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static AggregationResult parseFrom(byte[] arrby) throws InvalidProtocolBufferException {
        return (AggregationResult)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby);
    }

    public static AggregationResult parseFrom(byte[] arrby, ExtensionRegistryLite extensionRegistryLite) throws InvalidProtocolBufferException {
        return (AggregationResult)GeneratedMessageLite.parseFrom((GeneratedMessageLite)DEFAULT_INSTANCE, (byte[])arrby, (ExtensionRegistryLite)extensionRegistryLite);
    }

    public static Parser<AggregationResult> parser() {
        return DEFAULT_INSTANCE.getParserForType();
    }

    @Override
    public boolean containsAggregateFields(String string) {
        string.getClass();
        return this.internalGetAggregateFields().containsKey((Object)string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object object, Object object2) {
        switch (1.$SwitchMap$com$google$protobuf$GeneratedMessageLite$MethodToInvoke[methodToInvoke.ordinal()]) {
            default: {
                throw new UnsupportedOperationException();
            }
            case 7: {
                return null;
            }
            case 6: {
                return (byte)1;
            }
            case 5: {
                Parser<AggregationResult> parser = PARSER;
                if (parser != null) {
                    return parser;
                }
                Class<AggregationResult> class_ = AggregationResult.class;
                synchronized (AggregationResult.class) {
                    GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser = PARSER;
                    if (defaultInstanceBasedParser == null) {
                        PARSER = defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser((GeneratedMessageLite)DEFAULT_INSTANCE);
                    }
                    // ** MonitorExit[var8_5] (shouldn't be in output)
                    return defaultInstanceBasedParser;
                }
            }
            case 4: {
                return DEFAULT_INSTANCE;
            }
            case 3: {
                Object[] arrobject = new Object[]{"aggregateFields_", AggregateFieldsDefaultEntryHolder.defaultEntry};
                return AggregationResult.newMessageInfo((MessageLite)DEFAULT_INSTANCE, (String)"\u0000\u0001\u0000\u0000\u0002\u0002\u0001\u0001\u0000\u0000\u00022", (Object[])arrobject);
            }
            case 2: {
                return new Builder();
            }
            case 1: 
        }
        return new AggregationResult();
    }

    @Deprecated
    @Override
    public Map<String, Value> getAggregateFields() {
        return this.getAggregateFieldsMap();
    }

    @Override
    public int getAggregateFieldsCount() {
        return this.internalGetAggregateFields().size();
    }

    @Override
    public Map<String, Value> getAggregateFieldsMap() {
        return Collections.unmodifiableMap(this.internalGetAggregateFields());
    }

    @Override
    public Value getAggregateFieldsOrDefault(String string, Value value) {
        string.getClass();
        MapFieldLite<String, Value> mapFieldLite = this.internalGetAggregateFields();
        if (mapFieldLite.containsKey((Object)string)) {
            return (Value)mapFieldLite.get((Object)string);
        }
        return value;
    }

    @Override
    public Value getAggregateFieldsOrThrow(String string) {
        string.getClass();
        MapFieldLite<String, Value> mapFieldLite = this.internalGetAggregateFields();
        if (mapFieldLite.containsKey((Object)string)) {
            return (Value)mapFieldLite.get((Object)string);
        }
        throw new IllegalArgumentException();
    }

    public static final class Builder
    extends GeneratedMessageLite.Builder<AggregationResult, Builder>
    implements AggregationResultOrBuilder {
        private Builder() {
            super((GeneratedMessageLite)DEFAULT_INSTANCE);
        }

        public Builder clearAggregateFields() {
            this.copyOnWrite();
            ((AggregationResult)this.instance).getMutableAggregateFieldsMap().clear();
            return this;
        }

        @Override
        public boolean containsAggregateFields(String string) {
            string.getClass();
            return ((AggregationResult)this.instance).getAggregateFieldsMap().containsKey((Object)string);
        }

        @Deprecated
        @Override
        public Map<String, Value> getAggregateFields() {
            return this.getAggregateFieldsMap();
        }

        @Override
        public int getAggregateFieldsCount() {
            return ((AggregationResult)this.instance).getAggregateFieldsMap().size();
        }

        @Override
        public Map<String, Value> getAggregateFieldsMap() {
            return Collections.unmodifiableMap(((AggregationResult)this.instance).getAggregateFieldsMap());
        }

        @Override
        public Value getAggregateFieldsOrDefault(String string, Value value) {
            string.getClass();
            Map<String, Value> map = ((AggregationResult)this.instance).getAggregateFieldsMap();
            if (map.containsKey((Object)string)) {
                return (Value)map.get((Object)string);
            }
            return value;
        }

        @Override
        public Value getAggregateFieldsOrThrow(String string) {
            string.getClass();
            Map<String, Value> map = ((AggregationResult)this.instance).getAggregateFieldsMap();
            if (map.containsKey((Object)string)) {
                return (Value)map.get((Object)string);
            }
            throw new IllegalArgumentException();
        }

        public Builder putAggregateFields(String string, Value value) {
            string.getClass();
            value.getClass();
            this.copyOnWrite();
            ((AggregationResult)this.instance).getMutableAggregateFieldsMap().put((Object)string, (Object)value);
            return this;
        }

        public Builder putAllAggregateFields(Map<String, Value> map) {
            this.copyOnWrite();
            ((AggregationResult)this.instance).getMutableAggregateFieldsMap().putAll(map);
            return this;
        }

        public Builder removeAggregateFields(String string) {
            string.getClass();
            this.copyOnWrite();
            ((AggregationResult)this.instance).getMutableAggregateFieldsMap().remove((Object)string);
            return this;
        }
    }

}

