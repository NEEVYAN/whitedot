/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.MessageLiteOrBuilder
 *  java.lang.Object
 */
package com.google.firestore.v1;

import com.google.protobuf.MessageLiteOrBuilder;

public interface ExistenceFilterOrBuilder
extends MessageLiteOrBuilder {
    public int getCount();

    public int getTargetId();
}

