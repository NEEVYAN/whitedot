/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.ExtensionRegistryLite
 *  java.lang.Object
 */
package com.google.firestore.bundle;

import com.google.protobuf.ExtensionRegistryLite;

public final class BundleProto {
    private BundleProto() {
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
    }
}

