/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.MessageLiteOrBuilder
 *  java.lang.Object
 */
package com.google.type;

import com.google.protobuf.MessageLiteOrBuilder;

public interface QuaternionOrBuilder
extends MessageLiteOrBuilder {
    public double getW();

    public double getX();

    public double getY();

    public double getZ();
}

