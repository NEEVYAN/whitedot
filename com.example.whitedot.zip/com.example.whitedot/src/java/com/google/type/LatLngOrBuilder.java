/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.MessageLiteOrBuilder
 *  java.lang.Object
 */
package com.google.type;

import com.google.protobuf.MessageLiteOrBuilder;

public interface LatLngOrBuilder
extends MessageLiteOrBuilder {
    public double getLatitude();

    public double getLongitude();
}

