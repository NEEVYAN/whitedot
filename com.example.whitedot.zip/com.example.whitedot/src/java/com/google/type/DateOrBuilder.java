/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.MessageLiteOrBuilder
 *  java.lang.Object
 */
package com.google.type;

import com.google.protobuf.MessageLiteOrBuilder;

public interface DateOrBuilder
extends MessageLiteOrBuilder {
    public int getDay();

    public int getMonth();

    public int getYear();
}

