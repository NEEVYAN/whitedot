/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.ExtensionRegistryLite
 *  java.lang.Object
 */
package com.google.type;

import com.google.protobuf.ExtensionRegistryLite;

public final class DayOfWeekProto {
    private DayOfWeekProto() {
    }

    public static void registerAllExtensions(ExtensionRegistryLite extensionRegistryLite) {
    }
}

